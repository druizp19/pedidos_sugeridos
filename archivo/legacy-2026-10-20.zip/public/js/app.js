/**
 * MEDIFARMA HUMANOVA - Pedidos Sugeridos & DESGLOSE POR CLIENTE
 * Controlador Front-End de la Matriz Interactiva con Ordenamiento Avanzado
 */

const state = {
    unidadMedida: 'UNIDAD',
    filters: {
        unidades_negocio: [],
        franquicias: [],
        marcas: [],
        categorizaciones: [],
        quintiles: [],
        supervisores: [],
        zonas_base: [],
        clients: []
    },
    selected: {
        unidadNegocio: '',
        franquicia: '',
        marca: '',
        quintil: '',
        zonaBase: '',
        supervisor: '',
        search: '',
        clients: [] // Array of client cp_cliente strings
    },
    sortBy: 'vta_act',       // 'vta_act', 'estimacion', 'marca', 'vta_mdo', 'ms_act', 'ms_ideal', etc.
    sortDir: 'desc',        // 'desc' or 'asc'
    matrixData: null,
    collapsedBrands: new Set(),
    isLoading: false
};

// ==========================================================================
// INITIALIZATION
// ==========================================================================
document.addEventListener('DOMContentLoaded', async () => {
    showLoading(true);
    await loadFilters();
    await loadMatrixData();
    showLoading(false);
});

// ==========================================================================
// API CALLS
// ==========================================================================
async function loadFilters() {
    try {
        const res = await fetch('/api/filters');
        const json = await res.json();
        if (json.success && json.data) {
            state.filters = json.data;
            populateFilterDropdowns();
            state.selected.clients = [];
            updateSelectedClientsBadge();
        }
    } catch (e) {
        console.error("Error loading filters:", e);
        showToast("Error al cargar los filtros del servidor", "error");
    }
}

async function loadMatrixData() {
    showLoading(true);
    try {
        const payload = {
            unidadMedida: state.unidadMedida,
            unidadNegocio: state.selected.unidadNegocio ? [state.selected.unidadNegocio] : [],
            franquicia: state.selected.franquicia ? [state.selected.franquicia] : [],
            marca: state.selected.marca ? [state.selected.marca] : [],
            categorizacion: state.selected.quintil ? [state.selected.quintil] : [],
            zonaBase: state.selected.zonaBase ? [state.selected.zonaBase] : [],
            supervisor: state.selected.supervisor ? [state.selected.supervisor] : [],
            selectedClients: state.selected.clients,
            search: state.selected.search
        };

        const res = await fetch('/api/matrix', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const json = await res.json();
        if (json.success && json.data) {
            state.matrixData = json.data;
            sortMatrixData();
            renderKPIs();
            renderMatrix();
            updateSortUI();
        } else {
            showToast("Error en datos de matriz: " + (json.error || "Desconocido"), "error");
        }
    } catch (e) {
        console.error("Error loading matrix data:", e);
        showToast("Error al consultar la matriz de datos", "error");
    } finally {
        showLoading(false);
    }
}

// ==========================================================================
// SORTING LOGIC
// ==========================================================================
function sortMatrixData() {
    if (!state.matrixData || !state.matrixData.brands) return;

    const field = state.sortBy;
    const dir = state.sortDir === 'asc' ? 1 : -1;

    // 1. Sort Brands
    state.matrixData.brands.sort((a, b) => {
        if (field === 'marca') {
            return dir * a.marca.localeCompare(b.marca);
        }
        const valA = Number(a[field]) || 0;
        const valB = Number(b[field]) || 0;
        if (valA === valB) {
            return a.marca.localeCompare(b.marca);
        }
        return dir * (valA - valB);
    });

    // 2. Sort SKUs within each brand
    state.matrixData.brands.forEach(b => {
        if (b.skus && b.skus.length > 0) {
            b.skus.sort((sa, sb) => {
                if (field === 'marca') {
                    return dir * sa.sku.localeCompare(sb.sku);
                }
                const valA = Number(sa[field]) || 0;
                const valB = Number(sb[field]) || 0;
                if (valA === valB) {
                    return sa.sku.localeCompare(sb.sku);
                }
                return dir * (valA - valB);
            });
        }
    });
}

function toggleSort(field) {
    if (state.sortBy === field) {
        // Toggle direction
        state.sortDir = state.sortDir === 'asc' ? 'desc' : 'asc';
    } else {
        state.sortBy = field;
        // Default to desc for metrics, asc for text
        state.sortDir = field === 'marca' ? 'asc' : 'desc';
    }

    sortMatrixData();
    updateSortUI();
    renderMatrix();

    const fieldLabels = {
        'vta_act': 'Venta Actual',
        'estimacion': 'Estimación',
        'marca': 'Marca / SKU',
        'vta_mdo': 'Venta Mercado',
        'ms_act': 'MS. Actual',
        'ms_ant': 'MS. Anterior',
        'ms_territorio': 'MS. Territorio',
        'ms_ideal': 'MS. Ideal'
    };
    const dirLabel = state.sortDir === 'asc' ? 'Menor a Mayor' : 'Mayor a Menor';
    showToast(`Ordenado por: ${fieldLabels[field] || field} (${dirLabel})`, 'info');
}

function onSortDropdownChange() {
    const val = document.getElementById('selOrderBy').value;
    const parts = val.split('_');
    const dir = parts.pop(); // 'asc' or 'desc'
    const field = parts.join('_'); // 'vta_act', 'estimacion', 'marca', etc.

    state.sortBy = field;
    state.sortDir = dir;

    sortMatrixData();
    updateSortUI();
    renderMatrix();
}

function updateSortUI() {
    // 1. Update dropdown value
    const dropdownVal = `${state.sortBy}_${state.sortDir}`;
    const selOrder = document.getElementById('selOrderBy');
    if (selOrder) {
        selOrder.value = dropdownVal;
    }

    // 2. Update active sort text badge
    const fieldLabels = {
        'vta_act': 'Venta Actual',
        'estimacion': 'Estimación',
        'marca': 'Marca (A-Z)',
        'vta_mdo': 'Venta Mercado',
        'ms_act': 'MS. Actual',
        'ms_ant': 'MS. Anterior',
        'ms_territorio': 'MS. Territorio',
        'ms_ideal': 'MS. Ideal'
    };
    const dirLabel = state.sortDir === 'asc' ? 'Menor a Mayor' : 'Mayor a Menor';
    const activeText = document.getElementById('activeSortText');
    if (activeText) {
        activeText.innerText = `${fieldLabels[state.sortBy] || state.sortBy} (${dirLabel})`;
    }

    // 3. Update table header sort icons
    const allIcons = document.querySelectorAll('.sort-icon');
    allIcons.forEach(icon => {
        icon.className = 'fa-solid fa-sort sort-icon';
    });

    const activeIcon = document.getElementById(`sortIcon_${state.sortBy}`);
    if (activeIcon) {
        if (state.sortDir === 'asc') {
            activeIcon.className = 'fa-solid fa-sort-up sort-icon active';
        } else {
            activeIcon.className = 'fa-solid fa-sort-down sort-icon active';
        }
    }
}

// ==========================================================================
// DROPDOWNS & FILTER HANDLING
// ==========================================================================
function populateFilterDropdowns() {
    const selUN = document.getElementById('selUnidadNegocio');
    const selFr = document.getElementById('selFranquicia');
    const selMa = document.getElementById('selMarca');
    const selZB = document.getElementById('selZonaBase');
    const selSup = document.getElementById('selSupervisor');

    if (selUN) {
        selUN.innerHTML = '<option value="">(Todas)</option>' + 
            (state.filters.unidades_negocio || []).map(u => `<option value="${escapeHtml(u)}">${escapeHtml(u)}</option>`).join('');
    }
    if (selFr) {
        selFr.innerHTML = '<option value="">(Todas)</option>' + 
            (state.filters.franquicias || []).map(f => `<option value="${escapeHtml(f)}">${escapeHtml(f)}</option>`).join('');
    }
    if (selMa) {
        selMa.innerHTML = '<option value="">(Todas)</option>' + 
            (state.filters.marcas || []).map(m => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join('');
    }
    if (selZB) {
        selZB.innerHTML = '<option value="">(Todas)</option>' + 
            (state.filters.zonas_base || []).map(z => `<option value="${escapeHtml(z)}">${escapeHtml(z)}</option>`).join('');
    }
    if (selSup) {
        selSup.innerHTML = '<option value="">(Todos)</option>' + 
            (state.filters.supervisores || []).map(s => `<option value="${escapeHtml(s)}">${escapeHtml(s)}</option>`).join('');
    }
}

function getAvailableClientsForCategory() {
    let all = state.filters.clients || [];
    if (state.selected.quintil) {
        const catMap = {'Q1': 'DIAMANTE', 'Q2': 'ORO', 'Q3': 'PLATA', 'Q4': 'BRONCE', 'Q5': 'PLOMO'};
        const activeCat = catMap[state.selected.quintil] || state.selected.quintil;
        all = all.filter(c => c.categorizacion === activeCat || c.quintil === state.selected.quintil);
    }
    if (state.selected.zonaBase) {
        all = all.filter(c => c.zonabase === state.selected.zonaBase);
    }
    if (state.selected.supervisor) {
        all = all.filter(c => c.supervisor === state.selected.supervisor);
    }
    return all;
}

function onFilterChange(changedFilterKey) {
    const selUN = document.getElementById('selUnidadNegocio');
    const selFr = document.getElementById('selFranquicia');
    const selMa = document.getElementById('selMarca');
    const selQu = document.getElementById('selQuintil');
    const selZB = document.getElementById('selZonaBase');
    const selSup = document.getElementById('selSupervisor');

    state.selected.unidadNegocio = selUN ? selUN.value : '';
    state.selected.franquicia = selFr ? selFr.value : '';
    state.selected.marca = selMa ? selMa.value : '';
    state.selected.quintil = selQu ? selQu.value : '';
    state.selected.zonaBase = selZB ? selZB.value : '';
    state.selected.supervisor = selSup ? selSup.value : '';

    if (changedFilterKey === 'quintil' || changedFilterKey === 'zonaBase' || changedFilterKey === 'supervisor') {
        // Strong mutual exclusion: prune any selected clients not belonging to the selected category/zonabase/supervisor
        const available = getAvailableClientsForCategory();
        const availableSet = new Set(available.map(c => c.cp_cliente));
        state.selected.clients = state.selected.clients.filter(cp => availableSet.has(cp));
        updateSelectedClientsBadge();
    }

    loadMatrixData();
}

let searchDebounceTimer = null;
function onSearchInput() {
    clearTimeout(searchDebounceTimer);
    searchDebounceTimer = setTimeout(() => {
        state.selected.search = document.getElementById('txtSearch').value.trim();
        filterRowsInDOM();
    }, 200);
}

function setUnit(unit) {
    if (state.unidadMedida === unit) return;
    state.unidadMedida = unit;
    
    document.getElementById('btnUnitUnidad').classList.toggle('active', unit === 'UNIDAD');
    document.getElementById('btnUnitSoles').classList.toggle('active', unit === 'S/ SOLES');
    
    document.getElementById('kpiUnitText1').innerText = unit === 'UNIDAD' ? 'Unidades / mes' : 'Soles (S/) / mes';

    showToast(`Métrica cambiada a: ${unit === 'UNIDAD' ? 'UNIDADES' : 'S/ SOLES'}`, "info");
    loadMatrixData();
}

function resetFilters() {
    const selUN = document.getElementById('selUnidadNegocio');
    const selFr = document.getElementById('selFranquicia');
    const selMa = document.getElementById('selMarca');
    const selQu = document.getElementById('selQuintil');
    const selZB = document.getElementById('selZonaBase');
    const selSup = document.getElementById('selSupervisor');
    const txtSearch = document.getElementById('txtSearch');

    if (selUN) selUN.value = '';
    if (selFr) selFr.value = '';
    if (selMa) selMa.value = '';
    if (selQu) selQu.value = '';
    if (selZB) selZB.value = '';
    if (selSup) selSup.value = '';
    if (txtSearch) txtSearch.value = '';

    state.selected.unidadNegocio = '';
    state.selected.franquicia = '';
    state.selected.marca = '';
    state.selected.quintil = '';
    state.selected.zonaBase = '';
    state.selected.supervisor = '';
    state.selected.clients = [];
    state.selected.search = '';

    updateSelectedClientsBadge();
    loadMatrixData();
    showToast("Filtros restablecidos", "info");
}

// ==========================================================================
// RENDER KPI SUMMARY CARDS
// ==========================================================================
function renderKPIs() {
    if (!state.matrixData || !state.matrixData.totals) return;
    const t = state.matrixData.totals;
    const isSoles = state.unidadMedida === 'S/ SOLES';

    document.getElementById('kpiVtaAct').innerText = formatNumber(t.vta_act, isSoles);
    document.getElementById('kpiVtaMdo').innerText = formatNumber(t.vta_mdo, isSoles);
    document.getElementById('kpiMsAct').innerText = formatPercent(t.ms_act);
    document.getElementById('kpiMsIdeal').innerText = formatPercent(t.ms_ideal);
    document.getElementById('kpiEstimacion').innerText = formatNumber(t.estimacion, isSoles);
}

// ==========================================================================
// RENDER TABLE HEADERS & ROWS
// ==========================================================================
function renderMatrix() {
    if (!state.matrixData) return;
    const data = state.matrixData;
    const clientCols = data.client_columns || [];
    const brands = data.brands || [];
    const totals = data.totals || {};
    const isSoles = state.unidadMedida === 'S/ SOLES';

    // Update Brand count badge
    document.getElementById('brandCountBadge').innerText = `${brands.length} marcas`;

    // 1. RENDER TABLE HEADERS
    const trLevel1 = document.querySelector('.header-level-1');
    const trLevel2 = document.getElementById('headerLevel2');

    // Remove previously added client headers
    document.querySelectorAll('.th-client-header-dyn').forEach(e => e.remove());
    document.querySelectorAll('.th-client-sub-dyn').forEach(e => e.remove());

    // Inject Client Headers Level 1 & 2
    clientCols.forEach(cli => {
        // Level 1: Client RUC & Name (Clickable to open detailed construction share modal)
        const thL1 = document.createElement('th');
        thL1.className = 'th-client-header th-client-header-dyn';
        thL1.colSpan = 2;
        thL1.style.cursor = 'pointer';
        thL1.title = `Haga clic para ver el desglose recalculado de ${cli.cp_cliente}`;
        thL1.onclick = () => openClientDetailModal(cli.cp_cliente);
        thL1.innerHTML = `
            <div style="max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin: 0 auto; font-weight: 700;">${cli.cp_cliente}</div>
            <div style="font-size: 0.68rem; opacity: 0.9; margin-top: 2px;">
                <span style="background: rgba(255,255,255,0.7); color: #53459e; padding: 1px 6px; border-radius: 4px; font-weight: bold;">Ver Share</span>
            </div>
        `;
        trLevel1.appendChild(thL1);

        // Level 2: Sub-columns (¿COMPRA?, QUINTIL)
        const thCompra = document.createElement('th');
        thCompra.className = 'th-metric th-client-sub th-client-sub-dyn';
        thCompra.innerText = '¿COMPRA?';
        trLevel2.appendChild(thCompra);

        const thQuintil = document.createElement('th');
        thQuintil.className = 'th-metric th-client-sub th-client-sub-dyn';
        thQuintil.innerText = 'QUINTIL';
        trLevel2.appendChild(thQuintil);
    });

    // 2. RENDER TBODY (BRANDS & SKUS)
    const tbody = document.getElementById('matrixTableBody');
    tbody.innerHTML = '';

    brands.forEach(b => {
        const isCollapsed = state.collapsedBrands.has(b.marca);
        const skuCount = (b.skus || []).length;

        // Brand Row
        const trBrand = document.createElement('tr');
        trBrand.className = 'tr-brand';
        trBrand.dataset.brand = b.marca;

        let brandHtml = `
            <td class="td-sticky">
                <div class="brand-cell-content" onclick="toggleBrand('${escapeHtml(b.marca)}')">
                    <span class="toggle-icon"><i class="fa-solid ${isCollapsed ? 'fa-plus' : 'fa-minus'}"></i></span>
                    <span class="brand-name">${b.marca}</span>
                    <span class="brand-sku-badge">${skuCount} SKU${skuCount !== 1 ? 's' : ''}</span>
                </div>
            </td>
            <td>${formatNumber(b.vta_act, isSoles)}</td>
            <td>${formatNumber(b.vta_mdo, isSoles)}</td>
            <td>${formatPercent(b.ms_act)}</td>
            <td>${formatPercent(b.ms_ant)}</td>
            <td>${formatPercent(b.ms_territorio)}</td>
            <td class="col-ideal">${formatPercent(b.ms_ideal)}</td>
            <td class="col-estimacion">${formatNumber(b.estimacion, isSoles)}</td>
        `;

        // Client columns for Brand
        clientCols.forEach(cli => {
            const clientInfo = b.clients ? b.clients[cli.cp_cliente] : { compra: 'NO', quintil: cli.quintil };
            const compra = clientInfo ? clientInfo.compra : 'NO';
            const quintil = (clientInfo && clientInfo.quintil) ? clientInfo.quintil : cli.quintil;
            const compraClass = compra === 'SI' ? 'si' : 'no';

            brandHtml += `
                <td class="td-client-compra">
                    <span class="badge-compra ${compraClass}">${compra}</span>
                </td>
                <td class="td-client-quintil">
                    <span class="badge-quintil ${quintil}">${quintil || '-'}</span>
                </td>
            `;
        });

        trBrand.innerHTML = brandHtml;
        tbody.appendChild(trBrand);

        // SKU Rows
        (b.skus || []).forEach(s => {
            const trSku = document.createElement('tr');
            trSku.className = `tr-sku ${isCollapsed ? 'collapsed' : ''}`;
            trSku.dataset.parentBrand = b.marca;

            let skuHtml = `
                <td class="td-sticky" title="${s.sku}">
                    <span class="sku-text">${s.sku}</span>
                </td>
                <td>${formatNumber(s.vta_act, isSoles)}</td>
                <td>${formatNumber(s.vta_mdo, isSoles)}</td>
                <td>${formatPercent(s.ms_act)}</td>
                <td>${formatPercent(s.ms_ant)}</td>
                <td>${formatPercent(s.ms_territorio)}</td>
                <td class="col-ideal">${formatPercent(s.ms_ideal)}</td>
                <td class="col-estimacion">${formatNumber(s.estimacion, isSoles)}</td>
            `;

            clientCols.forEach(cli => {
                const clientInfo = s.clients ? s.clients[cli.cp_cliente] : { compra: 'NO', quintil: cli.quintil };
                const compra = clientInfo ? clientInfo.compra : 'NO';
                const quintil = (clientInfo && clientInfo.quintil) ? clientInfo.quintil : cli.quintil;
                const compraClass = compra === 'SI' ? 'si' : 'no';

                skuHtml += `
                    <td class="td-client-compra">
                        <span class="badge-compra ${compraClass}">${compra}</span>
                    </td>
                    <td class="td-client-quintil">
                        <span class="badge-quintil ${quintil}">${quintil || '-'}</span>
                    </td>
                `;
            });

            trSku.innerHTML = skuHtml;
            tbody.appendChild(trSku);
        });
    });

    // 3. RENDER TFOOT (TOTAL ROW)
    const tfoot = document.getElementById('matrixTableFoot');
    let totalHtml = `
        <tr>
            <td class="td-sticky">Total General</td>
            <td>${formatNumber(totals.vta_act, isSoles)}</td>
            <td>${formatNumber(totals.vta_mdo, isSoles)}</td>
            <td>${formatPercent(totals.ms_act)}</td>
            <td>${formatPercent(totals.ms_ant)}</td>
            <td>${formatPercent(totals.ms_territorio)}</td>
            <td class="col-ideal">${formatPercent(totals.ms_ideal)}</td>
            <td class="col-estimacion">${formatNumber(totals.estimacion, isSoles)}</td>
    `;

    // Fill blank cells for client columns in total row
    clientCols.forEach(() => {
        totalHtml += `<td></td><td></td>`;
    });

    totalHtml += `</tr>`;
    tfoot.innerHTML = totalHtml;
}

// ==========================================================================
// TREE EXPAND / COLLAPSE
// ==========================================================================
function toggleBrand(brandName) {
    if (state.collapsedBrands.has(brandName)) {
        state.collapsedBrands.delete(brandName);
    } else {
        state.collapsedBrands.add(brandName);
    }

    const isCollapsed = state.collapsedBrands.has(brandName);

    // Toggle icon
    const trBrand = document.querySelector(`tr.tr-brand[data-brand="${CSS.escape(brandName)}"]`);
    if (trBrand) {
        const icon = trBrand.querySelector('.toggle-icon i');
        if (icon) {
            icon.className = `fa-solid ${isCollapsed ? 'fa-plus' : 'fa-minus'}`;
        }
    }

    // Toggle SKU rows
    const skuRows = document.querySelectorAll(`tr.tr-sku[data-parent-brand="${CSS.escape(brandName)}"]`);
    skuRows.forEach(row => {
        row.classList.toggle('collapsed', isCollapsed);
    });
}

function expandAll(expand) {
    if (expand) {
        state.collapsedBrands.clear();
    } else {
        if (state.matrixData && state.matrixData.brands) {
            state.matrixData.brands.forEach(b => state.collapsedBrands.add(b.marca));
        }
    }
    renderMatrix();
}

// ==========================================================================
// CLIENT SELECTOR MODAL
// ==========================================================================
function getCategoryOptions() {
    const sel = document.getElementById('selQuintil');
    if (sel && sel.options) {
        return Array.from(sel.options).map(o => ({ value: o.value, label: o.text }));
    }
    return [
        { value: '', label: 'Todas las categorías' },
        { value: 'DIAMANTE', label: 'DIAMANTE (Q1)' },
        { value: 'ORO', label: 'ORO (Q2)' },
        { value: 'PLATA', label: 'PLATA (Q3)' },
        { value: 'BRONCE', label: 'BRONCE (Q4)' },
        { value: 'PLOMO', label: 'PLOMO (Q5)' },
        { value: 'SIN CATEGORIZACION', label: 'SIN CATEGORIZACION' }
    ];
}
window.getCategoryOptions = getCategoryOptions;

function openClientModal() {
    const modal = document.getElementById('clientModal');
    if (!modal) return;
    const available = getAvailableClientsForCategory();
    const catOpt = getCategoryOptions().find(o => o.value === state.selected.quintil);
    const catName = state.selected.quintil ? (catOpt ? catOpt.label : state.selected.quintil) : 'Todas las categorías';
    const descEl = document.querySelector('.modal-desc');
    if (descEl) {
        descEl.innerHTML = `Categoría activa: <strong style="color: var(--color-primary);">${catName}</strong> &bull; Total disponibles: <strong>${available.length}</strong> clientes`;
    }
    const txtSearch = document.getElementById('txtModalClientSearch');
    if (txtSearch) txtSearch.value = '';
    renderModalClientList();
    modal.classList.add('active');
}
window.openClientModal = openClientModal;

function closeClientModal() {
    document.getElementById('clientModal').classList.remove('active');
}

function renderModalClientList(filteredList = null) {
    const isSearch = filteredList !== null;
    const list = filteredList || getAvailableClientsForCategory();
    const container = document.getElementById('clientSelectionList');
    
    if (list.length === 0) {
        container.innerHTML = `<div style="padding: 24px; text-align: center; color: var(--color-text-muted);">No se encontraron clientes para el filtro o búsqueda actual.</div>`;
        updateModalSelectedCount();
        return;
    }

    let displayList = list;
    let noteHtml = '';
    if (list.length > 100 && !isSearch) {
        const top100 = list.slice(0, 100);
        const top100Cps = new Set(top100.map(c => c.cp_cliente));
        const selectedExtra = list.filter(c => state.selected.clients.includes(c.cp_cliente) && !top100Cps.has(c.cp_cliente));
        displayList = [...selectedExtra, ...top100];
        noteHtml = `<div style="padding: 6px 12px; margin-bottom: 8px; background: #ede9fe; color: #53459e; font-size: 0.74rem; border-radius: 6px; font-weight: 600;">
            <i class="fa-solid fa-circle-info"></i> Mostrando los primeros 100 de ${list.length} clientes categorizados. Escribe en el buscador para filtrar en tiempo real.
        </div>`;
    }

    container.innerHTML = noteHtml + displayList.map(c => {
        const isChecked = state.selected.clients.includes(c.cp_cliente);
        return `
            <label class="client-checkbox-item">
                <input type="checkbox" value="${escapeHtml(c.cp_cliente)}" ${isChecked ? 'checked' : ''} onchange="onModalClientCheckboxChange(this)">
                <div>
                    <strong>${c.cp_cliente}</strong>
                    ${c.zonabase ? `<span style="background: #ede9fe; color: #6a5cbc; font-size: 0.72rem; font-weight: 700; padding: 1px 6px; border-radius: 4px; margin-left: 6px; border: 1px solid #ddd6fe;">${escapeHtml(c.zonabase)}</span>` : ''}
                    ${c.quintil ? `<span class="badge-quintil ${c.quintil}" style="margin-left: 6px;">${c.quintil}</span>` : ''}
                    ${c.categorizacion ? `<span style="font-size:0.75rem; color:#64748b; margin-left:6px;">(${c.categorizacion})</span>` : ''}
                </div>
            </label>
        `;
    }).join('');

    updateModalSelectedCount();
}

let modalSearchDebounce = null;
function filterModalClients() {
    const term = document.getElementById('txtModalClientSearch').value.trim();
    if (!term) {
        renderModalClientList(getAvailableClientsForCategory());
        return;
    }

    clearTimeout(modalSearchDebounce);
    modalSearchDebounce = setTimeout(async () => {
        try {
            const params = new URLSearchParams({
                q: term,
                category: state.selected.quintil || '',
                zonaBase: state.selected.zonaBase || '',
                limit: '100'
            });
            const res = await fetch(`/api/search-clients?${params.toString()}`);
            const json = await res.json();
            if (json.success && Array.isArray(json.data)) {
                renderModalClientList(json.data);
            }
        } catch (e) {
            console.error("Modal search error:", e);
        }
    }, 250);
}

function onModalClientCheckboxChange(chk) {
    const val = chk.value;
    if (chk.checked) {
        if (!state.selected.clients.includes(val)) state.selected.clients.push(val);
    } else {
        state.selected.clients = state.selected.clients.filter(c => c !== val);
    }
    updateModalSelectedCount();
}

function selectTopClients(n) {
    const available = getAvailableClientsForCategory();
    state.selected.clients = available.slice(0, n).map(c => c.cp_cliente);
    renderModalClientList();
}

function selectAllModalClients(selectAll) {
    if (selectAll) {
        const available = getAvailableClientsForCategory();
        state.selected.clients = available.map(c => c.cp_cliente);
    } else {
        state.selected.clients = [];
    }
    renderModalClientList();
}

function updateModalSelectedCount() {
    const countEl = document.getElementById('modalSelectedCount');
    if (countEl) countEl.innerText = state.selected.clients.length;
}

function updateSelectedClientsBadge() {
    const badge = document.getElementById('selectedClientsCount');
    if (!badge) return;
    if (!state.selected.clients || state.selected.clients.length === 0) {
        badge.innerText = 'Todos';
    } else {
        badge.innerText = state.selected.clients.length;
    }
}

function applyClientSelection() {
    updateSelectedClientsBadge();
    closeClientModal();
    const countText = state.selected.clients.length === 0 ? "todos los clientes de la categoría" : `${state.selected.clients.length} clientes`;
    showToast(`Mostrando desglose para: ${countText}`, "info");
    loadMatrixData();
}

// ==========================================================================
// EXCEL EXPORT
// ==========================================================================
async function exportToExcel() {
    const btn = document.getElementById('btnExportExcel');
    const origHtml = btn.innerHTML;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Generando...';
    btn.disabled = true;

    try {
        const payload = {
            unidadMedida: state.unidadMedida,
            unidadNegocio: state.selected.unidadNegocio ? [state.selected.unidadNegocio] : [],
            franquicia: state.selected.franquicia ? [state.selected.franquicia] : [],
            marca: state.selected.marca ? [state.selected.marca] : [],
            categorizacion: state.selected.quintil ? [state.selected.quintil] : [],
            zonaBase: state.selected.zonaBase ? [state.selected.zonaBase] : [],
            selectedClients: state.selected.clients,
            search: state.selected.search
        };

        const response = await fetch('/api/export-excel', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!response.ok) throw new Error("Error en la descarga");

        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Construccion_de_Share_Medifarma_${state.unidadMedida}.xlsx`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);

        showToast("Archivo Excel descargado con éxito", "success");
    } catch (e) {
        console.error("Export error:", e);
        showToast("Error al generar el archivo Excel", "error");
    } finally {
        btn.innerHTML = origHtml;
        btn.disabled = false;
    }
}

// ==========================================================================
// UTILITIES & HELPERS
// ==========================================================================
function formatNumber(num, isCurrency = false) {
    if (num === null || num === undefined || isNaN(num)) return '0';
    const rounded = Math.round(num);
    const formatted = rounded.toLocaleString('es-PE');
    return isCurrency ? `S/ ${formatted}` : formatted;
}

function formatPercent(num) {
    if (num === null || num === undefined || isNaN(num)) return '0.0%';
    return (num * 100).toFixed(1) + '%';
}

function showLoading(show) {
    state.isLoading = show;
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.classList.toggle('active', show);
    }
}

function showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    if (!toast) return;

    const icons = {
        success: 'fa-solid fa-circle-check',
        error: 'fa-solid fa-circle-exclamation',
        info: 'fa-solid fa-circle-info'
    };

    toast.innerHTML = `<i class="${icons[type] || icons.info}"></i> <span>${message}</span>`;
    toast.className = `toast show ${type}`;

    setTimeout(() => {
        toast.className = 'toast';
    }, 3500);
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function filterRowsInDOM() {
    const term = state.selected.search.toLowerCase();
    const brandRows = document.querySelectorAll('tr.tr-brand');
    const skuRows = document.querySelectorAll('tr.tr-sku');

    if (!term) {
        brandRows.forEach(r => r.style.display = '');
        skuRows.forEach(r => {
            const parent = r.dataset.parentBrand;
            const isCollapsed = state.collapsedBrands.has(parent);
            r.style.display = isCollapsed ? 'none' : '';
        });
        return;
    }

    // Filter matching brands or SKUs
    brandRows.forEach(bRow => {
        const brand = bRow.dataset.brand.toLowerCase();
        const matchingSkus = Array.from(document.querySelectorAll(`tr.tr-sku[data-parent-brand="${CSS.escape(bRow.dataset.brand)}"]`))
            .filter(sRow => sRow.textContent.toLowerCase().includes(term));

        if (brand.includes(term) || matchingSkus.length > 0) {
            bRow.style.display = '';
            // Show matching skus
            matchingSkus.forEach(s => s.style.display = '');
        } else {
            bRow.style.display = 'none';
        }
    });
}

// ==========================================================================
// CLIENT DETAIL RECALCULATED MODAL (IMAGE 2 LAYOUT)
// ==========================================================================
const detailState = {
    client: null,
    unidadMedida: 'UNIDAD',
    data: null,
    sortBy: 'estimacion',
    sortDir: 'desc',
    collapsedBrands: new Set(),
    searchTerm: '',
    isLoading: false
};

async function openClientDetailModal(clientIdentifier) {
    const modal = document.getElementById('clientDetailModal');
    if (!modal) return;

    detailState.client = clientIdentifier;
    detailState.unidadMedida = state.unidadMedida;
    detailState.searchTerm = '';
    detailState.collapsedBrands.clear();
    detailState.sortBy = 'estimacion';
    detailState.sortDir = 'desc';

    const txtSearch = document.getElementById('txtDetailSearch');
    if (txtSearch) txtSearch.value = '';

    updateDetailUnitUI();
    modal.classList.add('active');

    await loadClientDetailData();
}
window.openClientDetailModal = openClientDetailModal;

function closeClientDetailModal() {
    const modal = document.getElementById('clientDetailModal');
    if (modal) modal.classList.remove('active');
}
window.closeClientDetailModal = closeClientDetailModal;

async function setDetailModalUnit(unit) {
    if (detailState.unidadMedida === unit) return;
    detailState.unidadMedida = unit;
    updateDetailUnitUI();
    await loadClientDetailData();
}
window.setDetailModalUnit = setDetailModalUnit;

function updateDetailUnitUI() {
    const isUnidad = detailState.unidadMedida === 'UNIDAD';
    const btnU = document.getElementById('btnDetailUnitUnidad');
    const btnS = document.getElementById('btnDetailUnitSoles');
    if (btnU) btnU.classList.toggle('active', isUnidad);
    if (btnS) btnS.classList.toggle('active', !isUnidad);

    const kpiUnitText = document.getElementById('detailKpiUnitText');
    if (kpiUnitText) kpiUnitText.innerText = isUnidad ? 'Unidades / mes' : 'Soles (S/) / mes';
}

async function loadClientDetailData() {
    showDetailLoading(true);
    try {
        const payload = {
            client: detailState.client,
            unidadMedida: detailState.unidadMedida,
            unidadNegocio: state.selected.unidadNegocio ? [state.selected.unidadNegocio] : [],
            franquicia: state.selected.franquicia ? [state.selected.franquicia] : [],
            marca: state.selected.marca ? [state.selected.marca] : [],
            search: ''
        };

        const res = await fetch('/api/client-matrix', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const json = await res.json();
        if (json.success && json.data) {
            detailState.data = json.data;
            renderDetailClientHeader();
            sortDetailData();
            renderDetailKPIs();
            renderDetailMatrix();
            updateDetailSortUI();
        } else {
            showToast("Error al cargar datos del cliente: " + (json.error || "Desconocido"), "error");
        }
    } catch (e) {
        console.error("Error cargando detalle cliente:", e);
        showToast("Error de conexión al obtener datos del cliente", "error");
    } finally {
        showDetailLoading(false);
    }
}

function showDetailLoading(show) {
    detailState.isLoading = show;
    const overlay = document.getElementById('detailLoadingOverlay');
    if (overlay) overlay.classList.toggle('active', show);
}

function renderDetailClientHeader() {
    if (!detailState.data || !detailState.data.client) return;
    const c = detailState.data.client;

    const elName = document.getElementById('detailClientName');
    if (elName) elName.innerText = c.farmacia || c.cp_cliente || detailState.client;

    const elRuc = document.getElementById('detailClientRUC');
    if (elRuc) elRuc.innerText = c.ruc || '-';

    const elQuintil = document.getElementById('detailClientQuintil');
    if (elQuintil) {
        elQuintil.innerText = c.categorizacion || c.quintil || 'Q1';
        elQuintil.className = `badge-quintil ${c.quintil || ''}`;
    }

    const elZone = document.getElementById('detailClientZone');
    const elZoneText = document.getElementById('detailClientZoneText');
    const elSup = document.getElementById('detailClientSupervisor');
    const elSupText = document.getElementById('detailClientSupervisorText');
    const elVend = document.getElementById('detailClientVendedores');
    const elVendText = document.getElementById('detailClientVendedoresText');

    if (elZone) {
        if (c.zonabase) {
            elZone.style.display = 'inline-flex';
            if (elZoneText) elZoneText.innerText = c.zonabase;
        } else if (c.lima_provincias) {
            elZone.style.display = 'inline-flex';
            if (elZoneText) elZoneText.innerText = c.lima_provincias;
        } else {
            elZone.style.display = 'none';
        }
    }

    if (elSup) {
        if (c.supervisor) {
            elSup.style.display = 'inline-flex';
            if (elSupText) elSupText.innerText = c.supervisor;
        } else {
            elSup.style.display = 'none';
        }
    }

    if (elVend) {
        if (c.vendedores && c.vendedores.length > 0) {
            elVend.style.display = 'inline-flex';
            if (elVendText) elVendText.innerText = c.vendedores.join(', ');
        } else {
            elVend.style.display = 'none';
        }
    }

    const elFooter = document.getElementById('detailFooterClientInfo');
    if (elFooter) {
        elFooter.innerHTML = `Desglose exclusivo para: <strong>${c.farmacia || c.cp_cliente}</strong>`;
    }
}

function renderDetailKPIs() {
    if (!detailState.data || !detailState.data.totals) return;
    const t = detailState.data.totals;
    const isSoles = detailState.unidadMedida === 'S/ SOLES';

    const elVtaAct = document.getElementById('detailKpiVtaAct');
    const elVtaMdo = document.getElementById('detailKpiVtaMdo');
    const elMsAct = document.getElementById('detailKpiMsAct');
    const elMsIdeal = document.getElementById('detailKpiMsIdeal');
    const elEst = document.getElementById('detailKpiEstimacion');

    if (elVtaAct) elVtaAct.innerText = formatNumber(t.vta_act, isSoles);
    if (elVtaMdo) elVtaMdo.innerText = formatNumber(t.vta_mdo, isSoles);
    if (elMsAct) elMsAct.innerText = formatPercent(t.ms_act);
    if (elMsIdeal) elMsIdeal.innerText = formatPercent(t.ms_ideal);
    if (elEst) elEst.innerText = formatNumber(t.estimacion, isSoles);
}

function sortDetailData() {
    if (!detailState.data || !detailState.data.brands) return;
    const field = detailState.sortBy;
    const dir = detailState.sortDir === 'asc' ? 1 : -1;

    detailState.data.brands.sort((a, b) => {
        if (field === 'marca') return dir * a.marca.localeCompare(b.marca);
        const valA = (a.distribuidoras && field in a.distribuidoras) ? Number(a.distribuidoras[field]) || 0 : Number(a[field]) || 0;
        const valB = (b.distribuidoras && field in b.distribuidoras) ? Number(b.distribuidoras[field]) || 0 : Number(b[field]) || 0;
        if (valA === valB) return a.marca.localeCompare(b.marca);
        return dir * (valA - valB);
    });

    detailState.data.brands.forEach(b => {
        if (b.skus && b.skus.length > 0) {
            b.skus.sort((sa, sb) => {
                if (field === 'marca') return dir * sa.sku.localeCompare(sb.sku);
                const valA = (sa.distribuidoras && field in sa.distribuidoras) ? Number(sa.distribuidoras[field]) || 0 : Number(sa[field]) || 0;
                const valB = (sb.distribuidoras && field in sb.distribuidoras) ? Number(sb.distribuidoras[field]) || 0 : Number(sb[field]) || 0;
                if (valA === valB) return sa.sku.localeCompare(sb.sku);
                return dir * (valA - valB);
            });
        }
    });
}

function toggleDetailSort(field) {
    if (detailState.sortBy === field) {
        detailState.sortDir = detailState.sortDir === 'asc' ? 'desc' : 'asc';
    } else {
        detailState.sortBy = field;
        detailState.sortDir = field === 'marca' ? 'asc' : 'desc';
    }
    sortDetailData();
    updateDetailSortUI();
    renderDetailMatrix();
}
window.toggleDetailSort = toggleDetailSort;

function updateDetailSortUI() {
    const allIcons = document.querySelectorAll('[id^="detailSortIcon_"]');
    allIcons.forEach(icon => {
        icon.className = 'fa-solid fa-sort sort-icon';
    });

    // Escape special characters in id selector if field is a distributor name
    const safeId = `detailSortIcon_${detailState.sortBy}`.replace(/["\\]/g, '\\$&');
    const activeIcon = document.getElementById(`detailSortIcon_${detailState.sortBy}`) || document.querySelector(`[id="${safeId}"]`);
    if (activeIcon) {
        if (detailState.sortDir === 'asc') {
            activeIcon.className = 'fa-solid fa-sort-up sort-icon active';
        } else {
            activeIcon.className = 'fa-solid fa-sort-down sort-icon active';
        }
    }
}

function renderDetailMatrix() {
    if (!detailState.data) return;
    const brands = detailState.data.brands || [];
    const totals = detailState.data.totals || {};
    const distributors = detailState.data.distributors || [];
    const isSoles = detailState.unidadMedida === 'S/ SOLES';
    const term = (detailState.searchTerm || '').toLowerCase().trim();

    const elCountBadge = document.getElementById('detailBrandCountBadge');
    const elBrandCount = document.getElementById('detailBrandCount');
    if (elCountBadge) elCountBadge.innerText = `${brands.length} marcas`;
    if (elBrandCount) elBrandCount.innerText = `${brands.length} marcas`;

    // Render Table Header dynamically
    const thead = document.getElementById('detailTableHead');
    if (thead) {
        let distribHeaderTop = '';
        let distribHeadersSub = '';
        if (distributors.length > 0) {
            distribHeaderTop = `
                <th class="th-distrib-header" colspan="${distributors.length}" style="background:#1d252d; color:#38bdf8; text-align:center; font-weight:800; border-left:2px solid #334155; padding:8px; font-size:0.75rem; text-transform:uppercase; letter-spacing:0.5px;">
                    COMPRAS POR DISTRIBUIDOR (PROM. MENSUAL ENE-MAY 2026)
                </th>
            `;
            distribHeadersSub = distributors.map(d => `
                <th class="th-metric th-sortable" style="background:#2b353f; color:#fff; text-align:right; min-width:140px; font-size:0.68rem; padding:8px 6px; border-right:1px solid #475569;" title="${escapeHtml(d)}" onclick="toggleDetailSort('${escapeHtml(d)}')">
                    ${escapeHtml(d)} <i class="fa-solid fa-sort sort-icon" id="detailSortIcon_${escapeHtml(d)}"></i>
                </th>
            `).join('');
        }

        thead.innerHTML = `
            <tr class="header-level-1">
                <th class="th-sticky th-row-label th-sortable" rowspan="2" onclick="toggleDetailSort('marca')">
                    <div class="th-content">
                        <span>Etiquetas de fila <i class="fa-solid fa-sort sort-icon" id="detailSortIcon_marca"></i></span>
                        <span class="badge-count" id="detailBrandCountBadge">${brands.length} marcas</span>
                    </div>
                </th>
                <th class="th-share-header" colspan="7">
                    ANÁLISIS DE Pedidos Sugeridos
                </th>
                ${distribHeaderTop}
            </tr>
            <tr class="header-level-2">
                <th class="th-metric th-sortable" onclick="toggleDetailSort('vta_act')">
                    VTA. ACT. <i class="fa-solid fa-sort sort-icon" id="detailSortIcon_vta_act"></i>
                </th>
                <th class="th-metric th-sortable" onclick="toggleDetailSort('vta_mdo')">
                    VTA. MDO. <i class="fa-solid fa-sort sort-icon" id="detailSortIcon_vta_mdo"></i>
                </th>
                <th class="th-metric th-sortable" onclick="toggleDetailSort('ms_act')">
                    MS. ACT. <i class="fa-solid fa-sort sort-icon" id="detailSortIcon_ms_act"></i>
                </th>
                <th class="th-metric th-sortable" onclick="toggleDetailSort('ms_ant')">
                    MS. ANT. <i class="fa-solid fa-sort sort-icon" id="detailSortIcon_ms_ant"></i>
                </th>
                <th class="th-metric th-sortable" onclick="toggleDetailSort('ms_territorio')">
                    MS. TERRITORIO <i class="fa-solid fa-sort sort-icon" id="detailSortIcon_ms_territorio"></i>
                </th>
                <th class="th-metric th-ideal th-sortable" onclick="toggleDetailSort('ms_ideal')">
                    MS. IDEAL <i class="fa-solid fa-sort sort-icon" id="detailSortIcon_ms_ideal"></i>
                </th>
                <th class="th-metric th-estimacion th-sortable" style="border-right:2px solid #334155;" onclick="toggleDetailSort('estimacion')">
                    ESTIMACION <i class="fa-solid fa-sort sort-icon" id="detailSortIcon_estimacion"></i>
                </th>
                ${distribHeadersSub}
            </tr>
        `;
    }

    const tbody = document.getElementById('detailTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';

    let visibleCount = 0;

    brands.forEach(b => {
        const brandMatch = !term || b.marca.toLowerCase().includes(term);
        const matchingSkus = (b.skus || []).filter(s => !term || s.sku.toLowerCase().includes(term));
        if (!brandMatch && matchingSkus.length === 0) return;

        visibleCount++;
        const isCollapsed = detailState.collapsedBrands.has(b.marca);
        const skuCount = (b.skus || []).length;

        // Distrib cells for Brand
        const distribBrandCells = distributors.map(d => {
            const val = (b.distribuidoras && b.distribuidoras[d]) || 0;
            return `<td style="text-align:right; font-weight:700; color:#1e293b; background:#f8fafc; border-right:1px solid #e2e8f0;">${val > 0 ? formatNumber(val, isSoles) : '-'}</td>`;
        }).join('');

        // Brand Row
        const trBrand = document.createElement('tr');
        trBrand.className = 'tr-brand';
        trBrand.dataset.brand = b.marca;
        trBrand.innerHTML = `
            <td class="td-sticky">
                <div class="brand-cell-content" onclick="toggleDetailBrand('${escapeHtml(b.marca)}')">
                    <span class="toggle-icon"><i class="fa-solid ${isCollapsed ? 'fa-plus' : 'fa-minus'}"></i></span>
                    <span class="brand-name">${b.marca}</span>
                    ${b.franquicia && b.franquicia !== 'RESTO' ? `<span style="font-size:0.7rem; color:#64748b; font-weight:normal;">(${b.franquicia})</span>` : ''}
                    <span class="brand-sku-badge">${skuCount} SKU${skuCount !== 1 ? 's' : ''}</span>
                </div>
            </td>
            <td style="text-align:right;">${formatNumber(b.vta_act, isSoles)}</td>
            <td style="text-align:right;">${formatNumber(b.vta_mdo, isSoles)}</td>
            <td style="text-align:right;">${formatPercent(b.ms_act)}</td>
            <td style="text-align:right;">${formatPercent(b.ms_ant)}</td>
            <td style="text-align:right;">${formatPercent(b.ms_territorio)}</td>
            <td class="col-ideal" style="text-align:right;">${formatPercent(b.ms_ideal)}</td>
            <td class="col-estimacion" style="text-align:right; border-right:2px solid #cbd5e1;">${formatNumber(b.estimacion, isSoles)}</td>
            ${distribBrandCells}
        `;
        tbody.appendChild(trBrand);

        // SKU Rows
        (b.skus || []).forEach(s => {
            const skuMatch = !term || s.sku.toLowerCase().includes(term);
            if (term && !brandMatch && !skuMatch) return;

            const distribSkuCells = distributors.map(d => {
                const val = (s.distribuidoras && s.distribuidoras[d]) || 0;
                return `<td style="text-align:right; color:#64748b; background:#fff; border-right:1px solid #f1f5f9;">${val > 0 ? formatNumber(val, isSoles) : '-'}</td>`;
            }).join('');

            const trSku = document.createElement('tr');
            trSku.className = `tr-sku ${isCollapsed ? 'collapsed' : ''}`;
            trSku.dataset.parentBrand = b.marca;
            trSku.innerHTML = `
                <td class="td-sticky" title="${s.sku}">
                    <span class="sku-text">${s.sku}</span>
                </td>
                <td style="text-align:right;">${formatNumber(s.vta_act, isSoles)}</td>
                <td style="text-align:right;">${formatNumber(s.vta_mdo, isSoles)}</td>
                <td style="text-align:right;">${formatPercent(s.ms_act)}</td>
                <td style="text-align:right;">${formatPercent(s.ms_ant)}</td>
                <td style="text-align:right;">${formatPercent(s.ms_territorio)}</td>
                <td class="col-ideal" style="text-align:right;">${formatPercent(s.ms_ideal)}</td>
                <td class="col-estimacion" style="text-align:right; border-right:2px solid #e2e8f0;">${formatNumber(s.estimacion, isSoles)}</td>
                ${distribSkuCells}
            `;
            tbody.appendChild(trSku);
        });
    });

    const totalCols = 8 + distributors.length;
    if (visibleCount === 0) {
        tbody.innerHTML = `<tr><td colspan="${totalCols}" style="padding: 32px; text-align: center; color: var(--color-text-muted);">No se encontraron marcas para este cliente con el filtro actual.</td></tr>`;
    }

    // Total Footer Row
    const tfoot = document.getElementById('detailTableFoot');
    if (tfoot) {
        const distribTotalCells = distributors.map(d => {
            const val = (totals.distribuidoras && totals.distribuidoras[d]) || 0;
            return `<td style="text-align:right; background:#1d252d; color:#38bdf8; font-weight:800; border-right:1px solid rgba(255,255,255,0.1);">${formatNumber(val, isSoles)}</td>`;
        }).join('');

        tfoot.innerHTML = `
            <tr>
                <td class="td-sticky" style="background:#1d252d; color:#fff; font-weight:800;">TOTAL GENERAL</td>
                <td style="text-align:right; background:#2b353f; color:#fff;">${formatNumber(totals.vta_act, isSoles)}</td>
                <td style="text-align:right; background:#2b353f; color:#cbd5e1;">${formatNumber(totals.vta_mdo, isSoles)}</td>
                <td style="text-align:right; background:#2b353f; color:#38bdf8; font-weight:700;">${formatPercent(totals.ms_act)}</td>
                <td style="text-align:right; background:#2b353f; color:#cbd5e1;">${formatPercent(totals.ms_ant)}</td>
                <td style="text-align:right; background:#2b353f; color:#cbd5e1;">${formatPercent(totals.ms_territorio)}</td>
                <td class="col-ideal" style="text-align:right; background:#2b353f; color:#fff;">${formatPercent(totals.ms_ideal)}</td>
                <td class="col-estimacion" style="text-align:right; background:#2b353f; color:#38bdf8; font-weight:900; border-right:2px solid #475569;">${formatNumber(totals.estimacion, isSoles)}</td>
                ${distribTotalCells}
            </tr>
        `;
    }
}

function toggleDetailBrand(brandName) {
    if (detailState.collapsedBrands.has(brandName)) {
        detailState.collapsedBrands.delete(brandName);
    } else {
        detailState.collapsedBrands.add(brandName);
    }
    renderDetailMatrix();
}
window.toggleDetailBrand = toggleDetailBrand;

function expandAllDetail(expand) {
    if (expand) {
        detailState.collapsedBrands.clear();
    } else {
        if (detailState.data && detailState.data.brands) {
            detailState.data.brands.forEach(b => detailState.collapsedBrands.add(b.marca));
        }
    }
    renderDetailMatrix();
}
window.expandAllDetail = expandAllDetail;

let detailSearchDebounce = null;
function onDetailSearchInput() {
    clearTimeout(detailSearchDebounce);
    detailSearchDebounce = setTimeout(() => {
        const txt = document.getElementById('txtDetailSearch');
        detailState.searchTerm = txt ? txt.value.trim() : '';
        renderDetailMatrix();
    }, 150);
}
window.onDetailSearchInput = onDetailSearchInput;

