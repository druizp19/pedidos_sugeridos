# Validación local — 16 octubre 2026

## Refactorización del frontend

- 18 pruebas correctas: se añadieron contratos HTTP, filtros, ordenamiento sin mutaciones, exportación y límites de dependencias.
- TypeScript y compilación de producción correctos.
- Revisión en navegador: matriz con datos reales, búsqueda por RUC, casilla y aplicación de selección, detalle del cliente, versión pendiente y temas claro/oscuro.
- Revisión de distribución a 1440 px y 390 px. Ajustados contraste de encabezados y tarjetas compactas en el detalle.
- Corregido el doble cambio de selección al pulsar una casilla dentro de la fila del cliente.
- La guía de implementación está en `frontend/ARQUITECTURA.md`.

## Validación previa del modelo

- Compilación de producción Next.js y TypeScript: correcta.
- 11 pruebas automáticas: correctas (fórmulas, divisores, mercados compartidos, validación, cola y caché).
- SQL real: lectura de V1 desde DTM_PEDIDOS_SUGERIDOS, sin modificar tablas ni ejecutar cargas.
- Matriz general: 347 grupos de marca, 8 columnas iniciales de clientes.
- Cliente 20481921491: venta propia mensual 52,061.2 y mercado mensual 360,738.6; contrastados con una consulta SQL independiente. Distribuidores: 51,543.2 y 518 unidades mensuales.
- Excel del cliente: archivo válido, una hoja, 1,322 filas y 12 columnas.
- V2 sin resumen: API devuelve HTTP 400 y la interfaz la muestra pendiente.
- 50 solicitudes simultáneas idénticas con caché: 50 respuestas correctas. Esto no equivale a 50 consultas distintas contra SQL.
- Primera consulta general observada: aproximadamente 21 segundos; detalle: entre 2.7 y 12 segundos dependiendo del estado de la caché.

Pendiente antes de la puesta en servicio: conciliación funcional con BI sobre la misma carga y prueba de concurrencia con consultas distintas en el servidor definitivo. Los importes del cliente difieren de la captura del legado; no se certifica equivalencia entre cargas diferentes.

Por solicitud del usuario, esta entrega funciona localmente sin integración con Ecosistema. El equipo que integra los proyectos incorporará el acceso del portal posteriormente.
