import os
import sys
import json
import time
from pathlib import Path
from dotenv import load_dotenv

# Cargar variables de entorno desde la raíz del proyecto
root_dir = Path(__file__).resolve().parent.parent
env_path = root_dir / '.env'
if env_path.exists():
    load_dotenv(env_path)
else:
    load_dotenv()

DB_SERVER = os.getenv('DB_SERVER', '172.17.2.181')
DB_PORT = os.getenv('DB_PORT', '1433')
DB_NAME = os.getenv('DB_NAME', 'VW_FR')
DB_USER = os.getenv('DB_USER', '')
DB_PASSWORD = os.getenv('DB_PASSWORD', '')

CACHE = {
    'filters': None,
    'client_map': {},
    'query_cache': {},        # cache_key -> {'skus': [], 'brands': [], 'totals': {}}
    'client_query_cache': {}, # (client_id, unit, un, fr, ma) -> client_matrix_data
    'purchases': {},          # (unit, tuple(clients)) -> (p_set, b_set)
    'territory_cache': {},    # (metrica_sql, lima_provincias) -> {'sku': {}, 'brand': {}, 'total': float}
}

def get_db_connection():
    """Establece conexión a SQL Server usando pymssql (Linux/Win) o pyodbc como fallback"""
    if not DB_USER or not DB_PASSWORD:
        raise ValueError("DB_USER o DB_PASSWORD estan vacios en el archivo .env. Por favor completa tus credenciales.")

    # 1. Intentar con pymssql
    try:
        import pymssql
        return pymssql.connect(
            server=DB_SERVER,
            port=str(DB_PORT),
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME,
            timeout=60,
            login_timeout=15,
            charset='UTF-8'
        )
    except ImportError:
        pass

    # 2. Fallback con pyodbc (habitual en entornos Windows)
    try:
        import pyodbc
        drivers = [d for d in pyodbc.drivers() if 'SQL Server' in d]
        driver_name = drivers[0] if drivers else 'ODBC Driver 17 for SQL Server'
        conn_str = f"DRIVER={{{driver_name}}};SERVER={DB_SERVER},{DB_PORT};DATABASE={DB_NAME};UID={DB_USER};PWD={DB_PASSWORD}"
        return pyodbc.connect(conn_str, timeout=15)
    except ImportError:
        pass

    raise ImportError("No se encontro 'pymssql' ni 'pyodbc'. Por favor ejecuta: pip install pymssql")

def fetch_all_dict(cursor):
    """Convierte los resultados del cursor en una lista de diccionarios"""
    cols = [col[0] for col in cursor.description]
    rows = cursor.fetchall()
    return [dict(zip(cols, row)) for row in rows]

def escape_sql_str(val):
    """Escapa comillas simples para strings SQL"""
    if val is None:
        return "''"
    return "'" + str(val).replace("'", "''") + "'"

ORDERED_ZONAS = [
    "Ax01 - Lima Norte 1",
    "Ax02 - Lima Norte 2",
    "Ax03 - Lima Norte 3 (SMP - Rímac)",
    "Ax04 - Callao - Lima Oeste",
    "Ax05 - Lima Este (SJL)",
    "Ax06 - Lima Centro (Capón)",
    "Ax07 - Lima Este (Ate - Chosica)",
    "Ax08 - Lima Centro - Este",
    "Ax09 - Lima Moderna / Top - Sur",
    "Ax10 - Lima Sur - Playas",
    "A021 - Piura - Tumbes",
    "A022 - Chiclayo 1 (Jaén)",
    "A023 - Chiclayo 2 (Costa)",
    "A024 - Cajamarca",
    "A025 - Trujillo 1 (Costa)",
    "A026 - Trujillo 2 (Sierra)",
    "A027 - Norte Chico - Huaraz",
    "A028 - Sur Chico (Ica - Cañete)",
    "A029 - Arequipa 1 (Costa)",
    "A030 - Arequipa 2 (Camaná)",
    "A031 - Arequipa 3 (Majes)",
    "A032 - Arequipa 4 (Aplao)",
    "A033 - Tacna - Moquegua",
    "A034 - Cusco 1 (Apurímac)",
    "A035 - Cusco 2 (Valle / Ciudad)",
    "A036 - Cusco 3 (Madre de Dios)",
    "A037 - Puno - Juliaca",
    "A038 - Ayacucho",
    "A039 - Huancayo - Centro",
    "A040 - Pasco - Junín",
    "A041 - Huánuco - Tingo María",
    "A042 - San Martín - Yurimaguas",
    "A043 - Iquitos",
    "A044 - Pucallpa"
]

def load_filters():
    """Obtiene todas las opciones de filtro desde las tablas de dimensiones"""
    if CACHE['filters']:
        return CACHE['filters']

    conn = get_db_connection()
    try:
        cursor = conn.cursor()

        # 1. Jerarquía de Materiales
        q_mat = """
        SELECT DISTINCT
            unidad_negocio,
            franquicia,
            marca_mkt
        FROM dbo.DIM_MATERIAL
        WHERE es_competidor = 0 
          AND marca_mkt IS NOT NULL 
          AND marca_mkt <> ''
          AND marca_mkt <> 'COMPETIDORES'
        ORDER BY unidad_negocio, franquicia, marca_mkt;
        """
        cursor.execute(q_mat)
        mat_rows = fetch_all_dict(cursor)

        unidades_negocio = sorted(list(set(r['unidad_negocio'] for r in mat_rows if r.get('unidad_negocio'))))
        franquicias = sorted(list(set(r['franquicia'] for r in mat_rows if r.get('franquicia'))))
        marcas = sorted(list(set(r['marca_mkt'] for r in mat_rows if r.get('marca_mkt'))))

        # 2. Vendedores y Supervisores (desde dbo.vendedores)
        vendedores_map = {}
        try:
            cursor.execute("SELECT zonaBase, nombreFFVV, nombreSSVV FROM dbo.vendedores")
            vend_rows = fetch_all_dict(cursor)
            for r in vend_rows:
                zb = str(r.get('zonaBase') or '').strip()
                ffvv = str(r.get('nombreFFVV') or '').strip()
                ssvv = str(r.get('nombreSSVV') or '').strip()
                code = zb.split(' - ')[0].strip() if ' - ' in zb else zb
                for k in [zb, code]:
                    if k:
                        if k not in vendedores_map:
                            vendedores_map[k] = {'ffvv': [], 'ssvv': ssvv}
                        if ffvv and ffvv not in vendedores_map[k]['ffvv']:
                            vendedores_map[k]['ffvv'].append(ffvv)
                        if ssvv and not vendedores_map[k]['ssvv']:
                            vendedores_map[k]['ssvv'] = ssvv
        except Exception as e:
            print("Error loading dbo.vendedores:", e)

        # 3. Supervisores desde DIM_CLIENTE
        q_sup = """
        SELECT DISTINCT supervisor
        FROM dbo.DIM_CLIENTE
        WHERE supervisor IS NOT NULL AND LTRIM(RTRIM(supervisor)) <> ''
        ORDER BY supervisor;
        """
        cursor.execute(q_sup)
        sup_rows = fetch_all_dict(cursor)
        supervisores = [r['supervisor'].strip() for r in sup_rows if r.get('supervisor') and r['supervisor'].strip()]

        # 4. Clientes con Categorización (para evitar sobrecarga de red y navegador)
        q_cli = """
        SELECT 
            ruc,
            farmacia,
            cp_cliente,
            categorizacion,
            quintil,
            zonabase,
            supervisor
        FROM dbo.DIM_CLIENTE
        WHERE categorizacion IN ('DIAMANTE', 'ORO', 'PLATA', 'BRONCE', 'PLOMO')
        ORDER BY 
            CASE quintil 
                WHEN 'Q1' THEN 1 
                WHEN 'Q2' THEN 2 
                WHEN 'Q3' THEN 3 
                WHEN 'Q4' THEN 4 
                WHEN 'Q5' THEN 5 
                ELSE 6 
            END,
            cp_cliente;
        """
        cursor.execute(q_cli)
        cli_rows = fetch_all_dict(cursor)

        categorizaciones = ["DIAMANTE", "ORO", "PLATA", "BRONCE", "PLOMO", "SIN CATEGORIZACION"]
        quintiles = ["Q1", "Q2", "Q3", "Q4", "Q5"]

        clients_list = []
        client_map = {}
        for c in cli_rows:
            cp = c.get('cp_cliente')
            if cp:
                zb = str(c.get('zonabase') or '').strip()
                v_info = vendedores_map.get(zb) or vendedores_map.get(zb.split(' - ')[0]) or {}
                obj = {
                    'ruc': str(c.get('ruc') or ''),
                    'farmacia': str(c.get('farmacia') or ''),
                    'cp_cliente': cp,
                    'categorizacion': c.get('categorizacion') or 'SIN CATEGORIZACION',
                    'quintil': c.get('quintil') or '',
                    'zonabase': zb,
                    'supervisor': str(c.get('supervisor') or v_info.get('ssvv') or '').strip(),
                    'vendedores': v_info.get('ffvv', [])
                }
                clients_list.append(obj)
                client_map[cp] = obj

        filters = {
            'unidades_negocio': unidades_negocio,
            'franquicias': franquicias,
            'marcas': marcas,
            'categorizaciones': categorizaciones,
            'quintiles': quintiles,
            'supervisores': supervisores,
            'zonas_base': ORDERED_ZONAS,
            'vendedores_map': vendedores_map,
            'clients': clients_list,
            'units': ['UNIDAD', 'S/ SOLES'],
            'periodo': 'Enero 2026 - Mayo 2026'
        }

        CACHE['filters'] = filters
        CACHE['client_map'] = client_map
        CACHE['vendedores_map'] = vendedores_map
        return filters
    finally:
        conn.close()

def get_vendor_info(zona_base):
    """Retorna los nombres de vendedores (FFVV) y supervisor (SSVV) para una zonaBase dada sin duplicar filas"""
    if not zona_base:
        return {'ffvv': [], 'ssvv': ''}
    v_map = CACHE.get('vendedores_map') or {}
    zb_str = str(zona_base).strip()
    code = zb_str.split(' - ')[0].strip() if ' - ' in zb_str else zb_str
    return v_map.get(zb_str) or v_map.get(code) or {'ffvv': [], 'ssvv': ''}

def search_clients_db(query="", category=None, zona_base=None, supervisor=None, limit=50):
    """Busca clientes en dbo.DIM_CLIENTE bajo demanda cuando el usuario escribe en el buscador"""
    q_str = (query or "").strip().replace("'", "''")
    if not q_str and not category and not zona_base and not supervisor:
        return []

    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        where_parts = []
        if q_str:
            where_parts.append(f"(cp_cliente LIKE '%{q_str}%' OR ruc LIKE '%{q_str}%' OR farmacia LIKE '%{q_str}%')")

        if category:
            cat_map = {'Q1': 'DIAMANTE', 'Q2': 'ORO', 'Q3': 'PLATA', 'Q4': 'BRONCE', 'Q5': 'PLOMO'}
            cat_target = cat_map.get(category, category)
            where_parts.append(f"(categorizacion = '{cat_target}' OR quintil = '{category}')")

        if zona_base:
            zb = zona_base[0] if isinstance(zona_base, (list, tuple)) else zona_base
            if zb and zb.strip():
                zb_clean = zb.strip().replace("'", "''")
                zb_code = zb_clean.split(' - ')[0].strip()
                where_parts.append(f"(zonabase = '{zb_clean}' OR zonabase = '{zb_code}')")

        if supervisor:
            sup = supervisor[0] if isinstance(supervisor, (list, tuple)) else supervisor
            if sup and sup.strip():
                sup_clean = sup.strip().replace("'", "''")
                where_parts.append(f"supervisor = '{sup_clean}'")

        where_clause = "WHERE " + " AND ".join(where_parts) if where_parts else ""

        sql = f"""
        SELECT TOP {int(limit)}
            ruc,
            farmacia,
            cp_cliente,
            categorizacion,
            quintil,
            zonabase,
            supervisor
        FROM dbo.DIM_CLIENTE
        {where_clause}
        ORDER BY 
            CASE quintil 
                WHEN 'Q1' THEN 1 
                WHEN 'Q2' THEN 2 
                WHEN 'Q3' THEN 3 
                WHEN 'Q4' THEN 4 
                WHEN 'Q5' THEN 5 
                ELSE 6 
            END,
            cp_cliente;
        """
        cursor.execute(sql)
        rows = fetch_all_dict(cursor)
        res = []
        for c in rows:
            cp = c.get('cp_cliente')
            if cp:
                zb = str(c.get('zonabase') or '').strip()
                v_info = get_vendor_info(zb)
                obj = {
                    'ruc': str(c.get('ruc') or ''),
                    'farmacia': str(c.get('farmacia') or ''),
                    'cp_cliente': cp,
                    'categorizacion': c.get('categorizacion') or 'SIN CATEGORIZACION',
                    'quintil': c.get('quintil') or '',
                    'zonabase': zb,
                    'supervisor': str(c.get('supervisor') or v_info.get('ssvv') or '').strip(),
                    'vendedores': v_info.get('ffvv', [])
                }
                res.append(obj)
                CACHE['client_map'][cp] = obj
        return res
    except Exception as e:
        print("Search clients error:", e)
        return []
    finally:
        conn.close()

def get_clients_by_ids(client_cps):
    """Recupera información de clientes específicos desde dbo.DIM_CLIENTE"""
    if not client_cps:
        return []
    
    # Check cache first
    missing = [cp for cp in client_cps if cp not in CACHE['client_map']]
    if not missing:
        return [CACHE['client_map'][cp] for cp in client_cps if cp in CACHE['client_map']]
        
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cps_in = ", ".join([escape_sql_str(cp) for cp in missing])
        cursor.execute(f"""
            SELECT ruc, farmacia, cp_cliente, categorizacion, quintil, zonabase, supervisor
            FROM dbo.DIM_CLIENTE
            WHERE cp_cliente IN ({cps_in}) OR ruc IN ({cps_in})
        """)
        rows = fetch_all_dict(cursor)
        for c in rows:
            cp = c.get('cp_cliente')
            if cp:
                zb = str(c.get('zonabase') or '').strip()
                v_info = get_vendor_info(zb)
                obj = {
                    'ruc': str(c.get('ruc') or ''),
                    'farmacia': str(c.get('farmacia') or ''),
                    'cp_cliente': cp,
                    'categorizacion': c.get('categorizacion') or 'SIN CATEGORIZACION',
                    'quintil': c.get('quintil') or '',
                    'zonabase': zb,
                    'supervisor': str(c.get('supervisor') or v_info.get('ssvv') or '').strip(),
                    'vendedores': v_info.get('ffvv', [])
                }
                CACHE['client_map'][cp] = obj
        return [CACHE['client_map'][cp] for cp in client_cps if cp in CACHE['client_map']]
    except Exception as e:
        print("get_clients_by_ids error:", e)
        return []
    finally:
        conn.close()

def get_filters_data():
    return load_filters()

def load_client_purchases(unit, client_cps):
    """Carga flags de compra para los clientes seleccionados en Ene-May 2026"""
    if not client_cps:
        return set(), set()

    cache_k = (unit, tuple(sorted(client_cps)))
    if cache_k in CACHE['purchases']:
        return CACHE['purchases'][cache_k]

    p_set = set()
    b_set = set()

    metrica_sql = 'VALOR' if 'SOL' in (unit or '').upper() else 'UNIDAD'
    cli_in = ", ".join([escape_sql_str(c) for c in client_cps])

    q_purchases = f"""
    SELECT DISTINCT
        c.cp_cliente,
        m.cp_presentacion,
        m.marca_mkt
    FROM dbo.FACT_VENTAS_AGREGADA f
    INNER JOIN dbo.DIM_MATERIAL m ON f.codigo_presentacion = m.codigo_presentacion
    INNER JOIN dbo.DIM_CLIENTE c ON f.ruc = c.ruc
    WHERE f.metrica = '{metrica_sql}'
      AND c.cp_cliente IN ({cli_in})
      AND f.vta_actual > 0
      AND m.es_competidor = 0;
    """

    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(q_purchases)
        rows = fetch_all_dict(cursor)
        for r in rows:
            c = r.get('cp_cliente')
            p = r.get('cp_presentacion')
            m = r.get('marca_mkt')
            if c and p:
                p_set.add((c, p))
            if c and m:
                b_set.add((c, m))
    except Exception as e:
        print("Purchases load error:", e)
    finally:
        conn.close()

    CACHE['purchases'][cache_k] = (p_set, b_set)
    return p_set, b_set

def query_sql_matrix(unidad_medida, unidad_negocio, franquicia, marca, categorizacion, zona_base=None, supervisor=None):
    """
    Ejecuta el cálculo de la matriz en SQL Server calculando ventas, mercados,
    Market Share actual/anterior/territorio, Recupero MS y Estimación mensual.
    """
    metrica_sql = 'VALOR' if 'SOL' in (unidad_medida or '').upper() else 'UNIDAD'

    cat_map = {'Q1': 'DIAMANTE', 'Q2': 'ORO', 'Q3': 'PLATA', 'Q4': 'BRONCE', 'Q5': 'PLOMO'}
    norm_cats = []
    if categorizacion:
        for cat in categorizacion:
            if cat:
                norm_cats.append(cat_map.get(cat, cat))

    # Filtro de clientes por categorización, zona base y supervisor
    cli_filters = []
    if norm_cats:
        cats_in = ", ".join([escape_sql_str(c) for c in norm_cats])
        cli_filters.append(f"c.categorizacion IN ({cats_in})")

    if zona_base:
        if isinstance(zona_base, (list, tuple)):
            zb_list = [z.strip() for z in zona_base if z and z.strip()]
            if zb_list:
                zb_clauses = []
                for z in zb_list:
                    z_code = z.split(' - ')[0].strip()
                    zb_clauses.append(f"c.zonabase = {escape_sql_str(z)} OR c.zonabase = {escape_sql_str(z_code)}")
                cli_filters.append(f"({' OR '.join(zb_clauses)})")
        elif isinstance(zona_base, str) and zona_base.strip():
            z_val = zona_base.strip()
            z_code = z_val.split(' - ')[0].strip()
            cli_filters.append(f"(c.zonabase = {escape_sql_str(z_val)} OR c.zonabase = {escape_sql_str(z_code)})")

    if supervisor:
        if isinstance(supervisor, (list, tuple)):
            sup_list = [s.strip() for s in supervisor if s and s.strip()]
            if sup_list:
                sup_in = ", ".join([escape_sql_str(s) for s in sup_list])
                cli_filters.append(f"c.supervisor IN ({sup_in})")
        elif isinstance(supervisor, str) and supervisor.strip():
            cli_filters.append(f"c.supervisor = {escape_sql_str(supervisor.strip())}")

    where_cli = ("AND " + " AND ".join(cli_filters)) if cli_filters else ""

    # Filtro de materiales visibles
    mat_filters = []
    if unidad_negocio and len(unidad_negocio) > 0:
        un_in = ", ".join([escape_sql_str(u) for u in unidad_negocio if u])
        if un_in:
            mat_filters.append(f"b.unidad_negocio IN ({un_in})")

    if franquicia and len(franquicia) > 0:
        fr_in = ", ".join([escape_sql_str(f) for f in franquicia if f])
        if fr_in:
            mat_filters.append(f"b.franquicia IN ({fr_in})")

    if marca and len(marca) > 0:
        ma_in = ", ".join([escape_sql_str(m) for m in marca if m])
        if ma_in:
            mat_filters.append(f"b.marca_mkt IN ({ma_in})")

    where_mat_brand = ("AND " + " AND ".join(mat_filters)) if mat_filters else ""
    where_mat_clean = where_mat_brand.replace('b.', '')
    where_mat_vt = where_mat_brand.replace('b.', 'vt.')

    q_matrix = f"""
    WITH 
    -- 1. Zonas presentes en el filtro de clientes seleccionados
    ZONAS_ACTUALES AS (
        SELECT DISTINCT c.lima_provincias
        FROM dbo.DIM_CLIENTE c
        WHERE 1=1 {where_cli}
    ),
    -- 2. Base filtrada por clientes seleccionados
    BASE_CLIENTES AS (
        SELECT c.ruc, c.lima_provincias, c.categorizacion
        FROM dbo.DIM_CLIENTE c
        WHERE 1=1 {where_cli}
    ),
    BASE_VENTAS AS (
        SELECT 
            f.codigo_presentacion,
            f.ruc,
            m.cp_presentacion,
            m.unidad_negocio,
            m.franquicia,
            m.marca_mkt,
            m.mercado,
            m.es_competidor,
            c.lima_provincias,
            f.vta_actual,
            f.vta_anterior
        FROM dbo.FACT_VENTAS_AGREGADA f
        INNER JOIN dbo.DIM_MATERIAL m ON f.codigo_presentacion = m.codigo_presentacion
        INNER JOIN BASE_CLIENTES c ON f.ruc = c.ruc
        WHERE f.metrica = '{metrica_sql}'
    ),
    -- Mercado Total por Mercado/Categoría en los clientes filtrados
    TOTAL_MERCADO AS (
        SELECT 
            mercado,
            SUM(vta_actual) AS mdo_actual,
            SUM(vta_anterior) AS mdo_anterior
        FROM BASE_VENTAS
        GROUP BY mercado
    ),
    -- Mercado Total por Marca en los clientes filtrados
    MERCADO_MARCA AS (
        SELECT 
            b.unidad_negocio,
            b.franquicia,
            b.marca_mkt,
            SUM(tm.mdo_actual) AS mdo_actual_tot,
            SUM(tm.mdo_anterior) AS mdo_anterior_tot
        FROM (
            SELECT DISTINCT unidad_negocio, franquicia, marca_mkt, mercado
            FROM BASE_VENTAS
            WHERE es_competidor = 0 AND marca_mkt <> 'COMPETIDORES'
        ) b
        INNER JOIN TOTAL_MERCADO tm ON b.mercado = tm.mercado
        GROUP BY b.unidad_negocio, b.franquicia, b.marca_mkt
    ),
    -- 3. Base Territorial (ALL DIM_CLIENTE en las zonas del filtro) para Market Share Territorial
    VENTAS_TERRITORIO AS (
        SELECT 
            f.codigo_presentacion,
            m.cp_presentacion,
            m.unidad_negocio,
            m.franquicia,
            m.marca_mkt,
            m.mercado,
            m.es_competidor,
            f.vta_actual
        FROM dbo.FACT_VENTAS_AGREGADA f
        INNER JOIN dbo.DIM_MATERIAL m ON f.codigo_presentacion = m.codigo_presentacion
        INNER JOIN dbo.DIM_CLIENTE c ON f.ruc = c.ruc
        INNER JOIN ZONAS_ACTUALES za ON c.lima_provincias = za.lima_provincias
        WHERE f.metrica = '{metrica_sql}'
          AND c.categorizacion IN ('DIAMANTE', 'ORO', 'PLATA', 'BRONCE', 'PLOMO')
    ),
    TOTAL_MERCADO_TERRITORIO AS (
        SELECT 
            mercado,
            SUM(vta_actual) AS mdo_territorio
        FROM VENTAS_TERRITORIO
        GROUP BY mercado
    ),
    MERCADO_MARCA_TERRITORIO AS (
        SELECT 
            b.unidad_negocio,
            b.franquicia,
            b.marca_mkt,
            SUM(mt.mdo_territorio) AS mdo_marca_territorio
        FROM (
            SELECT DISTINCT unidad_negocio, franquicia, marca_mkt, mercado
            FROM VENTAS_TERRITORIO
            WHERE es_competidor = 0 AND marca_mkt <> 'COMPETIDORES'
        ) b
        INNER JOIN TOTAL_MERCADO_TERRITORIO mt ON b.mercado = mt.mercado
        GROUP BY b.unidad_negocio, b.franquicia, b.marca_mkt
    ),
    -- MS Territorio por SKU
    MS_TERRITORIO_SKU AS (
        SELECT 
            vt.mercado,
            vt.cp_presentacion,
            CASE WHEN COALESCE(mt.mdo_territorio, 0) > 0 
                 THEN SUM(vt.vta_actual) * 1.0 / mt.mdo_territorio ELSE 0.0 END AS ms_territorio
        FROM VENTAS_TERRITORIO vt
        INNER JOIN TOTAL_MERCADO_TERRITORIO mt ON vt.mercado = mt.mercado
        WHERE vt.es_competidor = 0 AND vt.marca_mkt <> 'COMPETIDORES'
        GROUP BY vt.mercado, vt.cp_presentacion, mt.mdo_territorio
    ),
    -- MS Territorio por Marca
    MS_TERRITORIO_MARCA AS (
        SELECT 
            vt.unidad_negocio,
            vt.franquicia,
            vt.marca_mkt,
            CASE WHEN COALESCE(mmt.mdo_marca_territorio, 0) > 0 
                 THEN SUM(vt.vta_actual) * 1.0 / mmt.mdo_marca_territorio ELSE 0.0 END AS ms_territorio
        FROM VENTAS_TERRITORIO vt
        INNER JOIN MERCADO_MARCA_TERRITORIO mmt 
            ON vt.unidad_negocio = mmt.unidad_negocio 
           AND vt.franquicia = mmt.franquicia 
           AND vt.marca_mkt = mmt.marca_mkt
        WHERE vt.es_competidor = 0 AND vt.marca_mkt <> 'COMPETIDORES'
        GROUP BY vt.unidad_negocio, vt.franquicia, vt.marca_mkt, mmt.mdo_marca_territorio
    ),
    -- 4. Resumen por SKU en los clientes filtrados
    RESUMEN_SKU AS (
        SELECT 
            b.unidad_negocio,
            b.franquicia,
            b.marca_mkt,
            b.cp_presentacion,
            b.mercado,
            SUM(b.vta_actual) AS vta_actual_tot,
            SUM(b.vta_anterior) AS vta_anterior_tot
        FROM BASE_VENTAS b
        WHERE b.es_competidor = 0 
          AND b.marca_mkt <> 'COMPETIDORES'
          {where_mat_brand}
        GROUP BY b.unidad_negocio, b.franquicia, b.marca_mkt, b.cp_presentacion, b.mercado
    ),
    -- Resumen por Marca en los clientes filtrados
    RESUMEN_MARCA AS (
        SELECT 
            b.unidad_negocio,
            b.franquicia,
            b.marca_mkt,
            SUM(b.vta_actual) AS vta_actual_tot,
            SUM(b.vta_anterior) AS vta_anterior_tot
        FROM BASE_VENTAS b
        WHERE b.es_competidor = 0 
          AND b.marca_mkt <> 'COMPETIDORES'
          {where_mat_brand}
        GROUP BY b.unidad_negocio, b.franquicia, b.marca_mkt
    )
    -- 1. Consulta de SKUs con cálculos completos individuales
    SELECT 
        'SKU' AS tipo_fila,
        s.unidad_negocio,
        s.franquicia,
        s.marca_mkt,
        s.cp_presentacion,
        s.vta_actual_tot / 5.0 AS vta_act,
        COALESCE(tm.mdo_actual, 0) / 5.0 AS vta_mdo,
        s.vta_anterior_tot / 5.0 AS vta_ant,
        COALESCE(tm.mdo_anterior, 0) / 5.0 AS vta_mdo_ant,
        CASE WHEN COALESCE(tm.mdo_actual, 0) > 0 THEN s.vta_actual_tot * 1.0 / tm.mdo_actual ELSE 0.0 END AS ms_act,
        CASE WHEN COALESCE(tm.mdo_anterior, 0) > 0 THEN s.vta_anterior_tot * 1.0 / tm.mdo_anterior ELSE 0.0 END AS ms_ant,
        COALESCE(zsku.ms_territorio, (CASE WHEN COALESCE(tm.mdo_actual, 0) > 0 THEN s.vta_actual_tot * 1.0 / tm.mdo_actual ELSE 0.0 END)) AS ms_territorio
    FROM RESUMEN_SKU s
    LEFT JOIN TOTAL_MERCADO tm ON s.mercado = tm.mercado
    LEFT JOIN MS_TERRITORIO_SKU zsku ON s.mercado = zsku.mercado AND s.cp_presentacion = zsku.cp_presentacion

    UNION ALL

    -- 2. Consulta de Marcas con cálculos completos a nivel de Franquicia / Marca
    SELECT 
        'BRAND' AS tipo_fila,
        m.unidad_negocio,
        m.franquicia,
        m.marca_mkt,
        '' AS cp_presentacion,
        m.vta_actual_tot / 5.0 AS vta_act,
        COALESCE(mm.mdo_actual_tot, 0) / 5.0 AS vta_mdo,
        m.vta_anterior_tot / 5.0 AS vta_ant,
        COALESCE(mm.mdo_anterior_tot, 0) / 5.0 AS vta_mdo_ant,
        CASE WHEN COALESCE(mm.mdo_actual_tot, 0) > 0 THEN m.vta_actual_tot * 1.0 / mm.mdo_actual_tot ELSE 0.0 END AS ms_act,
        CASE WHEN COALESCE(mm.mdo_anterior_tot, 0) > 0 THEN m.vta_anterior_tot * 1.0 / mm.mdo_anterior_tot ELSE 0.0 END AS ms_ant,
        COALESCE(zm.ms_territorio, (CASE WHEN COALESCE(mm.mdo_actual_tot, 0) > 0 THEN m.vta_actual_tot * 1.0 / mm.mdo_actual_tot ELSE 0.0 END)) AS ms_territorio
    FROM RESUMEN_MARCA m
    LEFT JOIN MERCADO_MARCA mm ON m.unidad_negocio = mm.unidad_negocio AND m.franquicia = mm.franquicia AND m.marca_mkt = mm.marca_mkt
    LEFT JOIN MS_TERRITORIO_MARCA zm ON m.unidad_negocio = zm.unidad_negocio AND m.franquicia = zm.franquicia AND m.marca_mkt = zm.marca_mkt

    UNION ALL

    -- 3. Consulta de Mercados Distintos para el Total General de Mercado (evitando duplicar mercados compartidos)
    SELECT 
        'DISTINCT_MERCADO' AS tipo_fila,
        '' AS unidad_negocio,
        '' AS franquicia,
        '' AS marca_mkt,
        '' AS cp_presentacion,
        0.0 AS vta_act,
        SUM(tm.mdo_actual) / 5.0 AS vta_mdo,
        0.0 AS vta_ant,
        SUM(tm.mdo_anterior) / 5.0 AS vta_mdo_ant,
        0.0 AS ms_act,
        0.0 AS ms_ant,
        0.0 AS ms_territorio
    FROM TOTAL_MERCADO tm
    INNER JOIN (
        SELECT DISTINCT mercado
        FROM dbo.DIM_MATERIAL
        WHERE es_competidor = 0 
          AND marca_mkt IS NOT NULL 
          AND marca_mkt <> 'COMPETIDORES'
          {where_mat_clean}
    ) dm ON tm.mercado = dm.mercado

    UNION ALL

    -- 4. Total Territorio Medifarma vs Mercado (para calcular tot_ms_territorio global exacto a Power BI)
    SELECT 
        'TOTAL_TERRITORIO' AS tipo_fila,
        '' AS unidad_negocio,
        '' AS franquicia,
        '' AS marca_mkt,
        '' AS cp_presentacion,
        SUM(CASE WHEN vt.es_competidor = 0 AND vt.marca_mkt <> 'COMPETIDORES' {where_mat_vt} THEN vt.vta_actual ELSE 0.0 END) / 5.0 AS vta_act,
        SUM(vt.vta_actual) / 5.0 AS vta_mdo,
        0.0 AS vta_ant,
        0.0 AS vta_mdo_ant,
        0.0 AS ms_act,
        0.0 AS ms_ant,
        0.0 AS ms_territorio
    FROM VENTAS_TERRITORIO vt
    INNER JOIN (
        SELECT DISTINCT mercado
        FROM dbo.DIM_MATERIAL
        WHERE es_competidor = 0 AND marca_mkt IS NOT NULL AND marca_mkt <> 'COMPETIDORES'
        {where_mat_clean}
    ) mf ON vt.mercado = mf.mercado;
    """

    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(q_matrix)
        all_rows = fetch_all_dict(cursor)
    finally:
        conn.close()

    skus = []
    brands = []
    tot_mdo_row = None
    tot_terr_row = None

    for r in all_rows:
        tf = r.get('tipo_fila')
        if tf == 'DISTINCT_MERCADO':
            tot_mdo_row = r
            continue
        elif tf == 'TOTAL_TERRITORIO':
            tot_terr_row = r
            continue

        ms_act = float(r.get('ms_act') or 0)
        ms_ant = float(r.get('ms_ant') or 0)
        ms_ter = float(r.get('ms_territorio') or 0)
        vta_act = float(r.get('vta_act') or 0)
        vta_mdo = float(r.get('vta_mdo') or 0)
        vta_ant = float(r.get('vta_ant') or 0)
        vta_mdo_ant = float(r.get('vta_mdo_ant') or 0)

        # Reglas de negocio DAX exactas:
        ms_ideal = max(ms_act, ms_ant, ms_ter)
        construccion = 0.0 if ms_act >= ms_ideal else (ms_ideal - ms_act)
        valorizacion = (vta_mdo * 5.0) * construccion
        estimacion = (valorizacion + (vta_act * 5.0)) / 5.0

        item = {
            'DIM_MATERIAL[Unidad_Negocio]': r.get('unidad_negocio'),
            'DIM_MATERIAL[Franquicia]': r.get('franquicia'),
            'DIM_MATERIAL[Marca_MKT]': r.get('marca_mkt'),
            'DIM_MATERIAL[CP_presentacion]': r.get('cp_presentacion'),
            '[VTA_ACT]': vta_act,
            '[VTA_MDO]': vta_mdo,
            '[VTA_ANT]': vta_ant,
            '[VTA_MDO_ANT]': vta_mdo_ant,
            '[MS_ACT]': ms_act,
            '[MS_ANT]': ms_ant,
            '[MS_TERRITORIO]': ms_ter,
            '[MS_IDEAL]': ms_ideal,
            '[ESTIMACION]': estimacion
        }

        if tf == 'SKU':
            skus.append(item)
        else:
            brands.append(item)

    # Totales generales acumulados replicando exactamente las medidas de Power BI
    tot_vta_act = sum(b['[VTA_ACT]'] for b in brands)
    tot_vta_mdo = float(tot_mdo_row['vta_mdo']) if tot_mdo_row and float(tot_mdo_row.get('vta_mdo') or 0) > 0 else sum(b['[VTA_MDO]'] for b in brands)
    tot_vta_ant = sum(b.get('[VTA_ANT]', 0) for b in brands)
    tot_vta_mdo_ant = float(tot_mdo_row['vta_mdo_ant']) if tot_mdo_row and float(tot_mdo_row.get('vta_mdo_ant') or 0) > 0 else 0.0

    tot_ms_act = (tot_vta_act / tot_vta_mdo) if tot_vta_mdo > 0 else 0.0
    tot_ms_ant = (tot_vta_ant / tot_vta_mdo_ant) if tot_vta_mdo_ant > 0 else 0.0

    if tot_terr_row and float(tot_terr_row.get('vta_mdo') or 0) > 0:
        tot_ms_territorio = float(tot_terr_row.get('vta_act') or 0) / float(tot_terr_row.get('vta_mdo') or 1)
    else:
        tot_ms_territorio = tot_ms_act

    tot_ms_ideal = max(tot_ms_act, tot_ms_ant, tot_ms_territorio)
    tot_estimacion = tot_vta_mdo * tot_ms_ideal

    totals = {
        'marca': 'Total General',
        'vta_act': tot_vta_act,
        'vta_mdo': tot_vta_mdo,
        'ms_act': tot_ms_act,
        'ms_ant': tot_ms_ant,
        'ms_territorio': tot_ms_territorio,
        'ms_ideal': tot_ms_ideal,
        'estimacion': tot_estimacion
    }

    return {
        'skus': skus,
        'brands': brands,
        'totals': totals
    }

def get_matrix_data(unidad_medida="UNIDAD", unidad_negocio=None, franquicia=None, marca=None, 
                    categorizacion=None, zona_base=None, supervisor=None, selected_clients=None, search=""):
    """
    Retorna la matriz formateada y enriquecida con los flags de compra de clientes para el frontend.
    """
    unidad_medida = unidad_medida or "UNIDAD"
    load_filters()
    
    un_tuple = tuple(sorted(unidad_negocio)) if unidad_negocio else ()
    fr_tuple = tuple(sorted(franquicia)) if franquicia else ()
    ma_tuple = tuple(sorted(marca)) if marca else ()
    cat_tuple = tuple(sorted(categorizacion)) if categorizacion else ()
    zb_tuple = tuple(sorted(zona_base)) if isinstance(zona_base, (list, tuple)) else ((zona_base,) if zona_base else ())
    sup_tuple = tuple(sorted(supervisor)) if isinstance(supervisor, (list, tuple)) else ((supervisor,) if supervisor else ())
    
    cache_key = (unidad_medida, un_tuple, fr_tuple, ma_tuple, cat_tuple, zb_tuple, sup_tuple)
    
    if cache_key in CACHE['query_cache']:
        sql_res = CACHE['query_cache'][cache_key]
    else:
        sql_res = query_sql_matrix(unidad_medida, unidad_negocio, franquicia, marca, categorizacion, zona_base, supervisor)
        CACHE['query_cache'][cache_key] = sql_res

    sku_rows = sql_res['skus']
    brand_rows = sql_res['brands']
    totals = sql_res['totals']
    
    all_clients = CACHE['filters']['clients']
    
    # Filtrar clientes objetivo para las columnas de la tabla
    cat_map = {'Q1': 'DIAMANTE', 'Q2': 'ORO', 'Q3': 'PLATA', 'Q4': 'BRONCE', 'Q5': 'PLOMO'}
    norm_cats = [cat_map.get(c, c) for c in categorizacion] if categorizacion else []
    
    target_clients = all_clients
    if norm_cats:
        target_clients = [c for c in target_clients if c['categorizacion'] in norm_cats or c['quintil'] in norm_cats]

    if zona_base:
        zb_vals = set(zona_base) if isinstance(zona_base, (list, tuple)) else {zona_base}
        target_clients = [c for c in target_clients if c.get('zonabase') in zb_vals]

    if supervisor:
        sup_vals = set(supervisor) if isinstance(supervisor, (list, tuple)) else {supervisor}
        target_clients = [c for c in target_clients if c.get('supervisor') in sup_vals]

    if selected_clients and len(selected_clients) > 0:
        existing_cps = {c['cp_cliente'] for c in all_clients}
        missing_cps = [cp for cp in selected_clients if cp not in existing_cps]
        if missing_cps:
            extra_clients = get_clients_by_ids(missing_cps)
            all_clients = all_clients + extra_clients
        target_clients = [c for c in all_clients if c['cp_cliente'] in selected_clients or c['ruc'] in selected_clients]
    else:
        target_clients = target_clients[:8] # Default top 8

    # Cargar compras de los clientes objetivo
    target_client_cps = [c['cp_cliente'] for c in target_clients]
    p_set, b_set = load_client_purchases(unidad_medida, target_client_cps)

    # Columnas de clientes
    client_columns = [{
        'cp_cliente': c['cp_cliente'],
        'ruc': c['ruc'],
        'farmacia': c['farmacia'],
        'quintil': c['quintil'],
        'categorizacion': c['categorizacion']
    } for c in target_clients]

    # Mapear SKUs por Marca (agrupando por unidad_negocio, franquicia, marca)
    sku_dict = {}
    for r in sku_rows:
        un = r.get('DIM_MATERIAL[Unidad_Negocio]')
        fr = r.get('DIM_MATERIAL[Franquicia]')
        m = r.get('DIM_MATERIAL[Marca_MKT]')
        p = r.get('DIM_MATERIAL[CP_presentacion]')
        if not m or not p:
            continue

        sku_client_vals = {}
        for c in target_clients:
            cp = c['cp_cliente']
            compra = 'SI' if (cp, p) in p_set else 'NO'
            sku_client_vals[cp] = {'compra': compra, 'quintil': c['quintil']}

        sku_obj = {
            'sku': p,
            'vta_act': float(r.get('[VTA_ACT]') or 0),
            'vta_mdo': float(r.get('[VTA_MDO]') or 0),
            'ms_act': float(r.get('[MS_ACT]') or 0),
            'ms_ant': float(r.get('[MS_ANT]') or 0),
            'ms_territorio': float(r.get('[MS_TERRITORIO]') or 0),
            'ms_ideal': float(r.get('[MS_IDEAL]') or 0),
            'estimacion': float(r.get('[ESTIMACION]') or 0),
            'clients': sku_client_vals
        }
        b_key = (un, fr, m)
        sku_dict.setdefault(b_key, []).append(sku_obj)

    # Construir listado de Marcas
    brands_list = []
    seen_brands = set()
    for r in brand_rows:
        un = r.get('DIM_MATERIAL[Unidad_Negocio]')
        fr = r.get('DIM_MATERIAL[Franquicia]')
        m = r.get('DIM_MATERIAL[Marca_MKT]')
        if not m or m == 'COMPETIDORES':
            continue

        b_key = (un, fr, m)
        if b_key in seen_brands:
            continue
        seen_brands.add(b_key)

        skus_for_brand = sku_dict.get(b_key, [])
        skus_for_brand.sort(key=lambda x: x['vta_act'], reverse=True)

        if search:
            s_lower = search.lower()
            if s_lower not in m.lower() and not any(s_lower in s['sku'].lower() for s in skus_for_brand):
                continue

        brand_client_vals = {}
        for c in target_clients:
            cp = c['cp_cliente']
            compra = 'SI' if (cp, m) in b_set else 'NO'
            brand_client_vals[cp] = {'compra': compra, 'quintil': c['quintil']}

        brand_obj = {
            'marca': m,
            'unidad_negocio': un,
            'franquicia': fr,
            'vta_act': float(r.get('[VTA_ACT]') or 0),
            'vta_mdo': float(r.get('[VTA_MDO]') or 0),
            'ms_act': float(r.get('[MS_ACT]') or 0),
            'ms_ant': float(r.get('[MS_ANT]') or 0),
            'ms_territorio': float(r.get('[MS_TERRITORIO]') or 0),
            'ms_ideal': float(r.get('[MS_IDEAL]') or 0),
            'estimacion': float(r.get('[ESTIMACION]') or 0),
            'clients': brand_client_vals,
            'skus': skus_for_brand
        }
        brands_list.append(brand_obj)

    brands_list.sort(key=lambda x: x['estimacion'], reverse=True)

    return {
        'unidad_medida': unidad_medida,
        'periodo': 'Enero 2026 - Mayo 2026',
        'client_columns': client_columns,
        'brands': brands_list,
        'totals': totals,
        'total_brands_count': len(brands_list),
        'total_clients_count': len(all_clients)
    }

def get_territorial_benchmark(metrica_sql, lima_provincias):
    """Calcula o recupera de caché el benchmark territorial para LIMA o PROVINCIA."""
    key = (metrica_sql, lima_provincias)
    if 'territory_cache' not in CACHE:
        CACHE['territory_cache'] = {}
    if key in CACHE['territory_cache']:
        return CACHE['territory_cache'][key]

    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        q_terr = f"""
        WITH 
        CATALOGO_MEDIFARMA AS (
            SELECT DISTINCT
                m.unidad_negocio,
                m.franquicia,
                m.marca_mkt,
                m.cp_presentacion,
                m.mercado
            FROM dbo.DIM_MATERIAL m
            WHERE m.es_competidor = 0 
              AND m.marca_mkt IS NOT NULL 
              AND m.marca_mkt <> '' 
              AND m.marca_mkt <> 'COMPETIDORES'
              AND m.mercado IS NOT NULL
              AND m.mercado <> ''
              AND m.mercado <> 'RESTO'
        ),
        VENTAS_TERRITORIO AS (
            SELECT 
                f.codigo_presentacion,
                m.cp_presentacion,
                m.unidad_negocio,
                m.franquicia,
                m.marca_mkt,
                m.mercado,
                m.es_competidor,
                f.vta_actual
            FROM dbo.FACT_VENTAS_AGREGADA f
            INNER JOIN dbo.DIM_MATERIAL m ON f.codigo_presentacion = m.codigo_presentacion
            INNER JOIN dbo.DIM_CLIENTE c ON f.ruc = c.ruc
            WHERE f.metrica = '{metrica_sql}'
              AND c.lima_provincias = '{lima_provincias}'
              AND c.categorizacion IN ('DIAMANTE', 'ORO', 'PLATA', 'BRONCE', 'PLOMO')
        ),
        TOTAL_MERCADO_TERRITORIO AS (
            SELECT 
                mercado,
                SUM(vta_actual) AS mdo_territorio
            FROM VENTAS_TERRITORIO
            WHERE mercado IS NOT NULL AND mercado <> '' AND mercado <> 'RESTO'
            GROUP BY mercado
        ),
        MERCADO_MARCA_TERRITORIO AS (
            SELECT 
                cm.unidad_negocio,
                cm.franquicia,
                cm.marca_mkt,
                SUM(mt.mdo_territorio) AS mdo_marca_territorio
            FROM (
                SELECT DISTINCT unidad_negocio, franquicia, marca_mkt, mercado
                FROM CATALOGO_MEDIFARMA
            ) cm
            INNER JOIN TOTAL_MERCADO_TERRITORIO mt ON cm.mercado = mt.mercado
            GROUP BY cm.unidad_negocio, cm.franquicia, cm.marca_mkt
        )
        SELECT 
            'SKU' AS tipo_fila,
            vt.cp_presentacion,
            '' AS unidad_negocio,
            '' AS franquicia,
            '' AS marca_mkt,
            CASE WHEN COALESCE(mt.mdo_territorio, 0) > 0 
                 THEN SUM(vt.vta_actual) * 1.0 / mt.mdo_territorio ELSE 0.0 END AS ms_territorio
        FROM VENTAS_TERRITORIO vt
        INNER JOIN TOTAL_MERCADO_TERRITORIO mt ON vt.mercado = mt.mercado
        WHERE vt.es_competidor = 0 AND vt.marca_mkt <> 'COMPETIDORES'
        GROUP BY vt.cp_presentacion, mt.mdo_territorio

        UNION ALL

        SELECT 
            'BRAND' AS tipo_fila,
            '' AS cp_presentacion,
            vt.unidad_negocio,
            vt.franquicia,
            vt.marca_mkt,
            CASE WHEN COALESCE(mmt.mdo_marca_territorio, 0) > 0 
                 THEN SUM(vt.vta_actual) * 1.0 / mmt.mdo_marca_territorio ELSE 0.0 END AS ms_territorio
        FROM VENTAS_TERRITORIO vt
        INNER JOIN MERCADO_MARCA_TERRITORIO mmt 
            ON vt.unidad_negocio = mmt.unidad_negocio 
           AND vt.franquicia = mmt.franquicia 
           AND vt.marca_mkt = mmt.marca_mkt
        WHERE vt.es_competidor = 0 AND vt.marca_mkt <> 'COMPETIDORES'
        GROUP BY vt.unidad_negocio, vt.franquicia, vt.marca_mkt, mmt.mdo_marca_territorio

        UNION ALL

        SELECT 
            'TOTAL' AS tipo_fila,
            '' AS cp_presentacion,
            '' AS unidad_negocio,
            '' AS franquicia,
            '' AS marca_mkt,
            SUM(CASE WHEN vt.es_competidor = 0 AND vt.marca_mkt <> 'COMPETIDORES' THEN vt.vta_actual ELSE 0.0 END) * 1.0 / NULLIF(SUM(vt.vta_actual), 0) AS ms_territorio
        FROM VENTAS_TERRITORIO vt
        INNER JOIN (
            SELECT DISTINCT mercado FROM CATALOGO_MEDIFARMA
        ) mf ON vt.mercado = mf.mercado;
        """
        cursor.execute(q_terr)
        terr_rows = fetch_all_dict(cursor)
    finally:
        conn.close()

    ms_terr_sku = {}
    ms_terr_brand = {}
    tot_ms_terr = 0.0

    for r in terr_rows:
        tf = r['tipo_fila']
        ms = float(r.get('ms_territorio') or 0)
        if tf == 'SKU':
            ms_terr_sku[r['cp_presentacion']] = ms
        elif tf == 'BRAND':
            ms_terr_brand[(r['unidad_negocio'], r['franquicia'], r['marca_mkt'])] = ms
        elif tf == 'TOTAL':
            tot_ms_terr = ms

    bench = {
        'sku': ms_terr_sku,
        'brand': ms_terr_brand,
        'total': tot_ms_terr
    }
    CACHE['territory_cache'][key] = bench
    return bench

def get_client_matrix_data(client_identifier, unidad_medida="UNIDAD", unidad_negocio=None, 
                           franquicia=None, marca=None, search=""):
    """
    Calcula y retorna la matriz de Pedidos Sugeridos exclusivamente para un cliente seleccionado.
    Recalcula ventas Medifarma, ventas mercado del cliente, MS actual, anterior, territorio,
    MS ideal y estimación potencial mensual con rendimiento sub-segundo.
    """
    unidad_medida = unidad_medida or "UNIDAD"
    metrica_sql = 'VALOR' if 'SOL' in (unidad_medida or '').upper() else 'UNIDAD'
    
    un_tuple = tuple(sorted(unidad_negocio)) if unidad_negocio else ()
    fr_tuple = tuple(sorted(franquicia)) if franquicia else ()
    ma_tuple = tuple(sorted(marca)) if marca else ()
    cache_k = (str(client_identifier).strip(), unidad_medida, un_tuple, fr_tuple, ma_tuple)
    
    if cache_k in CACHE['client_query_cache']:
        cached = CACHE['client_query_cache'][cache_k]
        # Si se busca término de texto, filtrar en memoria desde caché
        if search:
            s_lower = search.lower().strip()
            filtered_brands = []
            for b in cached['brands']:
                b_match = s_lower in b['marca'].lower()
                matching_skus = [s for s in b['skus'] if s_lower in s['sku'].lower()]
                if b_match:
                    filtered_brands.append(b)
                elif matching_skus:
                    b_copy = dict(b)
                    b_copy['skus'] = matching_skus
                    filtered_brands.append(b_copy)
            return {
                **cached,
                'brands': filtered_brands,
                'total_brands_count': len(filtered_brands)
            }
        return cached

    # 1. Obtener información del cliente
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            f"SELECT TOP 1 ruc, farmacia, cp_cliente, lima_provincias, categorizacion, quintil, zonabase, supervisor "
            f"FROM dbo.DIM_CLIENTE "
            f"WHERE cp_cliente = {escape_sql_str(client_identifier)} OR ruc = {escape_sql_str(client_identifier)}"
        )
        cli_rows = fetch_all_dict(cursor)
        if not cli_rows:
            return None
            
        client_info = dict(cli_rows[0])
        zb = str(client_info.get('zonabase') or '').strip()
        v_info = get_vendor_info(zb)
        if not client_info.get('supervisor') and v_info.get('ssvv'):
            client_info['supervisor'] = v_info.get('ssvv')
        client_info['vendedores'] = v_info.get('ffvv', [])
        
        ruc = client_info['ruc']
        lima_provincias = client_info['lima_provincias'] or 'LIMA'
        
        # Filtros de materiales
        mat_filters = []
        if unidad_negocio and len(unidad_negocio) > 0:
            un_in = ", ".join([escape_sql_str(u) for u in unidad_negocio if u])
            if un_in:
                mat_filters.append(f"m.unidad_negocio IN ({un_in})")
        if franquicia and len(franquicia) > 0:
            fr_in = ", ".join([escape_sql_str(f) for f in franquicia if f])
            if fr_in:
                mat_filters.append(f"m.franquicia IN ({fr_in})")
        if marca and len(marca) > 0:
            ma_in = ", ".join([escape_sql_str(m) for m in marca if m])
            if ma_in:
                mat_filters.append(f"m.marca_mkt IN ({ma_in})")
                
        where_mat = ("AND " + " AND ".join(mat_filters)) if mat_filters else ""
        
        q_client = f"""
        WITH 
        CATALOGO_MEDIFARMA AS (
            SELECT DISTINCT
                m.unidad_negocio,
                m.franquicia,
                m.marca_mkt,
                m.cp_presentacion,
                m.mercado
            FROM dbo.DIM_MATERIAL m
            WHERE m.es_competidor = 0 
              AND m.marca_mkt IS NOT NULL 
              AND m.marca_mkt <> '' 
              AND m.marca_mkt <> 'COMPETIDORES'
              AND m.mercado IS NOT NULL
              AND m.mercado <> ''
              AND m.mercado <> 'RESTO'
              {where_mat}
        ),
        CATALOGO_MARCAS AS (
            SELECT DISTINCT
                unidad_negocio,
                franquicia,
                marca_mkt
            FROM CATALOGO_MEDIFARMA
        ),
        VENTAS_CLIENTE AS (
            SELECT 
                f.codigo_presentacion,
                m.cp_presentacion,
                m.unidad_negocio,
                m.franquicia,
                m.marca_mkt,
                m.mercado,
                m.es_competidor,
                f.vta_actual,
                f.vta_anterior
            FROM dbo.FACT_VENTAS_AGREGADA f
            INNER JOIN dbo.DIM_MATERIAL m ON f.codigo_presentacion = m.codigo_presentacion
            WHERE f.metrica = '{metrica_sql}'
              AND f.ruc = '{ruc}'
        ),
        TOTAL_MERCADO_CLIENTE AS (
            SELECT 
                mercado,
                SUM(vta_actual) AS mdo_actual,
                SUM(vta_anterior) AS mdo_anterior
            FROM VENTAS_CLIENTE
            WHERE mercado IS NOT NULL AND mercado <> '' AND mercado <> 'RESTO'
            GROUP BY mercado
        ),
        VENTAS_SKU_CLIENTE AS (
            SELECT 
                cp_presentacion,
                mercado,
                SUM(vta_actual) AS vta_act,
                SUM(vta_anterior) AS vta_ant
            FROM VENTAS_CLIENTE
            WHERE es_competidor = 0 AND marca_mkt <> 'COMPETIDORES'
            GROUP BY cp_presentacion, mercado
        ),
        VENTAS_MARCA_CLIENTE AS (
            SELECT 
                unidad_negocio,
                franquicia,
                marca_mkt,
                SUM(vta_actual) AS vta_act,
                SUM(vta_anterior) AS vta_ant
            FROM VENTAS_CLIENTE
            WHERE es_competidor = 0 AND marca_mkt <> 'COMPETIDORES'
            GROUP BY unidad_negocio, franquicia, marca_mkt
        ),
        MERCADO_MARCA_CLIENTE AS (
            SELECT 
                cm.unidad_negocio,
                cm.franquicia,
                cm.marca_mkt,
                SUM(COALESCE(tmc.mdo_actual, 0)) AS mdo_actual_tot,
                SUM(COALESCE(tmc.mdo_anterior, 0)) AS mdo_anterior_tot
            FROM (
                SELECT DISTINCT unidad_negocio, franquicia, marca_mkt, mercado
                FROM CATALOGO_MEDIFARMA
            ) cm
            INNER JOIN TOTAL_MERCADO_CLIENTE tmc ON cm.mercado = tmc.mercado
            GROUP BY cm.unidad_negocio, cm.franquicia, cm.marca_mkt
        )
        SELECT 
            'SKU' AS tipo_fila,
            c.unidad_negocio,
            c.franquicia,
            c.marca_mkt,
            c.cp_presentacion,
            COALESCE(vsc.vta_act, 0.0) / 5.0 AS vta_act,
            COALESCE(tmc.mdo_actual, 0.0) / 5.0 AS vta_mdo,
            COALESCE(vsc.vta_ant, 0.0) / 5.0 AS vta_ant,
            COALESCE(tmc.mdo_anterior, 0.0) / 5.0 AS vta_mdo_ant,
            CASE WHEN COALESCE(tmc.mdo_actual, 0) > 0 THEN COALESCE(vsc.vta_act, 0) * 1.0 / tmc.mdo_actual ELSE 0.0 END AS ms_act,
            CASE WHEN COALESCE(tmc.mdo_anterior, 0) > 0 THEN COALESCE(vsc.vta_ant, 0) * 1.0 / tmc.mdo_anterior ELSE 0.0 END AS ms_ant
        FROM CATALOGO_MEDIFARMA c
        LEFT JOIN TOTAL_MERCADO_CLIENTE tmc ON c.mercado = tmc.mercado
        LEFT JOIN VENTAS_SKU_CLIENTE vsc ON c.cp_presentacion = vsc.cp_presentacion

        UNION ALL

        SELECT 
            'BRAND' AS tipo_fila,
            cm.unidad_negocio,
            cm.franquicia,
            cm.marca_mkt,
            '' AS cp_presentacion,
            COALESCE(vmc.vta_act, 0.0) / 5.0 AS vta_act,
            COALESCE(mmc.mdo_actual_tot, 0.0) / 5.0 AS vta_mdo,
            COALESCE(vmc.vta_ant, 0.0) / 5.0 AS vta_ant,
            COALESCE(mmc.mdo_anterior_tot, 0.0) / 5.0 AS vta_mdo_ant,
            CASE WHEN COALESCE(mmc.mdo_actual_tot, 0) > 0 THEN COALESCE(vmc.vta_act, 0) * 1.0 / mmc.mdo_actual_tot ELSE 0.0 END AS ms_act,
            CASE WHEN COALESCE(mmc.mdo_anterior_tot, 0) > 0 THEN COALESCE(vmc.vta_ant, 0) * 1.0 / mmc.mdo_anterior_tot ELSE 0.0 END AS ms_ant
        FROM CATALOGO_MARCAS cm
        LEFT JOIN VENTAS_MARCA_CLIENTE vmc ON cm.unidad_negocio = vmc.unidad_negocio AND cm.franquicia = vmc.franquicia AND cm.marca_mkt = vmc.marca_mkt
        LEFT JOIN MERCADO_MARCA_CLIENTE mmc ON cm.unidad_negocio = mmc.unidad_negocio AND cm.franquicia = mmc.franquicia AND cm.marca_mkt = mmc.marca_mkt

        UNION ALL

        SELECT 
            'DISTINCT_MERCADO' AS tipo_fila,
            '' AS unidad_negocio,
            '' AS franquicia,
            '' AS marca_mkt,
            '' AS cp_presentacion,
            0.0 AS vta_act,
            SUM(tmc.mdo_actual) / 5.0 AS vta_mdo,
            0.0 AS vta_ant,
            SUM(tmc.mdo_anterior) / 5.0 AS vta_mdo_ant,
            0.0 AS ms_act,
            0.0 AS ms_ant
        FROM TOTAL_MERCADO_CLIENTE tmc
        INNER JOIN (
            SELECT DISTINCT mercado FROM CATALOGO_MEDIFARMA
        ) dm ON tmc.mercado = dm.mercado;
        """
        cursor.execute(q_client)
        all_rows = fetch_all_dict(cursor)

        # Consulta a FACT_VENTAS_SI para compras por distribuidor del cliente
        metrica_si = 'soles' if unidad_medida == 'S/ SOLES' else 'unidades'
        q_distrib = f"""
        SELECT 
            distribuidor,
            material,
            marca,
            SUM({metrica_si}) / 5.0 as prom_mensual
        FROM dbo.FACT_VENTAS_SI
        WHERE ruc = {escape_sql_str(ruc)}
          AND fecha >= '2026-01-01' AND fecha <= '2026-05-31'
        GROUP BY distribuidor, material, marca
        """
        cursor.execute(q_distrib)
        distrib_rows = fetch_all_dict(cursor)
    finally:
        conn.close()

    # Benchmark territorial (utiliza caché en memoria)
    bench = get_territorial_benchmark(metrica_sql, lima_provincias)
    ms_terr_sku = bench['sku']
    ms_terr_brand = bench['brand']
    tot_ms_territorio = bench['total']

    # Mapeo de compras por distribuidora
    dist_totals = {}
    sku_dist_map = {}
    for dr in distrib_rows:
        d = str(dr.get('distribuidor') or '').strip()
        if not d:
            continue
        mat = str(dr.get('material') or '').strip()
        val = float(dr.get('prom_mensual') or 0)
        dist_totals[d] = dist_totals.get(d, 0.0) + val
        if mat:
            if mat not in sku_dist_map:
                sku_dist_map[mat] = {}
            sku_dist_map[mat][d] = sku_dist_map[mat].get(d, 0.0) + val

    distributors = [d for d, _ in sorted(dist_totals.items(), key=lambda x: x[1], reverse=True)]

    skus_dict = {}
    brands_list = []
    tot_mdo_row = None
    
    for r in all_rows:
        tf = r.get('tipo_fila')
        if tf == 'DISTINCT_MERCADO':
            tot_mdo_row = r
            continue
            
        ms_act = float(r.get('ms_act') or 0)
        ms_ant = float(r.get('ms_ant') or 0)
        vta_act = float(r.get('vta_act') or 0)
        vta_mdo = float(r.get('vta_mdo') or 0)
        vta_ant = float(r.get('vta_ant') or 0)
        vta_mdo_ant = float(r.get('vta_mdo_ant') or 0)
        
        un = r.get('unidad_negocio')
        fr = r.get('franquicia')
        m = r.get('marca_mkt')
        p = r.get('cp_presentacion')
        
        if tf == 'SKU':
            ms_ter = ms_terr_sku.get(p, 0.0)
            ms_ideal = max(ms_act, ms_ant, ms_ter)
            construccion = 0.0 if ms_act >= ms_ideal else (ms_ideal - ms_act)
            valorizacion = (vta_mdo * 5.0) * construccion
            estimacion = (valorizacion + (vta_act * 5.0)) / 5.0
            mat_code = p.split(' - ')[0].strip() if p else ''
            sku_d_map = sku_dist_map.get(mat_code, {})
            sku_obj = {
                'sku': p,
                'vta_act': vta_act,
                'vta_mdo': vta_mdo,
                'vta_ant': vta_ant,
                'vta_mdo_ant': vta_mdo_ant,
                'ms_act': ms_act,
                'ms_ant': ms_ant,
                'ms_territorio': ms_ter,
                'ms_ideal': ms_ideal,
                'estimacion': estimacion,
                'distribuidoras': {d: float(sku_d_map.get(d, 0.0)) for d in distributors}
            }
            skus_dict.setdefault((un, fr, m), []).append(sku_obj)
        else:
            ms_ter = ms_terr_brand.get((un, fr, m), 0.0)
            ms_ideal = max(ms_act, ms_ant, ms_ter)
            construccion = 0.0 if ms_act >= ms_ideal else (ms_ideal - ms_act)
            valorizacion = (vta_mdo * 5.0) * construccion
            estimacion = (valorizacion + (vta_act * 5.0)) / 5.0
            brand_obj = {
                'marca': m,
                'unidad_negocio': un,
                'franquicia': fr,
                'vta_act': vta_act,
                'vta_mdo': vta_mdo,
                'vta_ant': vta_ant,
                'vta_mdo_ant': vta_mdo_ant,
                'ms_act': ms_act,
                'ms_ant': ms_ant,
                'ms_territorio': ms_ter,
                'ms_ideal': ms_ideal,
                'estimacion': estimacion,
                'skus': [],
                'distribuidoras': {}
            }
            brands_list.append(brand_obj)
            
    for b in brands_list:
        b_key = (b['unidad_negocio'], b['franquicia'], b['marca'])
        b_skus = skus_dict.get(b_key, [])
        b_skus.sort(key=lambda x: x['vta_act'], reverse=True)
        b['skus'] = b_skus
        b['distribuidoras'] = {
            d: sum(s['distribuidoras'].get(d, 0.0) for s in b_skus)
            for d in distributors
        }
        
    if search:
        s_lower = search.lower().strip()
        brands_list = [
            b for b in brands_list 
            if s_lower in b['marca'].lower() or any(s_lower in s['sku'].lower() for s in b['skus'])
        ]
        
    brands_list.sort(key=lambda x: x['estimacion'], reverse=True)
    
    tot_vta_act = sum(b['vta_act'] for b in brands_list)
    tot_vta_mdo = float(tot_mdo_row['vta_mdo']) if tot_mdo_row and float(tot_mdo_row.get('vta_mdo') or 0) > 0 else sum(b['vta_mdo'] for b in brands_list)
    tot_vta_ant = sum(b.get('vta_ant', 0) for b in brands_list)
    tot_vta_mdo_ant = float(tot_mdo_row['vta_mdo_ant']) if tot_mdo_row and float(tot_mdo_row.get('vta_mdo_ant') or 0) > 0 else 0.0

    tot_ms_act = (tot_vta_act / tot_vta_mdo) if tot_vta_mdo > 0 else 0.0
    tot_ms_ant = (tot_vta_ant / tot_vta_mdo_ant) if tot_vta_mdo_ant > 0 else 0.0

    tot_ms_ideal = max(tot_ms_act, tot_ms_ant, tot_ms_territorio)
    tot_construccion = 0.0 if tot_ms_act >= tot_ms_ideal else (tot_ms_ideal - tot_ms_act)
    tot_estimacion = ((tot_vta_mdo * 5.0 * tot_construccion) + (tot_vta_act * 5.0)) / 5.0

    tot_dist = {
        d: sum(b['distribuidoras'].get(d, 0.0) for b in brands_list)
        for d in distributors
    }

    totals = {
        'marca': 'Total General',
        'vta_act': tot_vta_act,
        'vta_mdo': tot_vta_mdo,
        'ms_act': tot_ms_act,
        'ms_ant': tot_ms_ant,
        'ms_territorio': tot_ms_territorio,
        'ms_ideal': tot_ms_ideal,
        'estimacion': tot_estimacion,
        'distribuidoras': tot_dist
    }
    
    result = {
        'client': client_info,
        'unidad_medida': unidad_medida,
        'periodo': 'Enero 2026 - Mayo 2026',
        'distributors': distributors,
        'brands': brands_list,
        'totals': totals,
        'total_brands_count': len(brands_list)
    }
    
    CACHE['client_query_cache'][cache_k] = result
    
    if search:
        s_lower = search.lower().strip()
        filtered_brands = []
        for b in brands_list:
            b_match = s_lower in b['marca'].lower()
            matching_skus = [s for s in b['skus'] if s_lower in s['sku'].lower()]
            if b_match:
                filtered_brands.append(b)
            elif matching_skus:
                b_copy = dict(b)
                b_copy['skus'] = matching_skus
                filtered_brands.append(b_copy)
        return {
            **result,
            'brands': filtered_brands,
            'total_brands_count': len(filtered_brands)
        }
        
    return result

if __name__ == '__main__':
    print("Testing data engine via SQL Server...")
    try:
        filters = get_filters_data()
        print(f"Filtros cargados: {len(filters['clients'])} clientes, {len(filters['marcas'])} marcas.")
        res = get_matrix_data(unidad_medida="S/ SOLES", unidad_negocio=["FARMA"], categorizacion=["DIAMANTE"])
        print(f"Marcas procesadas en matriz: {len(res['brands'])}")
        print("Totales (FARMA + DIAMANTE):", res['totals'])
    except Exception as ex:
        print("Error al probar:", ex)

