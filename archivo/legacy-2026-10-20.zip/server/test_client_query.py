from data_engine import run_dax_query
import json

print("Testing Client Breakdown...")
query = """
EVALUATE
CALCULATETABLE(
    SUMMARIZECOLUMNS(
        DIM_MATERIAL[Marca_MKT],
        DIM_CLIENTE[CP_cliente],
        "COMPRA", [M_ESTADO_Y_UNIDADES_v2],
        "QUINTIL", [M_CATEGORIZACION]
    ),
    DIM_MATERIAL[Marca_MKT] = "GASEOVET",
    AUX_UNIDAD_MEDIDA[unidadMedida] = "UNIDAD"
)
"""
rows = run_dax_query(query)
print(f"GASEOVET clients count: {len(rows)}")
for r in rows[:8]:
    print(r)
