import os
import sys
import json
import urllib.request
import time
import subprocess

print("==================================================")
print("Prueba E2E: Endpoint /api/client-matrix")
print("==================================================")

# 1. Iniciar servidor backend
server_proc = subprocess.Popen([sys.executable, "server/server.py"])
time.sleep(3)

try:
    # 2. Consultar health
    req = urllib.request.urlopen("http://localhost:8080/api/health", timeout=5)
    print("1. Health check:", req.read().decode('utf-8'))

    # 3. Consultar /api/client-matrix para cliente 20481921491
    payload = json.dumps({
        "client": "20481921491",
        "unidadMedida": "S/ SOLES",
        "unidadNegocio": ["FARMA"]
    }).encode('utf-8')

    req = urllib.request.Request(
        "http://localhost:8080/api/client-matrix",
        data=payload,
        headers={"Content-Type": "application/json"}
    )
    resp = urllib.request.urlopen(req, timeout=30)
    data = json.loads(resp.read().decode('utf-8'))

    print("2. Success:", data.get('success'))
    cdata = data.get('data', {})
    print("3. Cliente info:", cdata.get('client'))
    print("4. Totales:", cdata.get('totals'))
    print("5. Total marcas devueltas:", len(cdata.get('brands', [])))

    gaseovet = next((b for b in cdata.get('brands', []) if b['marca'] == 'GASEOVET'), None)
    if gaseovet:
        print("\n6. Detalle GASEOVET para este cliente:")
        print(f"   VTA. ACT: {gaseovet['vta_act']:,.2f}")
        print(f"   VTA. MDO: {gaseovet['vta_mdo']:,.2f}")
        print(f"   MS. ACT: {gaseovet['ms_act']:.1%}")
        print(f"   MS. TERRITORIO: {gaseovet['ms_territorio']:.1%}")
        print(f"   MS. IDEAL: {gaseovet['ms_ideal']:.1%}")
        print(f"   ESTIMACION: {gaseovet['estimacion']:,.2f}")
        print(f"   SKUs count: {len(gaseovet['skus'])}")
        for sku in gaseovet['skus'][:3]:
            print(f"     - {sku['sku']}: Act={sku['vta_act']:,.2f} | Mdo={sku['vta_mdo']:,.2f} | MS={sku['ms_act']:.1%} | Ideal={sku['ms_ideal']:.1%} | Est={sku['estimacion']:,.2f}")

    print("\n[EXITO] Prueba completada con éxito.")
finally:
    server_proc.terminate()
    print("Servidor detenido.")
