import sys
import os
import json
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from data_engine import get_filters_data, get_db_connection, fetch_all_dict, escape_sql_str

def get_single_client_matrix(client_ruc_or_cp, unidad_medida="S/ SOLES", unidad_negocio=None, franquicia=None, marca=None, search=""):
    metrica_sql = 'VALOR' if 'SOL' in (unidad_medida or '').upper() else 'UNIDAD'
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(f"SELECT TOP 1 ruc, farmacia, cp_cliente, lima_provincias, categorizacion, quintil FROM dbo.DIM_CLIENTE WHERE cp_cliente = {escape_sql_str(client_ruc_or_cp)} OR ruc = {escape_sql_str(client_ruc_or_cp)}")
    cli = fetch_all_dict(cursor)
    if not cli:
        conn.close()
        return None
    client_info = cli[0]
    ruc = client_info['ruc']
    lima_provincias = client_info['lima_provincias'] or 'LIMA'
    
    mat_filters = []
    if unidad_negocio and len(unidad_negocio) > 0:
        un_in = ", ".join([escape_sql_str(u) for u in unidad_negocio if u])
        if un_in:
            mat_filters.append(f"m.unidad_negocio IN ({un_in})")
    if franquicia and len(franquicia) > 0:
        fr_in = ", ".join([escape_sql_str(f) for f in franquicia if f])
        if fr_in:
            mat_filters.append(f"m.franquicia IN ({fr_in})")
    if marca and len(marca) > 0:
        ma_in = ", ".join([escape_sql_str(m) for m in marca if m])
        if ma_in:
            mat_filters.append(f"m.marca_mkt IN ({ma_in})")
            
    where_mat = ("AND " + " AND ".join(mat_filters)) if mat_filters else ""
    where_mat_vt = where_mat.replace('m.', 'vt.')
    
    q_client = f"""
    WITH 
    -- Catálogo de productos Medifarma filtrados
    CATALOGO_MEDIFARMA AS (
        SELECT DISTINCT
            m.unidad_negocio,
            m.franquicia,
            m.marca_mkt,
            m.cp_presentacion,
            m.mercado
        FROM dbo.DIM_MATERIAL m
        WHERE m.es_competidor = 0 
          AND m.marca_mkt IS NOT NULL 
          AND m.marca_mkt <> '' 
          AND m.marca_mkt <> 'COMPETIDORES'
          {where_mat}
    ),
    CATALOGO_MARCAS AS (
        SELECT DISTINCT
            unidad_negocio,
            franquicia,
            marca_mkt
        FROM CATALOGO_MEDIFARMA
    ),
    -- Ventas totales en este cliente (Medifarma + Competencia)
    VENTAS_CLIENTE AS (
        SELECT 
            f.codigo_presentacion,
            m.cp_presentacion,
            m.unidad_negocio,
            m.franquicia,
            m.marca_mkt,
            m.mercado,
            m.es_competidor,
            f.vta_actual,
            f.vta_anterior
        FROM dbo.FACT_VENTAS_AGREGADA f
        INNER JOIN dbo.DIM_MATERIAL m ON f.codigo_presentacion = m.codigo_presentacion
        WHERE f.metrica = '{metrica_sql}'
          AND f.ruc = '{ruc}'
    ),
    -- Mercado Total por Mercado en este cliente
    TOTAL_MERCADO_CLIENTE AS (
        SELECT 
            mercado,
            SUM(vta_actual) AS mdo_actual,
            SUM(vta_anterior) AS mdo_anterior
        FROM VENTAS_CLIENTE
        GROUP BY mercado
    ),
    -- Ventas Medifarma del cliente por SKU
    VENTAS_SKU_CLIENTE AS (
        SELECT 
            cp_presentacion,
            mercado,
            SUM(vta_actual) AS vta_act,
            SUM(vta_anterior) AS vta_ant
        FROM VENTAS_CLIENTE
        WHERE es_competidor = 0 AND marca_mkt <> 'COMPETIDORES'
        GROUP BY cp_presentacion, mercado
    ),
    -- Ventas Medifarma del cliente por Marca
    VENTAS_MARCA_CLIENTE AS (
        SELECT 
            unidad_negocio,
            franquicia,
            marca_mkt,
            SUM(vta_actual) AS vta_act,
            SUM(vta_anterior) AS vta_ant
        FROM VENTAS_CLIENTE
        WHERE es_competidor = 0 AND marca_mkt <> 'COMPETIDORES'
        GROUP BY unidad_negocio, franquicia, marca_mkt
    ),
    -- Mercado Total por Marca en este cliente
    MERCADO_MARCA_CLIENTE AS (
        SELECT 
            cm.unidad_negocio,
            cm.franquicia,
            cm.marca_mkt,
            SUM(COALESCE(tmc.mdo_actual, 0)) AS mdo_actual_tot,
            SUM(COALESCE(tmc.mdo_anterior, 0)) AS mdo_anterior_tot
        FROM (
            SELECT DISTINCT unidad_negocio, franquicia, marca_mkt, mercado
            FROM CATALOGO_MEDIFARMA
        ) cm
        INNER JOIN TOTAL_MERCADO_CLIENTE tmc ON cm.mercado = tmc.mercado
        GROUP BY cm.unidad_negocio, cm.franquicia, cm.marca_mkt
    ),
    -- Base Territorial (benchmark de la zona del cliente)
    VENTAS_TERRITORIO AS (
        SELECT 
            f.codigo_presentacion,
            m.cp_presentacion,
            m.unidad_negocio,
            m.franquicia,
            m.marca_mkt,
            m.mercado,
            m.es_competidor,
            f.vta_actual
        FROM dbo.FACT_VENTAS_AGREGADA f
        INNER JOIN dbo.DIM_MATERIAL m ON f.codigo_presentacion = m.codigo_presentacion
        INNER JOIN dbo.DIM_CLIENTE c ON f.ruc = c.ruc
        WHERE f.metrica = '{metrica_sql}'
          AND c.lima_provincias = '{lima_provincias}'
          AND c.categorizacion IN ('DIAMANTE', 'ORO', 'PLATA', 'BRONCE', 'PLOMO')
    ),
    TOTAL_MERCADO_TERRITORIO AS (
        SELECT 
            mercado,
            SUM(vta_actual) AS mdo_territorio
        FROM VENTAS_TERRITORIO
        GROUP BY mercado
    ),
    MERCADO_MARCA_TERRITORIO AS (
        SELECT 
            cm.unidad_negocio,
            cm.franquicia,
            cm.marca_mkt,
            SUM(mt.mdo_territorio) AS mdo_marca_territorio
        FROM (
            SELECT DISTINCT unidad_negocio, franquicia, marca_mkt, mercado
            FROM CATALOGO_MEDIFARMA
        ) cm
        INNER JOIN TOTAL_MERCADO_TERRITORIO mt ON cm.mercado = mt.mercado
        GROUP BY cm.unidad_negocio, cm.franquicia, cm.marca_mkt
    ),
    MS_TERRITORIO_SKU AS (
        SELECT 
            vt.mercado,
            vt.cp_presentacion,
            CASE WHEN COALESCE(mt.mdo_territorio, 0) > 0 
                 THEN SUM(vt.vta_actual) * 1.0 / mt.mdo_territorio ELSE 0.0 END AS ms_territorio
        FROM VENTAS_TERRITORIO vt
        INNER JOIN TOTAL_MERCADO_TERRITORIO mt ON vt.mercado = mt.mercado
        WHERE vt.es_competidor = 0 AND vt.marca_mkt <> 'COMPETIDORES'
        GROUP BY vt.mercado, vt.cp_presentacion, mt.mdo_territorio
    ),
    MS_TERRITORIO_MARCA AS (
        SELECT 
            vt.unidad_negocio,
            vt.franquicia,
            vt.marca_mkt,
            CASE WHEN COALESCE(mmt.mdo_marca_territorio, 0) > 0 
                 THEN SUM(vt.vta_actual) * 1.0 / mmt.mdo_marca_territorio ELSE 0.0 END AS ms_territorio
        FROM VENTAS_TERRITORIO vt
        INNER JOIN MERCADO_MARCA_TERRITORIO mmt 
            ON vt.unidad_negocio = mmt.unidad_negocio 
           AND vt.franquicia = mmt.franquicia 
           AND vt.marca_mkt = mmt.marca_mkt
        WHERE vt.es_competidor = 0 AND vt.marca_mkt <> 'COMPETIDORES'
        GROUP BY vt.unidad_negocio, vt.franquicia, vt.marca_mkt, mmt.mdo_marca_territorio
    )
    -- Consulta de SKUs del cliente
    SELECT 
        'SKU' AS tipo_fila,
        c.unidad_negocio,
        c.franquicia,
        c.marca_mkt,
        c.cp_presentacion,
        COALESCE(vsc.vta_act, 0.0) / 5.0 AS vta_act,
        COALESCE(tmc.mdo_actual, 0.0) / 5.0 AS vta_mdo,
        COALESCE(vsc.vta_ant, 0.0) / 5.0 AS vta_ant,
        COALESCE(tmc.mdo_anterior, 0.0) / 5.0 AS vta_mdo_ant,
        CASE WHEN COALESCE(tmc.mdo_actual, 0) > 0 THEN COALESCE(vsc.vta_act, 0) * 1.0 / tmc.mdo_actual ELSE 0.0 END AS ms_act,
        CASE WHEN COALESCE(tmc.mdo_anterior, 0) > 0 THEN COALESCE(vsc.vta_ant, 0) * 1.0 / tmc.mdo_anterior ELSE 0.0 END AS ms_ant,
        COALESCE(zsku.ms_territorio, 0.0) AS ms_territorio
    FROM CATALOGO_MEDIFARMA c
    LEFT JOIN TOTAL_MERCADO_CLIENTE tmc ON c.mercado = tmc.mercado
    LEFT JOIN VENTAS_SKU_CLIENTE vsc ON c.cp_presentacion = vsc.cp_presentacion
    LEFT JOIN MS_TERRITORIO_SKU zsku ON c.mercado = zsku.mercado AND c.cp_presentacion = zsku.cp_presentacion

    UNION ALL

    -- Consulta de Marcas del cliente
    SELECT 
        'BRAND' AS tipo_fila,
        cm.unidad_negocio,
        cm.franquicia,
        cm.marca_mkt,
        '' AS cp_presentacion,
        COALESCE(vmc.vta_act, 0.0) / 5.0 AS vta_act,
        COALESCE(mmc.mdo_actual_tot, 0.0) / 5.0 AS vta_mdo,
        COALESCE(vmc.vta_ant, 0.0) / 5.0 AS vta_ant,
        COALESCE(mmc.mdo_anterior_tot, 0.0) / 5.0 AS vta_mdo_ant,
        CASE WHEN COALESCE(mmc.mdo_actual_tot, 0) > 0 THEN COALESCE(vmc.vta_act, 0) * 1.0 / mmc.mdo_actual_tot ELSE 0.0 END AS ms_act,
        CASE WHEN COALESCE(mmc.mdo_anterior_tot, 0) > 0 THEN COALESCE(vmc.vta_ant, 0) * 1.0 / mmc.mdo_anterior_tot ELSE 0.0 END AS ms_ant,
        COALESCE(zm.ms_territorio, 0.0) AS ms_territorio
    FROM CATALOGO_MARCAS cm
    LEFT JOIN VENTAS_MARCA_CLIENTE vmc ON cm.unidad_negocio = vmc.unidad_negocio AND cm.franquicia = vmc.franquicia AND cm.marca_mkt = vmc.marca_mkt
    LEFT JOIN MERCADO_MARCA_CLIENTE mmc ON cm.unidad_negocio = mmc.unidad_negocio AND cm.franquicia = mmc.franquicia AND cm.marca_mkt = mmc.marca_mkt
    LEFT JOIN MS_TERRITORIO_MARCA zm ON cm.unidad_negocio = zm.unidad_negocio AND cm.franquicia = zm.franquicia AND cm.marca_mkt = zm.marca_mkt

    UNION ALL

    -- Total Mercado Distinto para este cliente
    SELECT 
        'DISTINCT_MERCADO' AS tipo_fila,
        '' AS unidad_negocio,
        '' AS franquicia,
        '' AS marca_mkt,
        '' AS cp_presentacion,
        0.0 AS vta_act,
        SUM(tmc.mdo_actual) / 5.0 AS vta_mdo,
        0.0 AS vta_ant,
        SUM(tmc.mdo_anterior) / 5.0 AS vta_mdo_ant,
        0.0 AS ms_act,
        0.0 AS ms_ant,
        0.0 AS ms_territorio
    FROM TOTAL_MERCADO_CLIENTE tmc
    INNER JOIN (
        SELECT DISTINCT mercado
        FROM CATALOGO_MEDIFARMA
    ) dm ON tmc.mercado = dm.mercado

    UNION ALL

    -- Total Territorio (para MS Territorio total)
    SELECT 
        'TOTAL_TERRITORIO' AS tipo_fila,
        '' AS unidad_negocio,
        '' AS franquicia,
        '' AS marca_mkt,
        '' AS cp_presentacion,
        SUM(CASE WHEN vt.es_competidor = 0 AND vt.marca_mkt <> 'COMPETIDORES' {where_mat_vt} THEN vt.vta_actual ELSE 0.0 END) / 5.0 AS vta_act,
        SUM(vt.vta_actual) / 5.0 AS vta_mdo,
        0.0 AS vta_ant,
        0.0 AS vta_mdo_ant,
        0.0 AS ms_act,
        0.0 AS ms_ant,
        0.0 AS ms_territorio
    FROM VENTAS_TERRITORIO vt
    INNER JOIN (
        SELECT DISTINCT mercado
        FROM CATALOGO_MEDIFARMA
    ) mf ON vt.mercado = mf.mercado;
    """
    
    cursor.execute(q_client)
    all_rows = fetch_all_dict(cursor)
    conn.close()
    
    skus_dict = {}
    brands_list = []
    tot_mdo_row = None
    tot_terr_row = None
    
    for r in all_rows:
        tf = r.get('tipo_fila')
        if tf == 'DISTINCT_MERCADO':
            tot_mdo_row = r
            continue
        elif tf == 'TOTAL_TERRITORIO':
            tot_terr_row = r
            continue
            
        ms_act = float(r.get('ms_act') or 0)
        ms_ant = float(r.get('ms_ant') or 0)
        ms_ter = float(r.get('ms_territorio') or 0)
        vta_act = float(r.get('vta_act') or 0)
        vta_mdo = float(r.get('vta_mdo') or 0)
        vta_ant = float(r.get('vta_ant') or 0)
        vta_mdo_ant = float(r.get('vta_mdo_ant') or 0)
        
        ms_ideal = max(ms_act, ms_ant, ms_ter)
        construccion = 0.0 if ms_act >= ms_ideal else (ms_ideal - ms_act)
        valorizacion = (vta_mdo * 5.0) * construccion
        estimacion = (valorizacion + (vta_act * 5.0)) / 5.0
        
        un = r.get('unidad_negocio')
        fr = r.get('franquicia')
        m = r.get('marca_mkt')
        p = r.get('cp_presentacion')
        
        if tf == 'SKU':
            sku_obj = {
                'sku': p,
                'vta_act': vta_act,
                'vta_mdo': vta_mdo,
                'ms_act': ms_act,
                'ms_ant': ms_ant,
                'ms_territorio': ms_ter,
                'ms_ideal': ms_ideal,
                'estimacion': estimacion
            }
            skus_dict.setdefault((un, fr, m), []).append(sku_obj)
        else:
            brand_obj = {
                'marca': m,
                'unidad_negocio': un,
                'franquicia': fr,
                'vta_act': vta_act,
                'vta_mdo': vta_mdo,
                'ms_act': ms_act,
                'ms_ant': ms_ant,
                'ms_territorio': ms_ter,
                'ms_ideal': ms_ideal,
                'estimacion': estimacion,
                'skus': []
            }
            brands_list.append(brand_obj)
            
    # Asignar skus a marcas
    for b in brands_list:
        b_key = (b['unidad_negocio'], b['franquicia'], b['marca'])
        b_skus = skus_dict.get(b_key, [])
        b_skus.sort(key=lambda x: x['vta_act'], reverse=True)
        b['skus'] = b_skus
        
    if search:
        s_lower = search.lower()
        brands_list = [
            b for b in brands_list 
            if s_lower in b['marca'].lower() or any(s_lower in s['sku'].lower() for s in b['skus'])
        ]
        
    brands_list.sort(key=lambda x: x['estimacion'], reverse=True)
    
    tot_vta_act = sum(b['vta_act'] for b in brands_list)
    tot_vta_mdo = float(tot_mdo_row['vta_mdo']) if tot_mdo_row and float(tot_mdo_row.get('vta_mdo') or 0) > 0 else sum(b['vta_mdo'] for b in brands_list)
    tot_vta_ant = sum(b.get('vta_ant', 0) for b in brands_list)
    tot_vta_mdo_ant = float(tot_mdo_row['vta_mdo_ant']) if tot_mdo_row and float(tot_mdo_row.get('vta_mdo_ant') or 0) > 0 else 0.0

    tot_ms_act = (tot_vta_act / tot_vta_mdo) if tot_vta_mdo > 0 else 0.0
    tot_ms_ant = (tot_vta_ant / tot_vta_mdo_ant) if tot_vta_mdo_ant > 0 else 0.0

    if tot_terr_row and float(tot_terr_row.get('vta_mdo') or 0) > 0:
        tot_ms_territorio = float(tot_terr_row.get('vta_act') or 0) / float(tot_terr_row.get('vta_mdo') or 1)
    else:
        tot_ms_territorio = tot_ms_act

    tot_ms_ideal = max(tot_ms_act, tot_ms_ant, tot_ms_territorio)
    tot_construccion = 0.0 if tot_ms_act >= tot_ms_ideal else (tot_ms_ideal - tot_ms_act)
    tot_estimacion = ((tot_vta_mdo * 5.0 * tot_construccion) + (tot_vta_act * 5.0)) / 5.0

    totals = {
        'marca': 'Total General',
        'vta_act': tot_vta_act,
        'vta_mdo': tot_vta_mdo,
        'ms_act': tot_ms_act,
        'ms_ant': tot_ms_ant,
        'ms_territorio': tot_ms_territorio,
        'ms_ideal': tot_ms_ideal,
        'estimacion': tot_estimacion
    }
    
    return {
        'client': client_info,
        'unidad_medida': unidad_medida,
        'periodo': 'Enero 2026 - Mayo 2026',
        'brands': brands_list,
        'totals': totals,
        'total_brands_count': len(brands_list)
    }

if __name__ == '__main__':
    res = get_single_client_matrix('20481921491', unidad_medida="S/ SOLES", unidad_negocio=["FARMA"])
    print("Cliente:", res['client'])
    print("Total General:", res['totals'])
    print("Total Marcas:", len(res['brands']))
    gaseovet = next((b for b in res['brands'] if b['marca'] == 'GASEOVET'), None)
    if gaseovet:
        print("GASEOVET Marca:", json.dumps({k: v for k, v in gaseovet.items() if k != 'skus'}, indent=2))
        print("GASEOVET SKUs count:", len(gaseovet['skus']))
        for s in gaseovet['skus'][:3]:
            print("  SKU:", s)
