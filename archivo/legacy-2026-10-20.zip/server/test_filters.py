from data_engine import run_dax_query
import json

print("Testing filters extraction...")

# Get Materials metadata
mat_query = """
EVALUATE
SUMMARIZE(
    DIM_MATERIAL,
    DIM_MATERIAL[Unidad_Negocio],
    DIM_MATERIAL[Franquicia],
    DIM_MATERIAL[Marca_MKT]
)
"""
mat_filters = run_dax_query(mat_query)
print("Materials filters sample:", mat_filters[:5])

# Get Clients metadata
cli_query = """
EVALUATE
TOPN(20,
    SUMMARIZE(
        DIM_CLIENTE,
        DIM_CLIENTE[CP_cliente],
        DIM_CLIENTE[CP_categorizacion],
        DIM_CLIENTE[CP_quintil]
    )
)
"""
cli_filters = run_dax_query(cli_query)
print("Clients filters sample:", cli_filters[:5])
