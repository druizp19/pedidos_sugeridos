import os
import sys
from pathlib import Path

# Cargar .env desde la raíz del proyecto
root_dir = Path(__file__).resolve().parent.parent
env_file = root_dir / '.env'

if env_file.exists():
    from dotenv import load_dotenv
    load_dotenv(env_file)
    print(f"[OK] Archivo .env cargado desde: {env_file}")
else:
    print(f"[WARN] No se encontro archivo .env en: {env_file}")

server = os.getenv('DB_SERVER', '172.17.2.181')
port = os.getenv('DB_PORT', '1433')
database = os.getenv('DB_NAME', 'VW_FR')
user = os.getenv('DB_USER')
password = os.getenv('DB_PASSWORD')

print("\n--- Diagnóstico de Configuración SQL Server ---")
print(f"Servidor  : {server}:{port}")
print(f"Base Datos: {database}")
print(f"Usuario   : {user or '(Vacio - por favor define DB_USER en .env)'}")
print(f"Password  : {'*' * len(password) if password else '(Vacio - por favor define DB_PASSWORD en .env)'}")

if not user or not password:
    print("\n[!] Por favor ingresa tu DB_USER y DB_PASSWORD en el archivo .env antes de probar la conexion.")
    sys.exit(1)

# Conectar usando pymssql o pyodbc
conn = None
driver_used = None

try:
    import pymssql
    print("\nIntentando conectar con pymssql...")
    conn = pymssql.connect(
        server=server,
        port=str(port),
        user=user,
        password=password,
        database=database,
        timeout=10,
        login_timeout=10,
        charset='UTF-8'
    )
    driver_used = "pymssql"
except ImportError:
    pass
except Exception as e:
    print(f"  [pymssql falló]: {e}")

if conn is None:
    try:
        import pyodbc
        print("\nIntentando conectar con pyodbc...")
        drivers = [d for d in pyodbc.drivers() if 'SQL Server' in d]
        driver_name = drivers[0] if drivers else 'ODBC Driver 17 for SQL Server'
        conn_str = f"DRIVER={{{driver_name}}};SERVER={server},{port};DATABASE={database};UID={user};PWD={password}"
        conn = pyodbc.connect(conn_str, timeout=10)
        driver_used = f"pyodbc ({driver_name})"
    except ImportError:
        pass
    except Exception as e:
        print(f"  [pyodbc falló]: {e}")

if conn is None:
    print("\n[ERROR] No se pudo establecer conexion a SQL Server.")
    print("Asegurate de instalar: pip install pymssql")
    sys.exit(1)

print(f"[EXITO] Conectado exitosamente via {driver_used}!")

try:
    cursor = conn.cursor()
    cursor.execute("SELECT @@VERSION AS version, DB_NAME() AS current_db")
    row = cursor.fetchone()
    print(f"Base de datos actual: {row[1]}")
    print(f"Version: {str(row[0])[:60]}...")

    print("\n--- Verificando Tablas del Modelo ---")
    tablas = ['DIM_CLIENTE', 'DIM_MATERIAL', 'FACT_VENTAS_AGREGADA']
    for t in tablas:
        try:
            cursor.execute(f"SELECT COUNT(*) FROM dbo.{t}")
            cnt = cursor.fetchone()[0]
            print(f"  [OK] dbo.{t}: {cnt:,} filas")
        except Exception as te:
            print(f"  [ERROR] Al consultar dbo.{t}: {te}")

    conn.close()
    print("\n[EXITO] Todo configurado y validado correctamente.")
except Exception as ex:
    print(f"\n[ERROR] Error al consultar datos: {ex}")
    sys.exit(1)
