import sys
import os
import json
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from data_engine import get_db_connection, fetch_all_dict, escape_sql_str

def test_client_totals(client_ruc_or_cp, unidad_medida="S/ SOLES", unidad_negocio=["FARMA"]):
    metrica_sql = 'VALOR' if 'SOL' in (unidad_medida or '').upper() else 'UNIDAD'
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(f"SELECT TOP 1 ruc, farmacia, cp_cliente, lima_provincias, categorizacion, quintil FROM dbo.DIM_CLIENTE WHERE cp_cliente = {escape_sql_str(client_ruc_or_cp)} OR ruc = {escape_sql_str(client_ruc_or_cp)}")
    cli = fetch_all_dict(cursor)
    if not cli:
        print("Cliente no encontrado")
        return
    client_info = cli[0]
    ruc = client_info['ruc']
    lima_provincias = client_info['lima_provincias'] or 'LIMA'
    
    un_in = ", ".join([escape_sql_str(u) for u in unidad_negocio if u]) if unidad_negocio else ""
    where_mat = f"AND m.unidad_negocio IN ({un_in})" if un_in else ""
    where_mat_vt = where_mat.replace('m.', 'vt.')
    
    q = f"""
    WITH 
    CATALOGO_MEDIFARMA AS (
        SELECT DISTINCT
            m.unidad_negocio,
            m.franquicia,
            m.marca_mkt,
            m.cp_presentacion,
            m.mercado
        FROM dbo.DIM_MATERIAL m
        WHERE m.es_competidor = 0 
          AND m.marca_mkt IS NOT NULL 
          AND m.marca_mkt <> '' 
          AND m.marca_mkt <> 'COMPETIDORES'
          AND m.mercado IS NOT NULL
          AND m.mercado <> ''
          AND m.mercado <> 'RESTO'
          {where_mat}
    ),
    CATALOGO_MARCAS AS (
        SELECT DISTINCT
            unidad_negocio,
            franquicia,
            marca_mkt
        FROM CATALOGO_MEDIFARMA
    ),
    VENTAS_CLIENTE AS (
        SELECT 
            f.codigo_presentacion,
            m.cp_presentacion,
            m.unidad_negocio,
            m.franquicia,
            m.marca_mkt,
            m.mercado,
            m.es_competidor,
            f.vta_actual,
            f.vta_anterior
        FROM dbo.FACT_VENTAS_AGREGADA f
        INNER JOIN dbo.DIM_MATERIAL m ON f.codigo_presentacion = m.codigo_presentacion
        WHERE f.metrica = '{metrica_sql}'
          AND f.ruc = '{ruc}'
    ),
    TOTAL_MERCADO_CLIENTE AS (
        SELECT 
            mercado,
            SUM(vta_actual) AS mdo_actual,
            SUM(vta_anterior) AS mdo_anterior
        FROM VENTAS_CLIENTE
        WHERE mercado IS NOT NULL AND mercado <> '' AND mercado <> 'RESTO'
        GROUP BY mercado
    ),
    VENTAS_SKU_CLIENTE AS (
        SELECT 
            cp_presentacion,
            mercado,
            SUM(vta_actual) AS vta_act,
            SUM(vta_anterior) AS vta_ant
        FROM VENTAS_CLIENTE
        WHERE es_competidor = 0 AND marca_mkt <> 'COMPETIDORES'
        GROUP BY cp_presentacion, mercado
    ),
    VENTAS_MARCA_CLIENTE AS (
        SELECT 
            unidad_negocio,
            franquicia,
            marca_mkt,
            SUM(vta_actual) AS vta_act,
            SUM(vta_anterior) AS vta_ant
        FROM VENTAS_CLIENTE
        WHERE es_competidor = 0 AND marca_mkt <> 'COMPETIDORES'
        GROUP BY unidad_negocio, franquicia, marca_mkt
    ),
    MERCADO_MARCA_CLIENTE AS (
        SELECT 
            cm.unidad_negocio,
            cm.franquicia,
            cm.marca_mkt,
            SUM(COALESCE(tmc.mdo_actual, 0)) AS mdo_actual_tot,
            SUM(COALESCE(tmc.mdo_anterior, 0)) AS mdo_anterior_tot
        FROM (
            SELECT DISTINCT unidad_negocio, franquicia, marca_mkt, mercado
            FROM CATALOGO_MEDIFARMA
        ) cm
        INNER JOIN TOTAL_MERCADO_CLIENTE tmc ON cm.mercado = tmc.mercado
        GROUP BY cm.unidad_negocio, cm.franquicia, cm.marca_mkt
    ),
    VENTAS_TERRITORIO AS (
        SELECT 
            f.codigo_presentacion,
            m.cp_presentacion,
            m.unidad_negocio,
            m.franquicia,
            m.marca_mkt,
            m.mercado,
            m.es_competidor,
            f.vta_actual
        FROM dbo.FACT_VENTAS_AGREGADA f
        INNER JOIN dbo.DIM_MATERIAL m ON f.codigo_presentacion = m.codigo_presentacion
        INNER JOIN dbo.DIM_CLIENTE c ON f.ruc = c.ruc
        WHERE f.metrica = '{metrica_sql}'
          AND c.lima_provincias = '{lima_provincias}'
          AND c.categorizacion IN ('DIAMANTE', 'ORO', 'PLATA', 'BRONCE', 'PLOMO')
    ),
    TOTAL_MERCADO_TERRITORIO AS (
        SELECT 
            mercado,
            SUM(vta_actual) AS mdo_territorio
        FROM VENTAS_TERRITORIO
        WHERE mercado IS NOT NULL AND mercado <> '' AND mercado <> 'RESTO'
        GROUP BY mercado
    ),
    MERCADO_MARCA_TERRITORIO AS (
        SELECT 
            cm.unidad_negocio,
            cm.franquicia,
            cm.marca_mkt,
            SUM(mt.mdo_territorio) AS mdo_marca_territorio
        FROM (
            SELECT DISTINCT unidad_negocio, franquicia, marca_mkt, mercado
            FROM CATALOGO_MEDIFARMA
        ) cm
        INNER JOIN TOTAL_MERCADO_TERRITORIO mt ON cm.mercado = mt.mercado
        GROUP BY cm.unidad_negocio, cm.franquicia, cm.marca_mkt
    ),
    MS_TERRITORIO_SKU AS (
        SELECT 
            vt.mercado,
            vt.cp_presentacion,
            CASE WHEN COALESCE(mt.mdo_territorio, 0) > 0 
                 THEN SUM(vt.vta_actual) * 1.0 / mt.mdo_territorio ELSE 0.0 END AS ms_territorio
        FROM VENTAS_TERRITORIO vt
        INNER JOIN TOTAL_MERCADO_TERRITORIO mt ON vt.mercado = mt.mercado
        WHERE vt.es_competidor = 0 AND vt.marca_mkt <> 'COMPETIDORES'
        GROUP BY vt.mercado, vt.cp_presentacion, mt.mdo_territorio
    ),
    MS_TERRITORIO_MARCA AS (
        SELECT 
            vt.unidad_negocio,
            vt.franquicia,
            vt.marca_mkt,
            CASE WHEN COALESCE(mmt.mdo_marca_territorio, 0) > 0 
                 THEN SUM(vt.vta_actual) * 1.0 / mmt.mdo_marca_territorio ELSE 0.0 END AS ms_territorio
        FROM VENTAS_TERRITORIO vt
        INNER JOIN MERCADO_MARCA_TERRITORIO mmt 
            ON vt.unidad_negocio = mmt.unidad_negocio 
           AND vt.franquicia = mmt.franquicia 
           AND vt.marca_mkt = mmt.marca_mkt
        WHERE vt.es_competidor = 0 AND vt.marca_mkt <> 'COMPETIDORES'
        GROUP BY vt.unidad_negocio, vt.franquicia, vt.marca_mkt, mmt.mdo_marca_territorio
    )
    SELECT 
        'SKU' AS tipo_fila,
        c.unidad_negocio,
        c.franquicia,
        c.marca_mkt,
        c.cp_presentacion,
        COALESCE(vsc.vta_act, 0.0) / 5.0 AS vta_act,
        COALESCE(tmc.mdo_actual, 0.0) / 5.0 AS vta_mdo,
        COALESCE(vsc.vta_ant, 0.0) / 5.0 AS vta_ant,
        COALESCE(tmc.mdo_anterior, 0.0) / 5.0 AS vta_mdo_ant,
        CASE WHEN COALESCE(tmc.mdo_actual, 0) > 0 THEN COALESCE(vsc.vta_act, 0) * 1.0 / tmc.mdo_actual ELSE 0.0 END AS ms_act,
        CASE WHEN COALESCE(tmc.mdo_anterior, 0) > 0 THEN COALESCE(vsc.vta_ant, 0) * 1.0 / tmc.mdo_anterior ELSE 0.0 END AS ms_ant,
        COALESCE(zsku.ms_territorio, 0.0) AS ms_territorio
    FROM CATALOGO_MEDIFARMA c
    LEFT JOIN TOTAL_MERCADO_CLIENTE tmc ON c.mercado = tmc.mercado
    LEFT JOIN VENTAS_SKU_CLIENTE vsc ON c.cp_presentacion = vsc.cp_presentacion
    LEFT JOIN MS_TERRITORIO_SKU zsku ON c.mercado = zsku.mercado AND c.cp_presentacion = zsku.cp_presentacion

    UNION ALL

    SELECT 
        'BRAND' AS tipo_fila,
        cm.unidad_negocio,
        cm.franquicia,
        cm.marca_mkt,
        '' AS cp_presentacion,
        COALESCE(vmc.vta_act, 0.0) / 5.0 AS vta_act,
        COALESCE(mmc.mdo_actual_tot, 0.0) / 5.0 AS vta_mdo,
        COALESCE(vmc.vta_ant, 0.0) / 5.0 AS vta_ant,
        COALESCE(mmc.mdo_anterior_tot, 0.0) / 5.0 AS vta_mdo_ant,
        CASE WHEN COALESCE(mmc.mdo_actual_tot, 0) > 0 THEN COALESCE(vmc.vta_act, 0) * 1.0 / mmc.mdo_actual_tot ELSE 0.0 END AS ms_act,
        CASE WHEN COALESCE(mmc.mdo_anterior_tot, 0) > 0 THEN COALESCE(vmc.vta_ant, 0) * 1.0 / mmc.mdo_anterior_tot ELSE 0.0 END AS ms_ant,
        COALESCE(zm.ms_territorio, 0.0) AS ms_territorio
    FROM CATALOGO_MARCAS cm
    LEFT JOIN VENTAS_MARCA_CLIENTE vmc ON cm.unidad_negocio = vmc.unidad_negocio AND cm.franquicia = vmc.franquicia AND cm.marca_mkt = vmc.marca_mkt
    LEFT JOIN MERCADO_MARCA_CLIENTE mmc ON cm.unidad_negocio = mmc.unidad_negocio AND cm.franquicia = mmc.franquicia AND cm.marca_mkt = mmc.marca_mkt
    LEFT JOIN MS_TERRITORIO_MARCA zm ON cm.unidad_negocio = zm.unidad_negocio AND cm.franquicia = zm.franquicia AND cm.marca_mkt = zm.marca_mkt

    UNION ALL

    SELECT 
        'DISTINCT_MERCADO' AS tipo_fila,
        '' AS unidad_negocio,
        '' AS franquicia,
        '' AS marca_mkt,
        '' AS cp_presentacion,
        0.0 AS vta_act,
        SUM(tmc.mdo_actual) / 5.0 AS vta_mdo,
        0.0 AS vta_ant,
        SUM(tmc.mdo_anterior) / 5.0 AS vta_mdo_ant,
        0.0 AS ms_act,
        0.0 AS ms_ant,
        0.0 AS ms_territorio
    FROM TOTAL_MERCADO_CLIENTE tmc
    INNER JOIN (
        SELECT DISTINCT mercado
        FROM CATALOGO_MEDIFARMA
    ) dm ON tmc.mercado = dm.mercado

    UNION ALL

    SELECT 
        'TOTAL_TERRITORIO' AS tipo_fila,
        '' AS unidad_negocio,
        '' AS franquicia,
        '' AS marca_mkt,
        '' AS cp_presentacion,
        SUM(CASE WHEN vt.es_competidor = 0 AND vt.marca_mkt <> 'COMPETIDORES' {where_mat_vt} THEN vt.vta_actual ELSE 0.0 END) / 5.0 AS vta_act,
        SUM(vt.vta_actual) / 5.0 AS vta_mdo,
        0.0 AS vta_ant,
        0.0 AS vta_mdo_ant,
        0.0 AS ms_act,
        0.0 AS ms_ant,
        0.0 AS ms_territorio
    FROM VENTAS_TERRITORIO vt
    INNER JOIN (
        SELECT DISTINCT mercado
        FROM CATALOGO_MEDIFARMA
    ) mf ON vt.mercado = mf.mercado;
    """
    
    cursor.execute(q)
    rows = fetch_all_dict(cursor)
    conn.close()
    
    brands = []
    tot_mdo_row = None
    tot_terr_row = None
    
    for r in rows:
        tf = r['tipo_fila']
        if tf == 'DISTINCT_MERCADO':
            tot_mdo_row = r
            continue
        elif tf == 'TOTAL_TERRITORIO':
            tot_terr_row = r
            continue
            
        ms_act = float(r.get('ms_act') or 0)
        ms_ant = float(r.get('ms_ant') or 0)
        ms_ter = float(r.get('ms_territorio') or 0)
        vta_act = float(r.get('vta_act') or 0)
        vta_mdo = float(r.get('vta_mdo') or 0)
        vta_ant = float(r.get('vta_ant') or 0)
        vta_mdo_ant = float(r.get('vta_mdo_ant') or 0)
        
        ms_ideal = max(ms_act, ms_ant, ms_ter)
        construccion = 0.0 if ms_act >= ms_ideal else (ms_ideal - ms_act)
        valorizacion = (vta_mdo * 5.0) * construccion
        estimacion = (valorizacion + (vta_act * 5.0)) / 5.0
        
        if tf == 'BRAND':
            brands.append({
                'marca': r['marca_mkt'],
                'vta_act': vta_act,
                'vta_mdo': vta_mdo,
                'vta_ant': vta_ant,
                'vta_mdo_ant': vta_mdo_ant,
                'ms_act': ms_act,
                'ms_ant': ms_ant,
                'ms_territorio': ms_ter,
                'ms_ideal': ms_ideal,
                'estimacion': estimacion
            })
            
    # Totales
    tot_vta_act = sum(b['vta_act'] for b in brands)
    tot_vta_mdo = float(tot_mdo_row['vta_mdo']) if tot_mdo_row and float(tot_mdo_row.get('vta_mdo') or 0) > 0 else sum(b['vta_mdo'] for b in brands)
    tot_vta_ant = sum(b['vta_ant'] for b in brands)
    tot_vta_mdo_ant = float(tot_mdo_row['vta_mdo_ant']) if tot_mdo_row and float(tot_mdo_row.get('vta_mdo_ant') or 0) > 0 else 0.0
    
    tot_ms_act = (tot_vta_act / tot_vta_mdo) if tot_vta_mdo > 0 else 0.0
    tot_ms_ant = (tot_vta_ant / tot_vta_mdo_ant) if tot_vta_mdo_ant > 0 else 0.0
    
    if tot_terr_row and float(tot_terr_row.get('vta_mdo') or 0) > 0:
        tot_ms_territorio = float(tot_terr_row.get('vta_act') or 0) / float(tot_terr_row.get('vta_mdo') or 1)
    else:
        tot_ms_territorio = tot_ms_act
        
    tot_ms_ideal = max(tot_ms_act, tot_ms_ant, tot_ms_territorio)
    
    # 1. Sum of brand estimations (suma de estimaciones por marca/sku)
    tot_estimacion_sum = sum(b['estimacion'] for b in brands)
    
    # 2. Formula global (Vta Mdo x MS Ideal)
    tot_construccion = 0.0 if tot_ms_act >= tot_ms_ideal else (tot_ms_ideal - tot_ms_act)
    tot_estimacion_global = ((tot_vta_mdo * 5.0 * tot_construccion) + (tot_vta_act * 5.0)) / 5.0
    
    print(f"\n--- CLIENTE: {client_info['cp_cliente']} ---")
    print(f"VTA. ACT TOTAL       : S/ {tot_vta_act:,.2f}")
    print(f"VTA. MDO TOTAL       : S/ {tot_vta_mdo:,.2f}")
    print(f"VTA. ANT TOTAL       : S/ {tot_vta_ant:,.2f}")
    print(f"VTA. MDO ANT TOTAL   : S/ {tot_vta_mdo_ant:,.2f}")
    print(f"MS. ACT TOTAL        : {tot_ms_act:.1%}")
    print(f"MS. ANT TOTAL        : {tot_ms_ant:.1%}")
    print(f"MS. TERRITORIO TOTAL : {tot_ms_territorio:.1%}")
    print(f"MS. IDEAL TOTAL      : {tot_ms_ideal:.1%}")
    print(f"ESTIMACION (SUMA MARCAS): S/ {tot_estimacion_sum:,.2f}")
    print(f"ESTIMACION (GLOBAL)     : S/ {tot_estimacion_global:,.2f}")

if __name__ == '__main__':
    test_client_totals('20503382408') # CORPORACION QUIRUFARMA
    test_client_totals('20481921491') # DROGUERIA O BOTICAS LIVES
