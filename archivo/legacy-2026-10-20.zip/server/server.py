import os
import sys
import json
import io
import mimetypes
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from urllib.request import Request as UrlRequest, urlopen
from urllib.error import HTTPError, URLError
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from data_engine import get_filters_data, get_matrix_data, get_client_matrix_data, search_clients_db

PORT = 8080
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PUBLIC_DIR = os.path.join(BASE_DIR, "public")

class MedifarmaRequestHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=PUBLIC_DIR, **kwargs)

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_GET(self):
        parsed_url = urlparse(self.path)
        if parsed_url.path == '/api/filters':
            self.handle_get_filters()
        elif parsed_url.path == '/api/search-clients':
            self.handle_search_clients_get(parsed_url)
        elif parsed_url.path == '/api/health':
            self.send_json_response({'status': 'ok', 'app': 'Medifarma Share Matrix'})
        else:
            super().do_GET()

    def do_POST(self):
        parsed_url = urlparse(self.path)
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length) if content_length > 0 else b'{}'
        
        try:
            body = json.loads(post_data.decode('utf-8'))
        except Exception:
            body = {}

        if parsed_url.path == '/api/matrix':
            self.handle_get_matrix(body)
        elif parsed_url.path == '/api/activity/heartbeat':
            self.handle_activity_heartbeat(body)
        elif parsed_url.path == '/api/client-matrix':
            self.handle_get_client_matrix(body)
        elif parsed_url.path == '/api/search-clients':
            self.handle_search_clients_post(body)
        elif parsed_url.path == '/api/export-excel':
            self.handle_export_excel(body)
        else:
            self.send_error(404, "Endpoint not found")

    def send_json_response(self, data, status_code=200):
        res = json.dumps(data, ensure_ascii=False)
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Content-Length', str(len(res.encode('utf-8'))))
        self.end_headers()
        self.wfile.write(res.encode('utf-8'))

    def handle_activity_heartbeat(self, body):
        """Reporta la presencia de este proyecto al panel central sin exponer el secreto en el navegador."""
        user_id = body.get('userId')
        try:
            user_id = int(user_id)
        except (TypeError, ValueError):
            self.send_json_response({'accepted': False, 'error': 'userId requerido'}, 400)
            return

        portal_url = os.getenv('ACTIVITY_PORTAL_URL', '').rstrip('/')
        secret = os.getenv('ACTIVITY_INTEGRATION_SECRET', '').strip()
        if not portal_url or not secret:
            self.send_json_response({'accepted': False, 'error': 'Actividad no configurada'}, 503)
            return

        payload = json.dumps({
            'userId': user_id,
            'sessionId': body.get('sessionId'),
            'systemCode': os.getenv('ACTIVITY_SYSTEM_CODE', 'SUGERIDO').upper(),
        }).encode('utf-8')
        request = UrlRequest(
            f'{portal_url}/api/actividad/integracion/heartbeat',
            data=payload,
            headers={
                'Content-Type': 'application/json',
                'X-Activity-Secret': secret,
            },
            method='POST',
        )

        try:
            with urlopen(request, timeout=5) as response:
                response_body = response.read().decode('utf-8')
                data = json.loads(response_body) if response_body else {'accepted': True}
                self.send_json_response(data, response.status)
        except HTTPError as error:
            try:
                error_body = error.read().decode('utf-8')
                data = json.loads(error_body) if error_body else {'accepted': False}
            except Exception:
                data = {'accepted': False}
            self.send_json_response(data, error.code)
        except (URLError, TimeoutError, OSError) as error:
            print(f'[Actividad] No se pudo reportar presencia al portal: {error}')
            self.send_json_response({'accepted': False, 'error': 'Portal de actividad no disponible'}, 502)

    def handle_get_filters(self):
        try:
            filters = get_filters_data()
            self.send_json_response({'success': True, 'data': filters})
        except Exception as e:
            self.send_json_response({'success': False, 'error': str(e)}, 500)

    def handle_search_clients_get(self, parsed_url):
        try:
            params = parse_qs(parsed_url.query)
            query = params.get('q', [''])[0]
            category = params.get('category', [''])[0]
            zona_base = params.get('zonaBase', [''])[0]
            supervisor = params.get('supervisor', [''])[0]
            limit = int(params.get('limit', [50])[0])
            results = search_clients_db(query=query, category=category, zona_base=zona_base, supervisor=supervisor, limit=limit)
            self.send_json_response({'success': True, 'data': results})
        except Exception as e:
            self.send_json_response({'success': False, 'error': str(e)}, 500)

    def handle_search_clients_post(self, body):
        try:
            query = body.get('query') or body.get('q') or body.get('search') or ''
            category = body.get('category') or body.get('categorizacion') or body.get('quintil') or ''
            zona_base = body.get('zonaBase') or body.get('zona_base') or ''
            supervisor = body.get('supervisor') or ''
            limit = int(body.get('limit', 50))
            results = search_clients_db(query=query, category=category, zona_base=zona_base, supervisor=supervisor, limit=limit)
            self.send_json_response({'success': True, 'data': results})
        except Exception as e:
            self.send_json_response({'success': False, 'error': str(e)}, 500)

    def handle_get_matrix(self, body):
        try:
            unidad_medida = body.get('unidadMedida', 'UNIDAD')
            unidad_negocio = body.get('unidadNegocio', [])
            franquicia = body.get('franquicia', [])
            marca = body.get('marca', [])
            categorizacion = body.get('categorizacion', [])
            zona_base = body.get('zonaBase') or body.get('zona_base') or []
            supervisor = body.get('supervisor') or []
            selected_clients = body.get('selectedClients', [])
            search = body.get('search', '')

            data = get_matrix_data(
                unidad_medida=unidad_medida,
                unidad_negocio=unidad_negocio,
                franquicia=franquicia,
                marca=marca,
                categorizacion=categorizacion,
                zona_base=zona_base,
                supervisor=supervisor,
                selected_clients=selected_clients,
                search=search
            )
            self.send_json_response({'success': True, 'data': data})
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.send_json_response({'success': False, 'error': str(e)}, 500)

    def handle_get_client_matrix(self, body):
        try:
            client = body.get('client') or body.get('client_id') or body.get('clientId') or body.get('ruc') or body.get('cp_cliente')
            if not client:
                self.send_json_response({'success': False, 'error': 'Parámetro client requerido'}, 400)
                return

            unidad_medida = body.get('unidadMedida', 'UNIDAD')
            unidad_negocio = body.get('unidadNegocio', [])
            franquicia = body.get('franquicia', [])
            marca = body.get('marca', [])
            search = body.get('search', '')

            data = get_client_matrix_data(
                client_identifier=client,
                unidad_medida=unidad_medida,
                unidad_negocio=unidad_negocio,
                franquicia=franquicia,
                marca=marca,
                search=search
            )
            if not data:
                self.send_json_response({'success': False, 'error': 'Cliente no encontrado'}, 404)
                return

            self.send_json_response({'success': True, 'data': data})
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.send_json_response({'success': False, 'error': str(e)}, 500)

    def handle_export_excel(self, body):
        try:
            unidad_medida = body.get('unidadMedida', 'UNIDAD')
            unidad_negocio = body.get('unidadNegocio', [])
            franquicia = body.get('franquicia', [])
            marca = body.get('marca', [])
            categorizacion = body.get('categorizacion', [])
            zona_base = body.get('zonaBase') or body.get('zona_base') or []
            supervisor = body.get('supervisor') or []
            selected_clients = body.get('selectedClients', [])
            search = body.get('search', '')

            matrix_data = get_matrix_data(
                unidad_medida=unidad_medida,
                unidad_negocio=unidad_negocio,
                franquicia=franquicia,
                marca=marca,
                categorizacion=categorizacion,
                zona_base=zona_base,
                supervisor=supervisor,
                selected_clients=selected_clients,
                search=search
            )

            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Pedidos Sugeridos"

            # Color Palette
            c_purple = "6A5CBC"
            c_light_blue = "B4CEE4"
            c_dark_navy = "1D252D"
            c_white = "FFFFFF"
            c_sku_bg = "F8FAFC"

            fill_purple = PatternFill(start_color=c_purple, end_color=c_purple, fill_type="solid")
            fill_light_blue = PatternFill(start_color=c_light_blue, end_color=c_light_blue, fill_type="solid")
            fill_dark_navy = PatternFill(start_color=c_dark_navy, end_color=c_dark_navy, fill_type="solid")
            fill_sku = PatternFill(start_color=c_sku_bg, end_color=c_sku_bg, fill_type="solid")

            font_title = Font(name="Calibri", size=14, bold=True, color=c_purple)
            font_header_white = Font(name="Calibri", size=10, bold=True, color=c_white)
            font_header_dark = Font(name="Calibri", size=10, bold=True, color=c_dark_navy)
            font_brand = Font(name="Calibri", size=10, bold=True, color=c_dark_navy)
            font_sku = Font(name="Calibri", size=9, bold=False, color="475569")
            font_total = Font(name="Calibri", size=10, bold=True, color=c_white)

            border_thin = Side(border_style="thin", color="D1D5DB")
            border_all = Border(left=border_thin, right=border_thin, top=border_thin, bottom=border_thin)

            # Title block
            ws.cell(row=1, column=1, value="MEDIFARMA HUMANOVA - Pedidos Sugeridos").font = font_title
            ws.cell(row=2, column=1, value=f"Unidad de Medida: {unidad_medida}").font = Font(name="Calibri", size=10, italic=True)

            # Header Row 4 & Row 5
            ws.merge_cells(start_row=4, start_column=1, end_row=5, end_column=1)
            cell_row_label = ws.cell(row=4, column=1, value="Etiquetas de fila")
            cell_row_label.fill = fill_purple
            cell_row_label.font = font_header_white
            cell_row_label.alignment = Alignment(horizontal="center", vertical="center")

            # Share Summary Columns
            summary_cols = [
                ("VTA. ACT.", "#,##0"),
                ("VTA. MDO.", "#,##0"),
                ("MS. ACT.", "0.0%"),
                ("MS. ANT.", "0.0%"),
                ("MS. TERRITORIO", "0.0%"),
                ("MS. IDEAL", "0.0%"),
                ("ESTIMACION", "#,##0")
            ]

            ws.merge_cells(start_row=4, start_column=2, end_row=4, end_column=8)
            cell_share_header = ws.cell(row=4, column=2, value="ANÁLISIS DE Pedidos Sugeridos")
            cell_share_header.fill = fill_purple
            cell_share_header.font = font_header_white
            cell_share_header.alignment = Alignment(horizontal="center", vertical="center")

            for i, (col_name, _) in enumerate(summary_cols, start=2):
                c = ws.cell(row=5, column=i, value=col_name)
                c.fill = fill_purple
                c.font = font_header_white
                c.alignment = Alignment(horizontal="center", vertical="center")
                c.border = border_all

            # Client Columns
            col_idx = 9
            client_cols = matrix_data.get('client_columns', [])
            for cli in client_cols:
                ws.merge_cells(start_row=4, start_column=col_idx, end_row=4, end_column=col_idx + 1)
                c_cli_head = ws.cell(row=4, column=col_idx, value=cli['cp_cliente'])
                c_cli_head.fill = fill_light_blue
                c_cli_head.font = font_header_dark
                c_cli_head.alignment = Alignment(horizontal="center", vertical="center")

                c_sub1 = ws.cell(row=5, column=col_idx, value="¿COMPRA?")
                c_sub1.fill = fill_light_blue
                c_sub1.font = font_header_dark
                c_sub1.alignment = Alignment(horizontal="center", vertical="center")
                c_sub1.border = border_all

                c_sub2 = ws.cell(row=5, column=col_idx + 1, value="QUINTIL")
                c_sub2.fill = fill_light_blue
                c_sub2.font = font_header_dark
                c_sub2.alignment = Alignment(horizontal="center", vertical="center")
                c_sub2.border = border_all

                col_idx += 2

            # Data Rows
            current_row = 6
            for b in matrix_data.get('brands', []):
                # Brand Row
                c_b = ws.cell(row=current_row, column=1, value=b['marca'])
                c_b.font = font_brand
                c_b.border = border_all

                # Brand Metrics
                brand_metric_vals = [
                    (b['vta_act'], "#,##0"),
                    (b['vta_mdo'], "#,##0"),
                    (b['ms_act'], "0.0%"),
                    (b['ms_ant'], "0.0%"),
                    (b['ms_territorio'], "0.0%"),
                    (b['ms_ideal'], "0.0%"),
                    (b['estimacion'], "#,##0")
                ]
                for ci, (val, fmt) in enumerate(brand_metric_vals, start=2):
                    c = ws.cell(row=current_row, column=ci, value=val)
                    c.number_format = fmt
                    c.font = font_brand
                    c.border = border_all

                # Brand Client columns
                c_ci = 9
                for cli in client_cols:
                    cp = cli['cp_cliente']
                    c_info = b['clients'].get(cp, {'compra': 'NO', 'quintil': cli['quintil']})
                    c1 = ws.cell(row=current_row, column=c_ci, value=c_info['compra'])
                    c1.font = font_brand
                    c1.alignment = Alignment(horizontal="center")
                    c1.border = border_all

                    c2 = ws.cell(row=current_row, column=c_ci + 1, value=c_info['quintil'])
                    c2.font = font_brand
                    c2.alignment = Alignment(horizontal="center")
                    c2.border = border_all
                    c_ci += 2

                current_row += 1

                # SKU Rows
                for s in b.get('skus', []):
                    c_s = ws.cell(row=current_row, column=1, value=f"    {s['sku']}")
                    c_s.font = font_sku
                    c_s.fill = fill_sku
                    c_s.border = border_all

                    sku_metric_vals = [
                        (s['vta_act'], "#,##0"),
                        (s['vta_mdo'], "#,##0"),
                        (s['ms_act'], "0.0%"),
                        (s['ms_ant'], "0.0%"),
                        (s['ms_territorio'], "0.0%"),
                        (s['ms_ideal'], "0.0%"),
                        (s['estimacion'], "#,##0")
                    ]
                    for ci, (val, fmt) in enumerate(sku_metric_vals, start=2):
                        c = ws.cell(row=current_row, column=ci, value=val)
                        c.number_format = fmt
                        c.font = font_sku
                        c.fill = fill_sku
                        c.border = border_all

                    s_ci = 9
                    for cli in client_cols:
                        cp = cli['cp_cliente']
                        s_info = s['clients'].get(cp, {'compra': 'NO', 'quintil': cli['quintil']})
                        c1 = ws.cell(row=current_row, column=s_ci, value=s_info['compra'])
                        c1.font = font_sku
                        c1.fill = fill_sku
                        c1.alignment = Alignment(horizontal="center")
                        c1.border = border_all

                        c2 = ws.cell(row=current_row, column=s_ci + 1, value=s_info['quintil'])
                        c2.font = font_sku
                        c2.fill = fill_sku
                        c2.alignment = Alignment(horizontal="center")
                        c2.border = border_all
                        s_ci += 2

                    current_row += 1

            # Total Row
            totals = matrix_data.get('totals', {})
            c_tot_lbl = ws.cell(row=current_row, column=1, value="Total General")
            c_tot_lbl.fill = fill_dark_navy
            c_tot_lbl.font = font_total
            c_tot_lbl.border = border_all

            total_metric_vals = [
                (totals.get('vta_act', 0), "#,##0"),
                (totals.get('vta_mdo', 0), "#,##0"),
                (totals.get('ms_act', 0), "0.0%"),
                (totals.get('ms_ant', 0), "0.0%"),
                (totals.get('ms_territorio', 0), "0.0%"),
                (totals.get('ms_ideal', 0), "0.0%"),
                (totals.get('estimacion', 0), "#,##0")
            ]
            for ci, (val, fmt) in enumerate(total_metric_vals, start=2):
                c = ws.cell(row=current_row, column=ci, value=val)
                c.number_format = fmt
                c.fill = fill_dark_navy
                c.font = font_total
                c.border = border_all

            # Fill rest of total row
            for ci in range(9, col_idx):
                c = ws.cell(row=current_row, column=ci, value="")
                c.fill = fill_dark_navy
                c.border = border_all

            # Set column widths
            ws.column_dimensions['A'].width = 45
            for col_letter in ['B', 'C', 'D', 'E', 'F', 'G', 'H']:
                ws.column_dimensions[col_letter].width = 16
            for ci in range(9, col_idx):
                ws.column_dimensions[get_column_letter(ci)].width = 14

            output = io.BytesIO()
            wb.save(output)
            output.seek(0)
            excel_bytes = output.getvalue()

            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            self.send_header('Content-Disposition', 'attachment; filename="Construccion_de_Share_Medifarma.xlsx"')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Content-Length', str(len(excel_bytes)))
            self.end_headers()
            self.wfile.write(excel_bytes)
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.send_json_response({'success': False, 'error': str(e)}, 500)

def run_server(port=PORT):
    ThreadingHTTPServer.allow_reuse_address = True
    server_address = ('0.0.0.0', port)
    try:
        httpd = ThreadingHTTPServer(server_address, MedifarmaRequestHandler)
    except OSError as e:
        if "10048" in str(e) or "Address already in use" in str(e):
            print(f"\n[ALERTA] El puerto {port} está ocupado por otra ventana o proceso.")
            print(f"Intentando en el puerto alternativo {port + 1}...")
            port = port + 1
            server_address = ('0.0.0.0', port)
            try:
                httpd = ThreadingHTTPServer(server_address, MedifarmaRequestHandler)
            except Exception as e2:
                print(f"[ERROR] No se pudo iniciar el servidor: {e2}")
                return
        else:
            print(f"[ERROR] Error al iniciar el servidor: {e}")
            return

    print(f"============================================================")
    print(f" Medifarma Humanova - Web App: Pedidos Sugeridos")
    print(f" Servidor iniciado en http://localhost:{port}")
    print(f"============================================================")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor detenido.")
        httpd.server_close()

if __name__ == '__main__':
    run_server()
