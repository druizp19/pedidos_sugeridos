import sys
import json
import urllib.request
import time
import subprocess

# Iniciar server.py en segundo plano
print("Iniciando server.py para prueba de endpoints...")
p = subprocess.Popen([sys.executable, "server/server.py"])
time.sleep(2)

try:
    # 1. Health check
    req = urllib.request.urlopen("http://localhost:8080/api/health", timeout=5)
    print("Health check response:", req.read().decode('utf-8'))

    # 2. Filters endpoint
    req = urllib.request.urlopen("http://localhost:8080/api/filters", timeout=10)
    filters_data = json.loads(req.read().decode('utf-8'))
    print("Success filters:", filters_data.get('success'))
    data = filters_data.get('data', {})
    print(f"Total clientes en API: {len(data.get('clients', []))}")
    print(f"Total marcas en API: {len(data.get('marcas', []))}")

    # 3. Matrix endpoint (POST)
    payload = json.dumps({
        "unidadMedida": "UNIDAD",
        "unidadNegocio": ["FARMA"],
        "categorizacion": ["DIAMANTE"],
        "selectedClients": []
    }).encode('utf-8')

    req = urllib.request.Request(
        "http://localhost:8080/api/matrix",
        data=payload,
        headers={"Content-Type": "application/json"}
    )
    resp = urllib.request.urlopen(req, timeout=15)
    matrix_data = json.loads(resp.read().decode('utf-8'))
    print("Success matrix:", matrix_data.get('success'))
    m_data = matrix_data.get('data', {})
    print(f"Marcas devueltas en matriz: {len(m_data.get('brands', []))}")
    print("Totales matriz:", m_data.get('totals'))
finally:
    p.terminate()
    print("Servidor de prueba detenido.")
