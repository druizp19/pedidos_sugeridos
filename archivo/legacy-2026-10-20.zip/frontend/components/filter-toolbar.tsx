"use client";

import React from "react";
import {
  Building2,
  Network,
  Tag,
  Gem,
  MapPin,
  UserCheck,
  Users,
  Search,
  RotateCcw,
  X,
  SlidersHorizontal,
  PlusSquare,
  MinusSquare,
  ArrowUpDown,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { FilterData, FilterState } from "@/types";

interface FilterToolbarProps {
  filterOptions: FilterData | null;
  filters: FilterState;
  onChange: (key: keyof FilterState, value: any) => void;
  onReset: () => void;
  onOpenClientModal: () => void;
  onExpandAll?: (expand: boolean) => void;
  sortField?: string;
  sortDir?: "asc" | "desc";
}

export function FilterToolbar({
  filterOptions,
  filters,
  onChange,
  onReset,
  onOpenClientModal,
  onExpandAll,
  sortField = "vta_act",
  sortDir = "desc",
}: FilterToolbarProps) {
  const selectedClientsCount = filters.selectedClients.length;

  const sortLabelMap: Record<string, string> = {
    vta_act: "Venta Actual",
    vta_mdo: "Venta Mercado",
    ms_act: "Market Share Actual",
    ms_ant: "Market Share Anterior",
    ms_territorio: "MS Territorio",
    ms_ideal: "MS Ideal (Recupero)",
    estimacion: "Estimación Mensual",
    marca: "Marca",
  };

  const getSortDescription = () => {
    const fieldName = sortLabelMap[sortField] || sortField;
    if (sortField === "marca") {
      return sortDir === "asc" ? "Marca (A a Z)" : "Marca (Z a A)";
    }
    return sortDir === "desc"
      ? `${fieldName} (Mayor a Menor)`
      : `${fieldName} (Menor a Mayor)`;
  };

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-3 sm:p-4 shadow-xs space-y-3">
      {/* 8 Filter Selectors Grid: 2x4 on laptops, 1x8 on wide screens */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 xl:grid-cols-4 2xl:grid-cols-8 gap-2.5 sm:gap-3 items-end">
        {/* Unidad de Negocio */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-[#1d252d] flex items-center gap-1.5">
            <Building2 className="h-3.5 w-3.5 text-[#6a5cbc]" />
            <span>Unidad Negocio</span>
          </label>
          <Select
            value={filters.unidadNegocio || "ALL"}
            onValueChange={(val) => onChange("unidadNegocio", val === "ALL" ? "" : val)}
          >
            <SelectTrigger className="h-8 text-xs bg-white border-slate-200 hover:border-slate-300">
              <SelectValue placeholder="(Todas)" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL" className="text-xs">(Todas)</SelectItem>
              {(filterOptions?.unidades_negocio || []).map((un) => (
                <SelectItem key={un} value={un} className="text-xs">
                  {un}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Franquicia */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-[#1d252d] flex items-center gap-1.5">
            <Network className="h-3.5 w-3.5 text-[#6a5cbc]" />
            <span>Franquicia</span>
          </label>
          <Select
            value={filters.franquicia || "ALL"}
            onValueChange={(val) => onChange("franquicia", val === "ALL" ? "" : val)}
          >
            <SelectTrigger className="h-8 text-xs bg-white border-slate-200 hover:border-slate-300">
              <SelectValue placeholder="(Todas)" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL" className="text-xs">(Todas)</SelectItem>
              {(filterOptions?.franquicias || []).map((fr) => (
                <SelectItem key={fr} value={fr} className="text-xs">
                  {fr}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Marca MKT */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-[#1d252d] flex items-center gap-1.5">
            <Tag className="h-3.5 w-3.5 text-[#6a5cbc]" />
            <span>Marca MKT</span>
          </label>
          <Select
            value={filters.marca || "ALL"}
            onValueChange={(val) => onChange("marca", val === "ALL" ? "" : val)}
          >
            <SelectTrigger className="h-8 text-xs bg-white border-slate-200 hover:border-slate-300">
              <SelectValue placeholder="(Todas)" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL" className="text-xs">(Todas)</SelectItem>
              {(filterOptions?.marcas || []).map((m) => (
                <SelectItem key={m} value={m} className="text-xs">
                  {m}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Categorización / Quintil */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-[#1d252d] flex items-center gap-1.5">
            <Gem className="h-3.5 w-3.5 text-[#6a5cbc]" />
            <span>Categorización</span>
          </label>
          <Select
            value={filters.quintil || "ALL"}
            onValueChange={(val) => onChange("quintil", val === "ALL" ? "" : val)}
          >
            <SelectTrigger className="h-8 text-xs bg-white border-slate-200 hover:border-slate-300">
              <SelectValue placeholder="(Todas)" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL" className="text-xs">(Todas)</SelectItem>
              <SelectItem value="DIAMANTE" className="text-xs">DIAMANTE (Q1)</SelectItem>
              <SelectItem value="ORO" className="text-xs">ORO (Q2)</SelectItem>
              <SelectItem value="PLATA" className="text-xs">PLATA (Q3)</SelectItem>
              <SelectItem value="BRONCE" className="text-xs">BRONCE (Q4)</SelectItem>
              <SelectItem value="PLOMO" className="text-xs">PLOMO (Q5)</SelectItem>
              <SelectItem value="SIN CATEGORIZACION" className="text-xs">SIN CATEGORIZACION</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Zona Base */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-[#1d252d] flex items-center gap-1.5">
            <MapPin className="h-3.5 w-3.5 text-[#6a5cbc]" />
            <span>Zona Base</span>
          </label>
          <Select
            value={filters.zonaBase || "ALL"}
            onValueChange={(val) => onChange("zonaBase", val === "ALL" ? "" : val)}
          >
            <SelectTrigger className="h-8 text-xs bg-white border-slate-200 hover:border-slate-300">
              <SelectValue placeholder="(Todas)" />
            </SelectTrigger>
            <SelectContent className="max-h-60">
              <SelectItem value="ALL" className="text-xs">(Todas)</SelectItem>
              {(filterOptions?.zonas_base || []).map((zb) => (
                <SelectItem key={zb} value={zb} className="text-xs">
                  {zb}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Supervisor */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-[#1d252d] flex items-center gap-1.5">
            <UserCheck className="h-3.5 w-3.5 text-[#6a5cbc]" />
            <span>Supervisor</span>
          </label>
          <Select
            value={filters.supervisor || "ALL"}
            onValueChange={(val) => onChange("supervisor", val === "ALL" ? "" : val)}
          >
            <SelectTrigger className="h-8 text-xs bg-white border-slate-200 hover:border-slate-300">
              <SelectValue placeholder="(Todos)" />
            </SelectTrigger>
            <SelectContent className="max-h-60">
              <SelectItem value="ALL" className="text-xs">(Todos)</SelectItem>
              {(filterOptions?.supervisores || []).map((sup) => (
                <SelectItem key={sup} value={sup} className="text-xs">
                  {sup}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Columnas de Clientes */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-[#1d252d] flex items-center gap-1.5">
            <Users className="h-3.5 w-3.5 text-[#6a5cbc]" />
            <span>Clientes</span>
          </label>
          <button
            type="button"
            onClick={onOpenClientModal}
            className="w-full h-8 px-2 flex items-center justify-center gap-1 text-xs font-bold text-[#6a5cbc] bg-white hover:bg-[#ede9fe]/40 border border-[#6a5cbc] rounded-md transition-colors"
          >
            <SlidersHorizontal className="h-3.5 w-3.5 shrink-0" />
            <span className="truncate">
              Clientes ({selectedClientsCount === 0 ? "Todos" : selectedClientsCount})
            </span>
          </button>
        </div>

        {/* Search */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-[#1d252d] flex items-center gap-1.5">
            <Search className="h-3.5 w-3.5 text-[#6a5cbc]" />
            <span>Buscar SKU</span>
          </label>
          <div className="relative">
            <Input
              type="text"
              placeholder="Buscar..."
              value={filters.search}
              onChange={(e) => onChange("search", e.target.value)}
              className="h-8 pl-2.5 pr-6 text-xs bg-white border-slate-200"
            />
            {filters.search ? (
              <button
                onClick={() => onChange("search", "")}
                className="absolute right-2 top-2 text-slate-400 hover:text-slate-600"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            ) : (
              <Search className="absolute right-2 top-2.5 h-3 w-3 text-slate-400 pointer-events-none" />
            )}
          </div>
        </div>
      </div>

      {/* Action Row: Expand/Collapse, Active Sort, Reset Filters */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-slate-100">
        {/* Left: Expand / Collapse */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onExpandAll?.(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#1d252d] bg-white hover:bg-slate-100 border border-slate-200 rounded-md shadow-2xs transition-colors"
          >
            <PlusSquare className="h-3.5 w-3.5 text-slate-700" />
            <span>Expandir Todo</span>
          </button>
          <button
            type="button"
            onClick={() => onExpandAll?.(false)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#1d252d] bg-white hover:bg-slate-100 border border-slate-200 rounded-md shadow-2xs transition-colors"
          >
            <MinusSquare className="h-3.5 w-3.5 text-slate-700" />
            <span>Colapsar Todo</span>
          </button>
        </div>

        {/* Center: Active Sort Indicator */}
        <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#6a5cbc]">
          <ArrowUpDown className="h-3.5 w-3.5" />
          <span>Orden activo:</span>
          <span className="font-bold text-[#1d252d]">{getSortDescription()}</span>
        </div>

        {/* Right: Reset Filters */}
        <div>
          <button
            type="button"
            onClick={onReset}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-[#b91c1c] bg-[#fee2e2] hover:bg-[#fecaca] border border-[#fca5a5] rounded-md transition-colors shadow-2xs"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Limpiar Filtros</span>
          </button>
        </div>
      </div>
    </div>
  );
}
