"use client";

import React from "react";
import { TrendingUp, Globe, PieChart, Target } from "lucide-react";
import { MatrixTotals } from "@/types";
import { formatNumber, formatPercent } from "@/lib/utils";

interface KPISummaryProps {
  totals: MatrixTotals | null;
  unidadMedida: "UNIDAD" | "S/ SOLES";
}

export function KPISummary({ totals, unidadMedida }: KPISummaryProps) {
  const isSoles = unidadMedida === "S/ SOLES";

  const cards = [
    {
      title: "VTA. ACT. MENSUAL",
      value: totals ? formatNumber(totals.vta_act, isSoles) : "0",
      subtext: isSoles ? "Soles (S/) / mes" : "Unidades / mes",
      icon: TrendingUp,
      iconColor: "text-[#6a5cbc]",
      iconBg: "bg-[#ede9fe]",
      highlight: false,
    },
    {
      title: "VTA. MDO. MENSUAL",
      value: totals ? formatNumber(totals.vta_mdo, isSoles) : "0",
      subtext: "Total Mercado auditado",
      icon: Globe,
      iconColor: "text-[#0284c7]",
      iconBg: "bg-[#e0f2fe]",
      highlight: false,
    },
    {
      title: "MARKET SHARE ACTUAL",
      value: totals ? formatPercent(totals.ms_act) : "0.0%",
      subtext: "Participación Global",
      icon: PieChart,
      iconColor: "text-[#d97706]",
      iconBg: "bg-[#fef3c7]",
      highlight: false,
    },
    {
      title: "MS. IDEAL (RECUPERO)",
      value: totals ? formatPercent(totals.ms_ideal) : "0.0%",
      subtext: "Objetivo sugerido",
      icon: Target,
      iconColor: "text-[#16a34a]",
      iconBg: "bg-[#dcfce7]",
      highlight: false,
    },
    {
      title: "ESTIMACIÓN MENSUAL",
      value: totals ? formatNumber(totals.estimacion, isSoles) : "0",
      subtext: "Potencial mensual proyectado",
      icon: TrendingUp,
      iconColor: "text-white",
      iconBg: "bg-white/20",
      highlight: true,
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-2.5 sm:gap-3.5">
      {cards.map((c, i) => {
        const Icon = c.icon;
        if (c.highlight) {
          return (
            <div
              key={i}
              className="bg-gradient-to-br from-[#6a5cbc] to-[#53459e] text-white rounded-xl p-3 sm:p-3.5 xl:p-4 shadow-sm flex items-center gap-3 transition-all hover:-translate-y-0.5 hover:shadow-md col-span-1 sm:col-span-2 md:col-span-1 xl:col-span-1"
            >
              <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
                <Icon className="h-5 w-5 text-white" />
              </div>
              <div className="flex flex-col min-w-0">
                <span className="text-[10px] sm:text-[11px] font-bold tracking-wider text-white/85 uppercase truncate">
                  {c.title}
                </span>
                <span className="text-xl sm:text-2xl font-black text-white tracking-tight leading-tight my-0.5 tabular-nums truncate">
                  {c.value}
                </span>
                <span className="text-[10px] sm:text-[11px] text-white/80 font-medium truncate">
                  {c.subtext}
                </span>
              </div>
            </div>
          );
        }

        return (
          <div
            key={i}
            className="bg-white border border-slate-200 rounded-xl p-3 sm:p-3.5 xl:p-4 shadow-xs flex items-center gap-3 transition-all hover:-translate-y-0.5 hover:shadow-md"
          >
            <div className={`w-10 h-10 sm:w-11 sm:h-11 rounded-xl ${c.iconBg} flex items-center justify-center shrink-0`}>
              <Icon className={`h-5 w-5 ${c.iconColor}`} />
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-[10px] sm:text-[11px] font-bold tracking-wider text-slate-500 uppercase truncate">
                {c.title}
              </span>
              <span className="text-xl sm:text-2xl font-black text-[#1d252d] tracking-tight leading-tight my-0.5 tabular-nums truncate">
                {c.value}
              </span>
              <span className="text-[10px] sm:text-[11px] text-slate-500 font-medium truncate">
                {c.subtext}
              </span>
            </div>
          </div>
        );
      })}
    </div>
  );
}
