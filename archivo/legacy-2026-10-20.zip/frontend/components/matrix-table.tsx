"use client";

import React, { useState, useMemo } from "react";
import {
  ChevronRight,
  ChevronDown,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  ChevronsUpDown,
  PlusSquare,
  MinusSquare,
  CornerDownRight,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { MatrixBrand, MatrixTotals, ClientColumn } from "@/types";
import { formatNumber, formatPercent } from "@/lib/utils";

interface MatrixTableProps {
  brands: MatrixBrand[];
  totals: MatrixTotals | null;
  clientColumns: ClientColumn[];
  unidadMedida: "UNIDAD" | "S/ SOLES";
  searchTerm: string;
  sortField?: SortField;
  sortDir?: "asc" | "desc";
  onSort?: (field: SortField) => void;
  collapsedBrands?: Set<string>;
  onToggleBrand?: (brandId: string) => void;
  onExpandAll?: (expand: boolean) => void;
  onClientClick?: (client: ClientColumn) => void;
}

export type SortField =
  | "marca"
  | "vta_act"
  | "vta_mdo"
  | "ms_act"
  | "ms_ant"
  | "ms_territorio"
  | "ms_ideal"
  | "estimacion";

export function MatrixTable({
  brands,
  totals,
  clientColumns,
  unidadMedida,
  searchTerm,
  sortField: externalSortField,
  sortDir: externalSortDir,
  onSort: externalOnSort,
  collapsedBrands: externalCollapsedBrands,
  onToggleBrand: externalOnToggleBrand,
  onExpandAll: externalOnExpandAll,
  onClientClick,
}: MatrixTableProps) {
  const isSoles = unidadMedida === "S/ SOLES";
  const getBrandId = (b: MatrixBrand) =>
    `${b.marca}__${b.unidad_negocio || ""}__${b.franquicia || ""}`;

  const [internalCollapsedBrands, setInternalCollapsedBrands] = useState<Set<string>>(new Set());
  const [internalSortField, setInternalSortField] = useState<SortField>("estimacion");
  const [internalSortDir, setInternalSortDir] = useState<"asc" | "desc">("desc");

  const sortField = externalSortField ?? internalSortField;
  const sortDir = externalSortDir ?? internalSortDir;
  const collapsedBrands = externalCollapsedBrands ?? internalCollapsedBrands;

  const toggleBrand = (brandId: string) => {
    if (externalOnToggleBrand) {
      externalOnToggleBrand(brandId);
    } else {
      setInternalCollapsedBrands((prev) => {
        const next = new Set(prev);
        if (next.has(brandId)) next.delete(brandId);
        else next.add(brandId);
        return next;
      });
    }
  };

  const handleSort = (field: SortField) => {
    if (externalOnSort) {
      externalOnSort(field);
    } else {
      if (internalSortField === field) {
        setInternalSortDir((prev) => (prev === "asc" ? "desc" : "asc"));
      } else {
        setInternalSortField(field);
        setInternalSortDir(field === "marca" ? "asc" : "desc");
      }
    }
  };

  // Filter & Sort brands and SKUs
  const processedBrands = useMemo(() => {
    const term = searchTerm.toLowerCase().trim();

    // 1. Filter
    let list = brands;
    if (term) {
      list = list.filter((b) => {
        const brandMatch = b.marca.toLowerCase().includes(term);
        const skuMatch = b.skus?.some((s) => s.sku.toLowerCase().includes(term));
        return brandMatch || skuMatch;
      });
    }

    // 2. Sort Brands
    const sorted = [...list].sort((a, b) => {
      if (sortField === "marca") {
        return sortDir === "asc"
          ? a.marca.localeCompare(b.marca)
          : b.marca.localeCompare(a.marca);
      }
      const valA = Number(a[sortField]) || 0;
      const valB = Number(b[sortField]) || 0;
      return sortDir === "asc" ? valA - valB : valB - valA;
    });

    // 3. Sort SKUs inside each brand
    return sorted.map((b) => {
      if (!b.skus || b.skus.length === 0) return b;
      const sortedSkus = [...b.skus].sort((sa, sb) => {
        if (sortField === "marca") {
          return sortDir === "asc"
            ? sa.sku.localeCompare(sb.sku)
            : sb.sku.localeCompare(sa.sku);
        }
        const valA = Number(sa[sortField]) || 0;
        const valB = Number(sb[sortField]) || 0;
        return sortDir === "asc" ? valA - valB : valB - valA;
      });
      return { ...b, skus: sortedSkus };
    });
  }, [brands, searchTerm, sortField, sortDir]);

  const renderSortIcon = (field: SortField) => {
    if (sortField !== field) {
      return <ArrowUpDown className="h-3 w-3 opacity-40 group-hover:opacity-100 transition-opacity" />;
    }
    return sortDir === "asc" ? (
      <ArrowUp className="h-3.5 w-3.5 text-[#38bdf8] font-black" />
    ) : (
      <ArrowDown className="h-3.5 w-3.5 text-[#38bdf8] font-black" />
    );
  };

  const getQuintilBadgeClass = (q: string) => {
    switch (q?.toUpperCase()) {
      case "DIAMANTE":
      case "Q1":
        return "bg-[#ede9fe] text-[#6d28d9] border border-[#ddd6fe]";
      case "ORO":
      case "Q2":
        return "bg-[#fef3c7] text-[#b45309] border border-[#fde68a]";
      case "PLATA":
      case "Q3":
        return "bg-[#dbeafe] text-[#1d4ed8] border border-[#bfdbfe]";
      case "BRONCE":
      case "Q4":
        return "bg-[#d1fae5] text-[#047857] border border-[#a7f3d0]";
      case "PLOMO":
      case "Q5":
        return "bg-[#f1f5f9] text-[#475569] border border-[#e2e8f0]";
      default:
        return "bg-slate-100 text-slate-500";
    }
  };

  return (
    <div className="rounded-xl border border-slate-200 bg-white shadow-xs overflow-hidden">
      {/* Full-width Responsive Table Container with dynamic viewport height */}
      <div className="relative max-h-[calc(100vh-310px)] min-h-[420px] overflow-auto">
        <table
          key={`matrix-table-${unidadMedida}-${clientColumns.map((c) => c.cp_cliente).join("-")}`}
          className="w-full border-collapse text-left text-xs"
        >
          {/* LEVEL 1 HEADERS */}
          <thead className="sticky top-0 z-30">
            <tr className="header-level-1">
              {/* Sticky Leftmost Header */}
              <th
                rowSpan={2}
                onClick={() => handleSort("marca")}
                className="sticky left-0 top-0 z-40 min-w-[250px] sm:min-w-[280px] md:min-w-[320px] max-w-[380px] bg-[#6a5cbc] text-white p-2 sm:p-2.5 font-bold group cursor-pointer hover:bg-[#53459e] transition-colors border-r-2 border-[#53459e] select-none"
              >
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-xs">
                    Etiquetas de fila
                    {renderSortIcon("marca")}
                  </span>
                  <span className="bg-white/20 text-white text-[10px] sm:text-[11px] font-semibold px-2 py-0.5 rounded-full">
                    {processedBrands.length} marcas
                  </span>
                </div>
              </th>

              {/* Central Metrics Span Header */}
              <th
                colSpan={7}
                className="bg-[#6a5cbc] text-white p-2 text-center font-bold tracking-wider uppercase text-xs border-r border-white/20 select-none"
              >
                ANÁLISIS DE Pedidos Sugeridos
              </th>

              {/* Level 1 Client Headers */}
              {clientColumns.map((c) => (
                <th
                  key={`h1-${c.cp_cliente}`}
                  colSpan={2}
                  onClick={() => onClientClick?.(c)}
                  className="bg-[#b4cee4] hover:bg-[#9ec2df] text-[#1d252d] px-2 py-1.5 text-center font-bold border-r-2 border-white min-w-[135px] cursor-pointer transition-all duration-150 select-none group/cli relative hover:shadow-inner"
                  title={`Haga clic para ver el desglose recalculado de ${c.farmacia || c.cp_cliente}`}
                >
                  <div className="flex items-center justify-center gap-1">
                    <div className="truncate text-xs font-bold group-hover/cli:text-[#6a5cbc] transition-colors" title={c.farmacia || c.cp_cliente}>
                      {c.farmacia || c.cp_cliente}
                    </div>
                  </div>
                  <div className="text-[10px] text-slate-600 font-mono font-normal flex items-center justify-center gap-1.5 mt-0.5">
                    <span>RUC: {c.ruc}</span>
                    <span className="text-[9px] bg-white/70 text-[#53459e] font-bold px-1 rounded group-hover/cli:bg-[#6a5cbc] group-hover/cli:text-white transition-colors">
                      Ver Share
                    </span>
                  </div>
                </th>
              ))}
            </tr>

            {/* LEVEL 2 METRIC HEADERS */}
            <tr className="header-level-2 text-[11px] font-bold text-white uppercase tracking-wider">
              <th
                onClick={() => handleSort("vta_act")}
                className="group cursor-pointer p-2 bg-[#53459e] hover:bg-[#473a8b] text-right min-w-[95px] border-r border-white/20 select-none transition-colors"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>VTA. ACT.</span>
                  {renderSortIcon("vta_act")}
                </div>
              </th>

              <th
                onClick={() => handleSort("vta_mdo")}
                className="group cursor-pointer p-2 bg-[#53459e] hover:bg-[#473a8b] text-right min-w-[95px] border-r border-white/20 select-none transition-colors"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>VTA. MDO.</span>
                  {renderSortIcon("vta_mdo")}
                </div>
              </th>

              <th
                onClick={() => handleSort("ms_act")}
                className="group cursor-pointer p-2 bg-[#53459e] hover:bg-[#473a8b] text-right min-w-[80px] border-r border-white/20 select-none transition-colors"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>MS. ACT.</span>
                  {renderSortIcon("ms_act")}
                </div>
              </th>

              <th
                onClick={() => handleSort("ms_ant")}
                className="group cursor-pointer p-2 bg-[#53459e] hover:bg-[#473a8b] text-right min-w-[80px] border-r border-white/20 select-none transition-colors"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>MS. ANT.</span>
                  {renderSortIcon("ms_ant")}
                </div>
              </th>

              <th
                onClick={() => handleSort("ms_territorio")}
                className="group cursor-pointer p-2 bg-[#53459e] hover:bg-[#473a8b] text-right min-w-[95px] border-r border-white/20 select-none transition-colors"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>MS. TERRITORIO</span>
                  {renderSortIcon("ms_territorio")}
                </div>
              </th>

              <th
                onClick={() => handleSort("ms_ideal")}
                className="group cursor-pointer p-2 bg-[#1d252d] hover:bg-[#2b353f] text-right min-w-[90px] border-r border-white/20 select-none transition-colors"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>MS. IDEAL</span>
                  {renderSortIcon("ms_ideal")}
                </div>
              </th>

              <th
                onClick={() => handleSort("estimacion")}
                className="group cursor-pointer p-2 bg-[#1d252d] hover:bg-[#2b353f] text-right min-w-[110px] text-[#38bdf8] border-r-2 border-white select-none transition-colors font-extrabold"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>ESTIMACION</span>
                  {renderSortIcon("estimacion")}
                </div>
              </th>

              {/* Client Columns Subheaders */}
              {clientColumns.flatMap((c) => [
                <th
                  key={`h2-compra-${c.cp_cliente}`}
                  className="p-1.5 text-center bg-[#9abedc] text-[#1d252d] font-bold text-[10px] min-w-[60px] border-r border-white/40"
                >
                  Compra
                </th>,
                <th
                  key={`h2-quintil-${c.cp_cliente}`}
                  className="p-1.5 text-center bg-[#9abedc] text-[#1d252d] font-bold text-[10px] border-r border-slate-300 min-w-[60px]"
                >
                  Quintil
                </th>,
              ])}
            </tr>
          </thead>

          {/* TABLE BODY */}
          <tbody className="divide-y divide-slate-100">
            {processedBrands.length === 0 ? (
              <tr>
                <td
                  colSpan={8 + clientColumns.length * 2}
                  className="p-12 text-center text-slate-400 text-xs bg-white"
                >
                  No se encontraron marcas ni productos para los filtros seleccionados.
                </td>
              </tr>
            ) : (
              processedBrands.map((brand, brandIdx) => {
                const uniqueBrandKey = getBrandId(brand);
                const brandId = `${uniqueBrandKey}_${brandIdx}`;
                const isCollapsed = collapsedBrands.has(uniqueBrandKey);
                const hasSkus = brand.skus && brand.skus.length > 0;

                return (
                  <React.Fragment key={`brand-group-${brandId}`}>
                    {/* Brand Row (Summary Level) */}
                    <tr
                      key={`tr-brand-${brandId}`}
                      className="bg-[#f8fafc] hover:bg-slate-100 transition-colors font-bold text-[#1d252d] border-t border-b border-slate-300 group"
                    >
                      {/* Sticky Brand Name */}
                      <td className="sticky left-0 z-10 bg-[#f8fafc] group-hover:bg-slate-100 p-2.5 border-r-2 border-slate-300">
                        <div
                          onClick={() => hasSkus && toggleBrand(uniqueBrandKey)}
                          className={`flex items-center gap-2 select-none ${hasSkus ? "cursor-pointer" : ""}`}
                        >
                          {hasSkus ? (
                            <span className="w-4 h-4 rounded bg-[#6a5cbc] hover:bg-[#53459e] text-white flex items-center justify-center text-[10px] shrink-0 transition-colors">
                              {isCollapsed ? "+" : "-"}
                            </span>
                          ) : (
                            <span className="w-4 h-4 shrink-0" />
                          )}
                          <span className="font-bold text-[#1d252d] text-xs tracking-tight truncate">
                            {brand.marca}
                          </span>
                          {brand.franquicia && brand.franquicia !== "RESTO" && (
                            <span className="text-[10px] text-slate-500 font-normal truncate">
                              ({brand.franquicia})
                            </span>
                          )}
                          {hasSkus && (
                            <span className="rounded bg-slate-200 text-slate-600 px-1.5 py-0.2 text-[10px] font-semibold">
                              {brand.skus.length}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Brand Metrics */}
                      <td className="p-2 text-right font-bold tabular-nums text-[#1d252d] border-r border-slate-200">
                        {formatNumber(brand.vta_act, isSoles)}
                      </td>
                      <td className="p-2 text-right tabular-nums text-slate-600 border-r border-slate-200">
                        {formatNumber(brand.vta_mdo, isSoles)}
                      </td>
                      <td className="p-2 text-right tabular-nums font-bold text-[#1d252d] border-r border-slate-200">
                        {formatPercent(brand.ms_act)}
                      </td>
                      <td className="p-2 text-right tabular-nums text-slate-600 border-r border-slate-200">
                        {formatPercent(brand.ms_ant)}
                      </td>
                      <td className="p-2 text-right tabular-nums text-slate-600 border-r border-slate-200">
                        {formatPercent(brand.ms_territorio)}
                      </td>
                      <td className="p-2 text-right tabular-nums font-bold text-[#1d252d] border-r border-slate-200">
                        {formatPercent(brand.ms_ideal)}
                      </td>
                      <td className="p-2 text-right tabular-nums font-extrabold text-[#53459e] bg-[#6a5cbc]/5 border-r-2 border-slate-300">
                        {formatNumber(brand.estimacion, isSoles)}
                      </td>

                      {/* Client Values for Brand */}
                      {clientColumns.flatMap((c) => {
                        const clientVal = brand.clients?.[c.cp_cliente];
                        const compra = clientVal?.compra === "SI";
                        const quintil = clientVal?.quintil || c.quintil;

                        return [
                          <td
                            key={`td-b-${brandId}-${c.cp_cliente}-compra`}
                            className="p-1.5 text-center border-r border-slate-200"
                          >
                            <span
                              className={`inline-block rounded-full px-2 py-0.5 text-[10px] font-bold ${
                                compra
                                  ? "bg-[#d1fae5] text-[#065f46]"
                                  : "bg-slate-100 text-slate-400"
                              }`}
                            >
                              {compra ? "SÍ" : "NO"}
                            </span>
                          </td>,
                          <td
                            key={`td-b-${brandId}-${c.cp_cliente}-quintil`}
                            className="p-1.5 text-center border-r border-slate-300"
                          >
                            <span
                              className={`inline-block px-2 py-0.5 rounded-full text-[9px] font-bold ${getQuintilBadgeClass(
                                quintil
                              )}`}
                            >
                              {quintil || "-"}
                            </span>
                          </td>,
                        ];
                      })}
                    </tr>

                    {/* SKU Rows (Detail Level) */}
                    {!isCollapsed &&
                      hasSkus &&
                      brand.skus.map((sku, skuIdx) => {
                        const skuId = `${brandId}__${sku.sku}_${skuIdx}`;
                        return (
                          <tr
                            key={`tr-sku-${skuId}`}
                            className="hover:bg-slate-50 transition-colors text-slate-600 bg-white group border-b border-slate-100"
                          >
                            {/* Sticky SKU Name */}
                            <td className="sticky left-0 z-10 bg-white group-hover:bg-slate-50 p-2 pl-8 text-xs border-r-2 border-slate-200">
                              <div className="flex items-center gap-1.5 truncate max-w-[340px]">
                                <CornerDownRight className="h-3 w-3 text-slate-400 shrink-0" />
                                <span title={sku.sku} className="truncate font-normal text-slate-700 text-xs">
                                  {sku.sku}
                                </span>
                              </div>
                            </td>

                            {/* SKU Metrics */}
                            <td className="p-1.5 text-right tabular-nums text-slate-700 border-r border-slate-100">
                              {formatNumber(sku.vta_act, isSoles)}
                            </td>
                            <td className="p-1.5 text-right tabular-nums text-slate-400 border-r border-slate-100">
                              {formatNumber(sku.vta_mdo, isSoles)}
                            </td>
                            <td className="p-1.5 text-right tabular-nums text-slate-600 border-r border-slate-100">
                              {formatPercent(sku.ms_act)}
                            </td>
                            <td className="p-1.5 text-right tabular-nums text-slate-400 border-r border-slate-100">
                              {formatPercent(sku.ms_ant)}
                            </td>
                            <td className="p-1.5 text-right tabular-nums text-slate-400 border-r border-slate-100">
                              {formatPercent(sku.ms_territorio)}
                            </td>
                            <td className="p-1.5 text-right tabular-nums font-medium text-[#1d252d] border-r border-slate-100">
                              {formatPercent(sku.ms_ideal)}
                            </td>
                            <td className="p-1.5 text-right tabular-nums font-semibold text-[#6a5cbc] bg-[#6a5cbc]/5 border-r-2 border-slate-200">
                              {formatNumber(sku.estimacion, isSoles)}
                            </td>

                            {/* Client Values for SKU */}
                            {clientColumns.flatMap((c) => {
                              const clientVal = sku.clients?.[c.cp_cliente];
                              const compra = clientVal?.compra === "SI";
                              const quintil = clientVal?.quintil || c.quintil;

                              return [
                                <td
                                  key={`td-s-${skuId}-${c.cp_cliente}-compra`}
                                  className="p-1.5 text-center border-r border-slate-100"
                                >
                                  <span
                                    className={`inline-block rounded-full px-1.5 py-0.2 text-[9px] font-semibold ${
                                      compra
                                        ? "bg-[#d1fae5] text-[#065f46]"
                                        : "bg-slate-50 text-slate-400"
                                    }`}
                                  >
                                    {compra ? "SÍ" : "NO"}
                                  </span>
                                </td>,
                                <td
                                  key={`td-s-${skuId}-${c.cp_cliente}-quintil`}
                                  className="p-1.5 text-center border-r border-slate-200"
                                >
                                  <span className="text-[10px] text-slate-400 font-mono">
                                    {quintil || "-"}
                                  </span>
                                </td>,
                              ];
                            })}
                          </tr>
                        );
                      })}
                  </React.Fragment>
                );
              })
            )}
          </tbody>

          {/* TABLE FOOTER (TOTAL GENERAL) */}
          {totals && (
            <tfoot className="sticky bottom-0 z-30 font-bold text-xs shadow-md">
              <tr className="border-t-2 border-[#1d252d]">
                <td className="sticky left-0 z-40 bg-[#1d252d] text-white p-2.5 border-r-2 border-white/20 tracking-wider font-extrabold">
                  TOTAL GENERAL
                </td>
                <td className="p-2.5 text-right tabular-nums bg-[#2b353f] text-white border-r border-white/10">
                  {formatNumber(totals.vta_act, isSoles)}
                </td>
                <td className="p-2.5 text-right tabular-nums bg-[#2b353f] text-slate-300 font-normal border-r border-white/10">
                  {formatNumber(totals.vta_mdo, isSoles)}
                </td>
                <td className="p-2.5 text-right tabular-nums bg-[#2b353f] text-[#38bdf8] font-bold border-r border-white/10">
                  {formatPercent(totals.ms_act)}
                </td>
                <td className="p-2.5 text-right tabular-nums bg-[#2b353f] text-slate-300 font-normal border-r border-white/10">
                  {formatPercent(totals.ms_ant)}
                </td>
                <td className="p-2.5 text-right tabular-nums bg-[#2b353f] text-slate-300 font-normal border-r border-white/10">
                  {formatPercent(totals.ms_territorio)}
                </td>
                <td className="p-2.5 text-right tabular-nums bg-[#2b353f] text-white border-r border-white/10">
                  {formatPercent(totals.ms_ideal)}
                </td>
                <td className="p-2.5 text-right tabular-nums bg-[#2b353f] text-[#38bdf8] border-r-2 border-white font-black">
                  {formatNumber(totals.estimacion, isSoles)}
                </td>

                {/* Empty cells for client columns in totals */}
                {clientColumns.map((c) => (
                  <td
                    key={`td-tot-${c.cp_cliente}`}
                    colSpan={2}
                    className="bg-[#2b353f] border-r border-white/10"
                  />
                ))}
              </tr>
            </tfoot>
          )}
        </table>
      </div>
    </div>
  );
}
