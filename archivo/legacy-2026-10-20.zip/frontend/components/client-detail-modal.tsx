"use client";

import React, { useState, useEffect, useMemo, useCallback } from "react";
import {
  X,
  Search,
  Building2,
  TrendingUp,
  BarChart3,
  DollarSign,
  Package,
  Layers,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  CornerDownRight,
  RefreshCw,
  MapPin,
  UserCheck,
  Users,
  ShieldCheck,
  PlusSquare,
  MinusSquare,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  ClientColumn,
  ClientInfo,
  ClientDetailBrand,
  ClientDetailSKU,
  ClientMatrixResponse,
  FilterState,
} from "@/types";
import { formatNumber, formatPercent, getApiPath } from "@/lib/utils";

interface ClientDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  client: ClientColumn | ClientInfo | null;
  filters: FilterState;
}

export type DetailSortField =
  | "marca"
  | "vta_act"
  | "vta_mdo"
  | "ms_act"
  | "ms_ant"
  | "ms_territorio"
  | "ms_ideal"
  | "estimacion"
  | string;

export function ClientDetailModal({
  isOpen,
  onClose,
  client,
  filters,
}: ClientDetailModalProps) {
  const [data, setData] = useState<ClientMatrixResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [sortField, setSortField] = useState<DetailSortField>("estimacion");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const [collapsedBrands, setCollapsedBrands] = useState<Set<string>>(new Set());
  const [modalUnit, setModalUnit] = useState<"UNIDAD" | "S/ SOLES">(
    filters.unidadMedida
  );

  // Sync unit when main filters change
  useEffect(() => {
    setModalUnit(filters.unidadMedida);
  }, [filters.unidadMedida]);

  // Fetch recalculated client matrix data
  const fetchClientData = useCallback(async () => {
    if (!client) return;
    setIsLoading(true);
    setError(null);

    const clientId = client.cp_cliente || client.ruc;

    try {
      const payload = {
        client: clientId,
        unidadMedida: modalUnit,
        unidadNegocio: filters.unidadNegocio ? [filters.unidadNegocio] : [],
        franquicia: filters.franquicia ? [filters.franquicia] : [],
        marca: filters.marca ? [filters.marca] : [],
        search: "",
      };

      const res = await fetch(getApiPath("/api/client-matrix"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const json = await res.json();
      if (json.success && json.data) {
        setData(json.data);
      } else {
        setError(json.error || "No se pudo cargar la información del cliente");
      }
    } catch (e: any) {
      console.error("Error cargando desglose de cliente:", e);
      setError("Error de conexión al servidor");
    } finally {
      setIsLoading(false);
    }
  }, [client, modalUnit, filters.unidadNegocio, filters.franquicia, filters.marca]);

  useEffect(() => {
    if (isOpen && client) {
      setSearchTerm("");
      setCollapsedBrands(new Set());
      fetchClientData();
    }
  }, [isOpen, client, modalUnit, fetchClientData]);

  const isSoles = modalUnit === "S/ SOLES";

  const handleSort = (field: DetailSortField) => {
    if (sortField === field) {
      setSortDir((prev) => (prev === "asc" ? "desc" : "asc"));
    } else {
      setSortField(field);
      setSortDir(field === "marca" ? "asc" : "desc");
    }
  };

  const toggleBrand = (brandKey: string) => {
    setCollapsedBrands((prev) => {
      const next = new Set(prev);
      if (next.has(brandKey)) next.delete(brandKey);
      else next.add(brandKey);
      return next;
    });
  };

  const handleExpandAll = (expand: boolean) => {
    if (expand) {
      setCollapsedBrands(new Set());
    } else {
      if (data?.brands) {
        setCollapsedBrands(
          new Set(
            data.brands.map(
              (b) => `${b.marca}__${b.unidad_negocio || ""}__${b.franquicia || ""}`
            )
          )
        );
      }
    }
  };

  const getBrandKey = (b: ClientDetailBrand) =>
    `${b.marca}__${b.unidad_negocio || ""}__${b.franquicia || ""}`;

  // Filter & Sort brands and SKUs
  const processedBrands = useMemo(() => {
    if (!data?.brands) return [];

    const term = searchTerm.toLowerCase().trim();
    let list = data.brands;

    // Filter by search term
    if (term) {
      list = list.filter((b) => {
        const brandMatch = b.marca.toLowerCase().includes(term);
        const skuMatch = b.skus?.some((s) => s.sku.toLowerCase().includes(term));
        return brandMatch || skuMatch;
      });
    }

    // Sort Brands
    const sorted = [...list].sort((a, b) => {
      if (sortField === "marca") {
        return sortDir === "asc"
          ? a.marca.localeCompare(b.marca)
          : b.marca.localeCompare(a.marca);
      }
      const valA =
        a.distribuidoras && sortField in a.distribuidoras
          ? Number(a.distribuidoras[sortField]) || 0
          : Number((a as any)[sortField]) || 0;
      const valB =
        b.distribuidoras && sortField in b.distribuidoras
          ? Number(b.distribuidoras[sortField]) || 0
          : Number((b as any)[sortField]) || 0;
      return sortDir === "asc" ? valA - valB : valB - valA;
    });

    // Sort SKUs inside each brand
    return sorted.map((b) => {
      if (!b.skus || b.skus.length === 0) return b;
      const sortedSkus = [...b.skus].sort((sa, sb) => {
        if (sortField === "marca") {
          return sortDir === "asc"
            ? sa.sku.localeCompare(sb.sku)
            : sb.sku.localeCompare(sa.sku);
        }
        const valA =
          sa.distribuidoras && sortField in sa.distribuidoras
            ? Number(sa.distribuidoras[sortField]) || 0
            : Number((sa as any)[sortField]) || 0;
        const valB =
          sb.distribuidoras && sortField in sb.distribuidoras
            ? Number(sb.distribuidoras[sortField]) || 0
            : Number((sb as any)[sortField]) || 0;
        return sortDir === "asc" ? valA - valB : valB - valA;
      });
      return { ...b, skus: sortedSkus };
    });
  }, [data?.brands, searchTerm, sortField, sortDir]);

  const renderSortIcon = (field: DetailSortField) => {
    if (sortField !== field) {
      return (
        <ArrowUpDown className="h-3 w-3 opacity-40 group-hover:opacity-100 transition-opacity" />
      );
    }
    return sortDir === "asc" ? (
      <ArrowUp className="h-3.5 w-3.5 text-[#38bdf8] font-black" />
    ) : (
      <ArrowDown className="h-3.5 w-3.5 text-[#38bdf8] font-black" />
    );
  };

  const getQuintilBadgeClass = (q: string) => {
    switch (q?.toUpperCase()) {
      case "DIAMANTE":
      case "Q1":
        return "bg-[#ede9fe] text-[#6d28d9] border border-[#ddd6fe]";
      case "ORO":
      case "Q2":
        return "bg-[#fef3c7] text-[#b45309] border border-[#fde68a]";
      case "PLATA":
      case "Q3":
        return "bg-[#dbeafe] text-[#1d4ed8] border border-[#bfdbfe]";
      case "BRONCE":
      case "Q4":
        return "bg-[#d1fae5] text-[#047857] border border-[#a7f3d0]";
      case "PLOMO":
      case "Q5":
        return "bg-[#f1f5f9] text-[#475569] border border-[#e2e8f0]";
      default:
        return "bg-slate-100 text-slate-500 border border-slate-200";
    }
  };

  const clientInfo = data?.client || client;
  const totals = data?.totals || null;
  const distributors = data?.distributors || [];

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-[96vw] 2xl:max-w-[1480px] max-h-[92vh] flex flex-col p-0 overflow-hidden bg-white border border-slate-200 shadow-2xl rounded-2xl">
        {/* MODAL HEADER */}
        <DialogHeader className="p-3.5 sm:p-5 pb-3 bg-[#1d252d] text-white border-b border-slate-800">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex items-start gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#6a5cbc] text-white shadow-inner">
                <Building2 className="h-5 w-5" />
              </div>
              <div className="space-y-0.5">
                <div className="flex flex-wrap items-center gap-2">
                  <DialogTitle className="text-base sm:text-lg font-bold text-white tracking-tight">
                    {clientInfo?.farmacia || clientInfo?.cp_cliente || "Detalle de Cliente"}
                  </DialogTitle>
                  {clientInfo?.quintil && (
                    <span
                      className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${getQuintilBadgeClass(
                        clientInfo.quintil
                      )}`}
                    >
                      {clientInfo.categorizacion || clientInfo.quintil}
                    </span>
                  )}
                  {clientInfo?.zonabase && (
                    <span className="flex items-center gap-1 text-[10px] text-amber-200 bg-amber-950/70 px-2 py-0.5 rounded-md border border-amber-800">
                      <MapPin className="h-3 w-3 text-amber-400 shrink-0" />
                      <span>{clientInfo.zonabase}</span>
                    </span>
                  )}
                  {clientInfo?.supervisor && (
                    <span className="flex items-center gap-1 text-[10px] text-sky-200 bg-sky-950/70 px-2 py-0.5 rounded-md border border-sky-800" title="Supervisor de Ventas">
                      <UserCheck className="h-3 w-3 text-sky-400 shrink-0" />
                      <span><strong className="text-sky-300">SSVV:</strong> {clientInfo.supervisor}</span>
                    </span>
                  )}
                  {clientInfo?.vendedores && clientInfo.vendedores.length > 0 && (
                    <span className="flex items-center gap-1 text-[10px] text-purple-200 bg-purple-950/70 px-2 py-0.5 rounded-md border border-purple-800" title="Fuerza de Ventas / Vendedores">
                      <Users className="h-3 w-3 text-purple-400 shrink-0" />
                      <span><strong className="text-purple-300">FFVV:</strong> {clientInfo.vendedores.join(", ")}</span>
                    </span>
                  )}
                  {clientInfo?.lima_provincias && !clientInfo?.zonabase && (
                    <span className="flex items-center gap-1 text-[10px] text-slate-300 bg-slate-800 px-2 py-0.5 rounded-md border border-slate-700">
                      <MapPin className="h-3 w-3 text-cyan-400 shrink-0" />
                      {clientInfo.lima_provincias}
                    </span>
                  )}
                </div>
                <DialogDescription className="text-xs text-slate-300 flex flex-wrap items-center gap-3">
                  <span>
                    RUC: <strong className="text-white font-mono">{clientInfo?.ruc || "-"}</strong>
                  </span>
                  <span>&bull;</span>
                  <span>
                    Periodo: <strong className="text-white">Enero 2026 - Mayo 2026</strong>
                  </span>
                  <span>&bull;</span>
                  <span className="text-[#38bdf8] font-medium">
                    Pedidos Sugeridos Recalculada por Cliente
                  </span>
                </DialogDescription>
              </div>
            </div>

            {/* Top Right Actions: Unit Toggle & Refresh */}
            <div className="flex items-center gap-2 self-end md:self-auto">
              <div className="flex items-center rounded-lg border border-slate-700 bg-slate-800/80 p-0.5 text-xs">
                <button
                  type="button"
                  onClick={() => setModalUnit("UNIDAD")}
                  className={`flex items-center gap-1 rounded-md px-2.5 py-1 text-[11px] font-bold transition-colors ${
                    modalUnit === "UNIDAD"
                      ? "bg-[#6a5cbc] text-white shadow-xs"
                      : "text-slate-300 hover:text-white"
                  }`}
                >
                  <Package className="h-3 w-3" />
                  UNIDADES
                </button>
                <button
                  type="button"
                  onClick={() => setModalUnit("S/ SOLES")}
                  className={`flex items-center gap-1 rounded-md px-2.5 py-1 text-[11px] font-bold transition-colors ${
                    modalUnit === "S/ SOLES"
                      ? "bg-[#6a5cbc] text-white shadow-xs"
                      : "text-slate-300 hover:text-white"
                  }`}
                >
                  <DollarSign className="h-3 w-3" />
                  S/ SOLES
                </button>
              </div>

              <Button
                variant="ghost"
                size="sm"
                onClick={fetchClientData}
                disabled={isLoading}
                className="h-8 w-8 p-0 text-slate-300 hover:text-white hover:bg-slate-800"
                title="Recargar datos"
              >
                <RefreshCw className={`h-3.5 w-3.5 ${isLoading ? "animate-spin" : ""}`} />
              </Button>
            </div>
          </div>
        </DialogHeader>

        {/* CLIENT KPI SUMMARY CARDS */}
        <div className="bg-[#f8fafc] px-4 py-3 border-b border-slate-200">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
            {/* Card 1: VTA ACT */}
            <div className="rounded-xl border border-slate-200 bg-white p-2.5 shadow-2xs">
              <div className="flex items-center justify-between text-slate-500 mb-1">
                <span className="text-[10px] font-bold uppercase tracking-wider">
                  Vta. Act. Mensual
                </span>
                <TrendingUp className="h-3.5 w-3.5 text-purple-600" />
              </div>
              <div className="text-sm sm:text-base font-extrabold text-[#1d252d] tabular-nums">
                {totals ? formatNumber(totals.vta_act, isSoles) : "-"}
              </div>
              <p className="text-[10px] text-slate-400">
                {isSoles ? "Soles (S/) / mes" : "Unidades / mes"}
              </p>
            </div>

            {/* Card 2: VTA MDO */}
            <div className="rounded-xl border border-slate-200 bg-white p-2.5 shadow-2xs">
              <div className="flex items-center justify-between text-slate-500 mb-1">
                <span className="text-[10px] font-bold uppercase tracking-wider">
                  Vta. Mdo. Mensual
                </span>
                <BarChart3 className="h-3.5 w-3.5 text-sky-600" />
              </div>
              <div className="text-sm sm:text-base font-extrabold text-slate-700 tabular-nums">
                {totals ? formatNumber(totals.vta_mdo, isSoles) : "-"}
              </div>
              <p className="text-[10px] text-slate-400">Total mercado auditado</p>
            </div>

            {/* Card 3: MS ACT */}
            <div className="rounded-xl border border-slate-200 bg-white p-2.5 shadow-2xs">
              <div className="flex items-center justify-between text-slate-500 mb-1">
                <span className="text-[10px] font-bold uppercase tracking-wider">
                  Market Share Actual
                </span>
                <span className="text-[10px] font-bold text-amber-600 bg-amber-50 px-1.5 py-0.2 rounded-full border border-amber-200">
                  MS
                </span>
              </div>
              <div className="text-sm sm:text-base font-extrabold text-[#1d252d] tabular-nums">
                {totals ? formatPercent(totals.ms_act) : "-"}
              </div>
              <p className="text-[10px] text-slate-400">Participación en cliente</p>
            </div>

            {/* Card 4: MS IDEAL */}
            <div className="rounded-xl border border-slate-200 bg-white p-2.5 shadow-2xs">
              <div className="flex items-center justify-between text-slate-500 mb-1">
                <span className="text-[10px] font-bold uppercase tracking-wider">
                  MS. Ideal (Recupero)
                </span>
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />
              </div>
              <div className="text-sm sm:text-base font-extrabold text-emerald-700 tabular-nums">
                {totals ? formatPercent(totals.ms_ideal) : "-"}
              </div>
              <p className="text-[10px] text-slate-400">Objetivo sugerido</p>
            </div>

            {/* Card 5: ESTIMACION */}
            <div className="rounded-xl border border-[#6a5cbc]/30 bg-[#6a5cbc]/5 p-2.5 shadow-2xs col-span-2 sm:col-span-1">
              <div className="flex items-center justify-between text-[#53459e] mb-1">
                <span className="text-[10px] font-extrabold uppercase tracking-wider">
                  Estimación Mensual
                </span>
                <TrendingUp className="h-3.5 w-3.5 text-[#6a5cbc]" />
              </div>
              <div className="text-sm sm:text-base font-black text-[#53459e] tabular-nums">
                {totals ? formatNumber(totals.estimacion, isSoles) : "-"}
              </div>
              <p className="text-[10px] text-slate-500">Potencial mensual proyectado</p>
            </div>
          </div>
        </div>

        {/* TOOLBAR: SEARCH & TREE EXPANSION */}
        <div className="px-4 py-2.5 bg-white border-b border-slate-200 flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center gap-2">
            <div className="relative w-64 sm:w-80">
              <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
              <Input
                placeholder="Buscar marca o SKU en este cliente..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8 h-8 text-xs bg-slate-50 border-slate-200 focus:bg-white"
              />
            </div>

            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleExpandAll(true)}
                className="h-8 px-2.5 text-[11px] font-semibold text-slate-700 hover:bg-slate-100"
              >
                <PlusSquare className="h-3.5 w-3.5 mr-1 text-[#6a5cbc]" />
                Expandir Todo
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleExpandAll(false)}
                className="h-8 px-2.5 text-[11px] font-semibold text-slate-700 hover:bg-slate-100"
              >
                <MinusSquare className="h-3.5 w-3.5 mr-1 text-slate-500" />
                Colapsar Todo
              </Button>
            </div>
          </div>

          <div className="text-xs text-slate-500 flex items-center gap-2 font-medium">
            <span>
              Mostrando:{" "}
              <strong className="text-slate-800 font-bold">
                {processedBrands.length} marcas
              </strong>
            </span>
          </div>
        </div>

        {/* TABLE CONTAINER - EXACT LAYOUT OF IMAGE 2 with dynamic viewport height */}
        <div className="flex-1 overflow-auto relative min-h-[350px] max-h-[calc(92vh-270px)] bg-slate-50/30">
          {isLoading && (
            <div className="absolute inset-0 z-40 flex items-center justify-center bg-white/75 backdrop-blur-2xs">
              <div className="flex items-center gap-3 rounded-xl border border-slate-200 bg-white px-5 py-3 shadow-md">
                <div className="h-5 w-5 animate-spin rounded-full border-2 border-[#6a5cbc] border-t-transparent" />
                <span className="text-xs font-semibold text-slate-700">
                  Recalculando Pedidos Sugeridos para este cliente...
                </span>
              </div>
            </div>
          )}

          {error && (
            <div className="p-12 text-center text-xs text-rose-600 font-medium">
              {error}
            </div>
          )}

          {!isLoading && !error && (
            <table className="w-full border-collapse text-left text-xs bg-white">
              {/* LEVEL 1 HEADERS */}
              <thead className="sticky top-0 z-30">
                <tr className="header-level-1">
                  {/* Left Sticky Header */}
                  <th
                    rowSpan={2}
                    onClick={() => handleSort("marca")}
                    className="sticky left-0 top-0 z-40 min-w-[250px] sm:min-w-[280px] md:min-w-[320px] max-w-[420px] bg-[#6a5cbc] text-white p-2 sm:p-2.5 font-bold group cursor-pointer hover:bg-[#53459e] transition-colors border-r-2 border-[#53459e] select-none shadow-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5 text-xs">
                        Etiquetas de fila
                        {renderSortIcon("marca")}
                      </span>
                      <span className="bg-white/20 text-white text-[10px] sm:text-[11px] font-semibold px-2 py-0.5 rounded-full">
                        {processedBrands.length} marcas
                      </span>
                    </div>
                  </th>

                  {/* Central Spanning Header */}
                  <th
                    colSpan={7}
                    className="bg-[#6a5cbc] text-white p-2 text-center font-bold tracking-wider uppercase text-xs border-l border-white/20 select-none"
                  >
                    ANÁLISIS DE Pedidos Sugeridos
                  </th>

                  {/* Right Spanning Header for Distributors */}
                  {distributors.length > 0 && (
                    <th
                      colSpan={distributors.length}
                      className="bg-[#1d252d] text-[#38bdf8] p-2 text-center font-bold tracking-wider uppercase text-xs border-l-2 border-slate-700 select-none shadow-xs"
                    >
                      COMPRAS POR DISTRIBUIDOR (PROM. MENSUAL ENE-MAY 2026)
                    </th>
                  )}
                </tr>

                {/* LEVEL 2 METRIC HEADERS */}
                <tr className="header-level-2 text-[11px] font-bold text-white uppercase tracking-wider">
                  <th
                    onClick={() => handleSort("vta_act")}
                    className="group cursor-pointer p-2 bg-[#53459e] hover:bg-[#473a8b] text-right min-w-[105px] border-r border-white/20 select-none transition-colors"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>VTA. ACT.</span>
                      {renderSortIcon("vta_act")}
                    </div>
                  </th>

                  <th
                    onClick={() => handleSort("vta_mdo")}
                    className="group cursor-pointer p-2 bg-[#53459e] hover:bg-[#473a8b] text-right min-w-[105px] border-r border-white/20 select-none transition-colors"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>VTA. MDO.</span>
                      {renderSortIcon("vta_mdo")}
                    </div>
                  </th>

                  <th
                    onClick={() => handleSort("ms_act")}
                    className="group cursor-pointer p-2 bg-[#53459e] hover:bg-[#473a8b] text-right min-w-[90px] border-r border-white/20 select-none transition-colors"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>MS. ACT.</span>
                      {renderSortIcon("ms_act")}
                    </div>
                  </th>

                  <th
                    onClick={() => handleSort("ms_ant")}
                    className="group cursor-pointer p-2 bg-[#53459e] hover:bg-[#473a8b] text-right min-w-[90px] border-r border-white/20 select-none transition-colors"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>MS. ANT.</span>
                      {renderSortIcon("ms_ant")}
                    </div>
                  </th>

                  <th
                    onClick={() => handleSort("ms_territorio")}
                    className="group cursor-pointer p-2 bg-[#53459e] hover:bg-[#473a8b] text-right min-w-[105px] border-r border-white/20 select-none transition-colors"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>MS. TERRITORIO</span>
                      {renderSortIcon("ms_territorio")}
                    </div>
                  </th>

                  <th
                    onClick={() => handleSort("ms_ideal")}
                    className="group cursor-pointer p-2 bg-[#1d252d] hover:bg-[#2b353f] text-right min-w-[95px] border-r border-white/20 select-none transition-colors"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>MS. IDEAL</span>
                      {renderSortIcon("ms_ideal")}
                    </div>
                  </th>

                  <th
                    onClick={() => handleSort("estimacion")}
                    className="group cursor-pointer p-2 bg-[#1d252d] hover:bg-[#2b353f] text-right min-w-[120px] text-[#38bdf8] select-none transition-colors font-extrabold border-r-2 border-slate-700"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>ESTIMACION</span>
                      {renderSortIcon("estimacion")}
                    </div>
                  </th>

                  {/* Distributor Dynamic Subheaders */}
                  {distributors.map((dist) => (
                    <th
                      key={dist}
                      onClick={() => handleSort(dist)}
                      className="group cursor-pointer p-2 bg-[#2b353f] hover:bg-[#3b4754] text-right min-w-[140px] max-w-[200px] border-r border-slate-700 select-none transition-colors text-[10px]"
                      title={dist}
                    >
                      <div className="flex items-center justify-end gap-1">
                        <span className="truncate">{dist}</span>
                        {renderSortIcon(dist)}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>

              {/* TABLE BODY */}
              <tbody className="divide-y divide-slate-100">
                {processedBrands.length === 0 ? (
                  <tr>
                    <td
                      colSpan={8 + distributors.length}
                      className="p-12 text-center text-slate-400 text-xs bg-white"
                    >
                      No se encontraron marcas ni productos para los filtros seleccionados en este cliente.
                    </td>
                  </tr>
                ) : (
                  processedBrands.map((brand, brandIdx) => {
                    const brandKey = getBrandKey(brand);
                    const brandId = `modal_b_${brandKey}_${brandIdx}`;
                    const isCollapsed = collapsedBrands.has(brandKey);
                    const hasSkus = brand.skus && brand.skus.length > 0;

                    return (
                      <React.Fragment key={brandId}>
                        {/* Brand Row */}
                        <tr className="bg-[#f8fafc] hover:bg-slate-100 transition-colors font-bold text-[#1d252d] border-t border-b border-slate-300 group">
                          {/* Sticky Brand Name Column */}
                          <td className="sticky left-0 z-10 bg-[#f8fafc] group-hover:bg-slate-100 p-2.5 border-r-2 border-slate-300 shadow-2xs">
                            <div
                              onClick={() => hasSkus && toggleBrand(brandKey)}
                              className={`flex items-center gap-2 select-none ${
                                hasSkus ? "cursor-pointer" : ""
                              }`}
                            >
                              {hasSkus ? (
                                <span className="w-4 h-4 rounded bg-[#6a5cbc] hover:bg-[#53459e] text-white flex items-center justify-center text-[10px] shrink-0 transition-colors">
                                  {isCollapsed ? "+" : "-"}
                                </span>
                              ) : (
                                <span className="w-4 h-4 shrink-0" />
                              )}
                              <span className="font-bold text-[#1d252d] text-xs tracking-tight truncate">
                                {brand.marca}
                              </span>
                              {brand.franquicia && brand.franquicia !== "RESTO" && (
                                <span className="text-[10px] text-slate-500 font-normal truncate">
                                  ({brand.franquicia})
                                </span>
                              )}
                              {hasSkus && (
                                <span className="rounded bg-slate-200 text-slate-600 px-1.5 py-0.2 text-[10px] font-semibold">
                                  {brand.skus.length} SKU{brand.skus.length !== 1 ? "s" : ""}
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Brand 7 Metrics */}
                          <td className="p-2 text-right font-bold tabular-nums text-[#1d252d] border-r border-slate-200">
                            {formatNumber(brand.vta_act, isSoles)}
                          </td>
                          <td className="p-2 text-right tabular-nums text-slate-600 border-r border-slate-200">
                            {formatNumber(brand.vta_mdo, isSoles)}
                          </td>
                          <td className="p-2 text-right tabular-nums font-bold text-[#1d252d] border-r border-slate-200">
                            {formatPercent(brand.ms_act)}
                          </td>
                          <td className="p-2 text-right tabular-nums text-slate-600 border-r border-slate-200">
                            {formatPercent(brand.ms_ant)}
                          </td>
                          <td className="p-2 text-right tabular-nums text-slate-600 border-r border-slate-200">
                            {formatPercent(brand.ms_territorio)}
                          </td>
                          <td className="p-2 text-right tabular-nums font-bold text-[#1d252d] border-r border-slate-200">
                            {formatPercent(brand.ms_ideal)}
                          </td>
                          <td className="p-2 text-right tabular-nums font-extrabold text-[#53459e] bg-[#6a5cbc]/5 border-r-2 border-slate-300">
                            {formatNumber(brand.estimacion, isSoles)}
                          </td>

                          {/* Brand Distributor Sales */}
                          {distributors.map((dist) => {
                            const val = brand.distribuidoras?.[dist] || 0;
                            return (
                              <td
                                key={dist}
                                className="p-2 text-right font-semibold tabular-nums text-slate-800 bg-slate-50/70 border-r border-slate-200"
                              >
                                {val > 0 ? formatNumber(val, isSoles) : "-"}
                              </td>
                            );
                          })}
                        </tr>

                        {/* SKU Rows */}
                        {!isCollapsed &&
                          hasSkus &&
                          brand.skus.map((sku, skuIdx) => {
                            const skuId = `${brandId}__sku_${skuIdx}`;
                            return (
                              <tr
                                key={skuId}
                                className="hover:bg-slate-50 transition-colors text-slate-600 bg-white group border-b border-slate-100"
                              >
                                {/* Sticky SKU Name Column */}
                                <td className="sticky left-0 z-10 bg-white group-hover:bg-slate-50 p-2 pl-8 text-xs border-r-2 border-slate-200">
                                  <div className="flex items-center gap-1.5 truncate max-w-[380px]">
                                    <CornerDownRight className="h-3 w-3 text-slate-400 shrink-0" />
                                    <span
                                      title={sku.sku}
                                      className="truncate font-normal text-slate-700 text-xs"
                                    >
                                      {sku.sku}
                                    </span>
                                  </div>
                                </td>

                                {/* SKU 7 Metrics */}
                                <td className="p-1.5 text-right tabular-nums text-slate-700 border-r border-slate-100">
                                  {formatNumber(sku.vta_act, isSoles)}
                                </td>
                                <td className="p-1.5 text-right tabular-nums text-slate-400 border-r border-slate-100">
                                  {formatNumber(sku.vta_mdo, isSoles)}
                                </td>
                                <td className="p-1.5 text-right tabular-nums text-slate-600 border-r border-slate-100">
                                  {formatPercent(sku.ms_act)}
                                </td>
                                <td className="p-1.5 text-right tabular-nums text-slate-400 border-r border-slate-100">
                                  {formatPercent(sku.ms_ant)}
                                </td>
                                <td className="p-1.5 text-right tabular-nums text-slate-400 border-r border-slate-100">
                                  {formatPercent(sku.ms_territorio)}
                                </td>
                                <td className="p-1.5 text-right tabular-nums font-medium text-[#1d252d] border-r border-slate-100">
                                  {formatPercent(sku.ms_ideal)}
                                </td>
                                <td className="p-1.5 text-right tabular-nums font-semibold text-[#6a5cbc] bg-[#6a5cbc]/5 border-r-2 border-slate-200">
                                  {formatNumber(sku.estimacion, isSoles)}
                                </td>

                                {/* SKU Distributor Sales */}
                                {distributors.map((dist) => {
                                  const val = sku.distribuidoras?.[dist] || 0;
                                  return (
                                    <td
                                      key={dist}
                                      className="p-1.5 text-right tabular-nums text-slate-600 bg-white border-r border-slate-100"
                                    >
                                      {val > 0 ? formatNumber(val, isSoles) : "-"}
                                    </td>
                                  );
                                })}
                              </tr>
                            );
                          })}
                      </React.Fragment>
                    );
                  })
                )}
              </tbody>

              {/* TABLE FOOTER (TOTAL GENERAL) */}
              {totals && (
                <tfoot className="sticky bottom-0 z-30 font-bold text-xs shadow-md">
                  <tr className="border-t-2 border-[#1d252d]">
                    <td className="sticky left-0 z-40 bg-[#1d252d] text-white p-2.5 border-r-2 border-white/20 tracking-wider font-extrabold shadow-sm">
                      TOTAL GENERAL
                    </td>
                    <td className="p-2.5 text-right tabular-nums bg-[#2b353f] text-white border-r border-white/10">
                      {formatNumber(totals.vta_act, isSoles)}
                    </td>
                    <td className="p-2.5 text-right tabular-nums bg-[#2b353f] text-slate-300 font-normal border-r border-white/10">
                      {formatNumber(totals.vta_mdo, isSoles)}
                    </td>
                    <td className="p-2.5 text-right tabular-nums bg-[#2b353f] text-[#38bdf8] font-bold border-r border-white/10">
                      {formatPercent(totals.ms_act)}
                    </td>
                    <td className="p-2.5 text-right tabular-nums bg-[#2b353f] text-slate-300 font-normal border-r border-white/10">
                      {formatPercent(totals.ms_ant)}
                    </td>
                    <td className="p-2.5 text-right tabular-nums bg-[#2b353f] text-slate-300 font-normal border-r border-white/10">
                      {formatPercent(totals.ms_territorio)}
                    </td>
                    <td className="p-2.5 text-right tabular-nums bg-[#2b353f] text-white border-r border-white/10">
                      {formatPercent(totals.ms_ideal)}
                    </td>
                    <td className="p-2.5 text-right tabular-nums bg-[#2b353f] text-[#38bdf8] font-black border-r-2 border-slate-700">
                      {formatNumber(totals.estimacion, isSoles)}
                    </td>

                    {/* Total General Distributor Sales */}
                    {distributors.map((dist) => {
                      const val = totals.distribuidoras?.[dist] || 0;
                      return (
                        <td
                          key={dist}
                          className="p-2.5 text-right tabular-nums bg-[#1d252d] text-[#38bdf8] font-bold border-r border-white/10"
                        >
                          {formatNumber(val, isSoles)}
                        </td>
                      );
                    })}
                  </tr>
                </tfoot>
              )}
            </table>
          )}
        </div>

        {/* FOOTER */}
        <div className="p-3 px-5 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs">
          <div className="text-slate-500 font-medium">
            Desglose exclusivo para el cliente:{" "}
            <strong className="text-slate-700 font-bold">
              {clientInfo?.farmacia || clientInfo?.cp_cliente}
            </strong>
          </div>
          <Button
            variant="default"
            size="sm"
            onClick={onClose}
            className="bg-[#6a5cbc] hover:bg-[#53459e] text-white font-bold text-xs h-8 px-4"
          >
            Cerrar Ventana
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
