"use client";

import React, { useState, useMemo } from "react";
import { Search, Users, Check, X, SlidersHorizontal } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { ClientOption } from "@/types";
import { getApiPath } from "@/lib/utils";

interface ClientModalProps {
  isOpen: boolean;
  onClose: () => void;
  clients: ClientOption[];
  selectedClients: string[];
  activeCategory: string;
  activeZonaBase?: string;
  activeSupervisor?: string;
  onApply: (selected: string[]) => void;
}

export function ClientModal({
  isOpen,
  onClose,
  clients,
  selectedClients,
  activeCategory,
  activeZonaBase,
  activeSupervisor,
  onApply,
}: ClientModalProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [tempSelected, setTempSelected] = useState<string[]>(selectedClients);
  const [searchResults, setSearchResults] = useState<ClientOption[] | null>(null);
  const [isSearching, setIsSearching] = useState(false);

  // Sync tempSelected when modal opens
  React.useEffect(() => {
    if (isOpen) {
      setTempSelected(selectedClients);
      setSearchTerm("");
      setSearchResults(null);
    }
  }, [isOpen, selectedClients]);

  // Server-side search when user types in search box
  React.useEffect(() => {
    if (!searchTerm.trim()) {
      setSearchResults(null);
      setIsSearching(false);
      return;
    }

    const timer = setTimeout(async () => {
      setIsSearching(true);
      try {
        const params = new URLSearchParams({
          q: searchTerm.trim(),
          category: activeCategory || "",
          zonaBase: activeZonaBase || "",
          supervisor: activeSupervisor || "",
          limit: "100"
        });
        const res = await fetch(getApiPath(`/api/search-clients?${params.toString()}`));
        const json = await res.json();
        if (json.success && Array.isArray(json.data)) {
          setSearchResults(json.data);
        }
      } catch (e) {
        console.error("Search clients error:", e);
      } finally {
        setIsSearching(false);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [searchTerm, activeCategory, activeZonaBase, activeSupervisor]);

  // Use search results if searching, otherwise categorized filtered list (capped to 100 + selected for performance)
  const { filteredClients, totalAvailableCount } = useMemo(() => {
    if (searchResults !== null) {
      return { filteredClients: searchResults, totalAvailableCount: searchResults.length };
    }

    let list = clients;

    // Filter by active category
    if (activeCategory) {
      const catMap: Record<string, string> = {
        Q1: "DIAMANTE",
        Q2: "ORO",
        Q3: "PLATA",
        Q4: "BRONCE",
        Q5: "PLOMO",
      };
      const catTarget = catMap[activeCategory] || activeCategory;
      list = list.filter(
        (c) => c.categorizacion === catTarget || c.quintil === activeCategory
      );
    }

    // Filter by active zona base
    if (activeZonaBase) {
      list = list.filter((c) => c.zonabase === activeZonaBase);
    }

    // Filter by active supervisor
    if (activeSupervisor) {
      list = list.filter((c) => c.supervisor === activeSupervisor);
    }

    const totalCount = list.length;
    let displayList = list;
    if (list.length > 100) {
      const top100 = list.slice(0, 100);
      const top100Cps = new Set(top100.map((c) => c.cp_cliente));
      const selectedExtra = list.filter((c) => tempSelected.includes(c.cp_cliente) && !top100Cps.has(c.cp_cliente));
      displayList = [...selectedExtra, ...top100];
    }

    return { filteredClients: displayList, totalAvailableCount: totalCount };
  }, [searchResults, clients, activeCategory, activeZonaBase, activeSupervisor, tempSelected]);

  const toggleClient = (cp: string) => {
    setTempSelected((prev) =>
      prev.includes(cp) ? prev.filter((item) => item !== cp) : [...prev, cp]
    );
  };

  const handleSelectTop = (n: number) => {
    const top = filteredClients.slice(0, n).map((c) => c.cp_cliente);
    setTempSelected(top);
  };

  const handleSelectAll = () => {
    setTempSelected(filteredClients.map((c) => c.cp_cliente));
  };

  const handleClear = () => {
    setTempSelected([]);
  };

  const handleSave = () => {
    onApply(tempSelected);
    onClose();
  };

  const getBadgeVariant = (q: string) => {
    switch (q?.toUpperCase()) {
      case "Q1": return "q1";
      case "Q2": return "q2";
      case "Q3": return "q3";
      case "Q4": return "q4";
      case "Q5": return "q5";
      default: return "secondary";
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-h-[85vh] flex flex-col p-0 sm:max-w-2xl">
        <DialogHeader className="p-5 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-purple-50 text-primary">
              <Users className="h-4 w-4" />
            </div>
            <div>
              <DialogTitle className="text-base font-semibold">
                Seleccionar Columnas de Clientes
              </DialogTitle>
              <DialogDescription className="text-xs text-slate-500">
                Categoría activa:{" "}
                <strong className="text-primary">
                  {activeCategory || "Todas las categorías"}
                </strong>{" "}
                &bull; Disponibles: <strong>{totalAvailableCount}</strong>
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        {/* Search & Quick Actions Bar */}
        <div className="p-4 pb-2 space-y-3 bg-slate-50/50 border-b border-slate-100">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Buscar por RUC, Farmacia o Código..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 pr-8 bg-white text-xs h-9"
            />
            {isSearching && (
              <div className="absolute right-3 top-2.5 h-4 w-4 animate-spin rounded-full border-2 border-[#6a5cbc] border-t-transparent" />
            )}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-medium">Selección rápida:</span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleSelectTop(8)}
                className="h-7 px-2 text-[11px]"
              >
                Top 8
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleSelectTop(16)}
                className="h-7 px-2 text-[11px]"
              >
                Top 16
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleSelectAll}
                className="h-7 px-2 text-[11px]"
              >
                Todos
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleClear}
                className="h-7 px-2 text-[11px] text-slate-500 hover:text-red-600"
              >
                Limpiar
              </Button>
            </div>

            <div className="text-slate-600 font-medium text-xs">
              Seleccionados:{" "}
              <span className="font-bold text-primary">{tempSelected.length}</span>
            </div>
          </div>
        </div>

        {/* Client List */}
        <div className="flex-1 overflow-y-auto p-3 divide-y divide-slate-100">
          {searchResults === null && totalAvailableCount > filteredClients.length && (
            <div className="mb-2 p-2 px-3 text-[11px] font-medium text-[#53459e] bg-[#ede9fe] rounded-md border border-[#ddd6fe]">
              Mostrando los primeros 100 de {totalAvailableCount} clientes categorizados. Escribe en el buscador para buscar en toda la base de datos en tiempo real.
            </div>
          )}
          {filteredClients.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400">
              No se encontraron clientes para el filtro actual.
            </div>
          ) : (
            filteredClients.map((client) => {
              const isChecked = tempSelected.includes(client.cp_cliente);
              return (
                <div
                  key={client.cp_cliente}
                  onClick={() => toggleClient(client.cp_cliente)}
                  className={`flex items-center justify-between p-2.5 rounded-md cursor-pointer transition-colors ${
                    isChecked ? "bg-purple-50/60" : "hover:bg-slate-50"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Checkbox
                      checked={isChecked}
                      onCheckedChange={() => toggleClient(client.cp_cliente)}
                    />
                    <div>
                      <p className="text-xs font-medium text-slate-800">
                        {client.cp_cliente}
                      </p>
                      <p className="text-[11px] text-slate-400">
                        RUC: {client.ruc}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {client.zonabase && (
                      <span className="text-[10px] text-[#6a5cbc] bg-purple-50 px-1.5 py-0.5 rounded font-semibold border border-purple-200">
                        {client.zonabase}
                      </span>
                    )}
                    {client.quintil && (
                      <Badge variant={getBadgeVariant(client.quintil)} className="text-[10px] px-1.5 py-0">
                        {client.quintil}
                      </Badge>
                    )}
                    {client.categorizacion && (
                      <span className="text-[11px] text-slate-500 font-medium">
                        {client.categorizacion}
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <DialogFooter className="p-4 border-t border-slate-100 bg-white">
          <Button variant="outline" size="sm" onClick={onClose}>
            Cancelar
          </Button>
          <Button
            variant="default"
            size="sm"
            onClick={handleSave}
            className="bg-[#6a5cbc] hover:bg-[#53459e] text-white font-bold text-xs"
          >
            Aplicar Selección ({tempSelected.length})
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
