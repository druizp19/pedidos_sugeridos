"use client";

import React, { useState } from "react";
import {
  Download,
  RefreshCw,
  BarChart2,
  Calendar,
  Scale,
  Package,
  Coins,
  FileSpreadsheet,
  LogOut,
  User,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { FilterState } from "@/types";
import { getApiPath } from "@/lib/utils";

interface HeaderProps {
  filters: FilterState;
  onUnitChange: (unit: "UNIDAD" | "S/ SOLES") => void;
  onRefresh: () => void;
  isLoading: boolean;
  user?: {
    id_usuario?: number;
    nombre?: string;
    email?: string;
    rol?: string;
  } | null;
  onLogout?: () => void;
}

export function Header({ filters, onUnitChange, onRefresh, isLoading, user, onLogout }: HeaderProps) {
  const [isExporting, setIsExporting] = useState(false);

  const handleExportExcel = async () => {
    setIsExporting(true);
    try {
      const payload = {
        unidadMedida: filters.unidadMedida,
        unidadNegocio: filters.unidadNegocio ? [filters.unidadNegocio] : [],
        franquicia: filters.franquicia ? [filters.franquicia] : [],
        marca: filters.marca ? [filters.marca] : [],
        categorizacion: filters.quintil ? [filters.quintil] : [],
        selectedClients: filters.selectedClients,
        search: filters.search,
      };

      const res = await fetch(getApiPath("/api/export-excel"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) throw new Error("Error en la descarga de Excel");

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `Construccion_de_Share_Medifarma_${filters.unidadMedida}.xlsx`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error(err);
      alert("Error al exportar archivo Excel");
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 border-b-2 border-[#6a5cbc] bg-white shadow-xs">
      <div className="w-full flex flex-wrap items-center justify-between gap-3 px-3 sm:px-5 lg:px-7 py-2.5 sm:py-3">
        {/* Brand identity */}
        <div className="flex items-center gap-3 sm:gap-4 min-w-0">
          <div className="flex items-center shrink-0">
            <img
              src={getApiPath("/assets/medifarma_logo_purple.png")}
              alt="Medifarma Humanova"
              className="h-8 sm:h-9 w-auto object-contain"
            />
          </div>
          <div className="h-7 w-px bg-slate-200 hidden sm:block shrink-0" />
          <div className="flex flex-col min-w-0">
            <h1 className="text-base sm:text-lg lg:text-xl font-extrabold text-[#1d252d] tracking-tight leading-tight truncate">
              Pedidos Sugeridos
            </h1>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="text-[11px] sm:text-xs font-semibold text-[#6a5cbc] truncate">
                Análisis de Mercado & Desglose por Cliente
              </span>
              <span className="hidden xl:inline-flex items-center gap-1 bg-[#ede9fe] text-[#6a5cbc] text-[10px] font-bold px-2 py-0.5 rounded-full border border-[#ddd6fe] shrink-0">
                <Calendar className="h-3 w-3 text-[#6a5cbc]" />
                Ene - May 2026
              </span>
            </div>
          </div>
        </div>

        {/* Controls: Unit Switcher & Actions */}
        <div className="flex items-center flex-wrap gap-2 sm:gap-2.5">
          {/* Unit Toggle Group */}
          <div className="flex items-center gap-1.5 bg-[#f8fafc] px-2 py-0.5 sm:py-1 rounded-lg border border-slate-200">
            <span className="text-xs font-bold text-[#1d252d] hidden md:flex items-center gap-1">
              <Scale className="h-3.5 w-3.5 text-slate-600" />
              Métrica:
            </span>
            <div className="flex bg-[#e2e8f0] p-0.5 rounded-md">
              <button
                onClick={() => onUnitChange("UNIDAD")}
                className={`rounded px-2 sm:px-2.5 py-1 text-xs font-bold flex items-center gap-1 transition-all ${
                  filters.unidadMedida === "UNIDAD"
                    ? "bg-[#6a5cbc] text-white shadow-xs"
                    : "text-slate-600 hover:text-[#6a5cbc]"
                }`}
              >
                <Package className="h-3.5 w-3.5 shrink-0" />
                <span>UNIDADES</span>
              </button>
              <button
                onClick={() => onUnitChange("S/ SOLES")}
                className={`rounded px-2 sm:px-2.5 py-1 text-xs font-bold flex items-center gap-1 transition-all ${
                  filters.unidadMedida === "S/ SOLES"
                    ? "bg-[#6a5cbc] text-white shadow-xs"
                    : "text-slate-600 hover:text-[#6a5cbc]"
                }`}
              >
                <Coins className="h-3.5 w-3.5 shrink-0" />
                <span>S/ SOLES</span>
              </button>
            </div>
          </div>

          {/* Botón Ver en BI */}
          <a
            href="https://app.powerbi.com/reportEmbed?reportId=bfebef73-a89e-4277-a63a-5696af17f567&autoAuth=true&ctid=c646feee-bdad-4c72-b8a2-bf167f36afaf"
            target="_blank"
            rel="noopener noreferrer"
            id="btnVerEnBI"
            title="Abrir reporte oficial en Power BI"
            className="inline-flex items-center gap-1.5 h-8 px-2.5 sm:px-3.5 text-xs font-bold text-[#1a1a1a] bg-[#f2c811] hover:bg-[#e5b800] rounded-md shadow-xs transition-colors select-none shrink-0"
          >
            <BarChart2 className="h-3.5 w-3.5 text-[#1a1a1a] shrink-0" />
            <span className="hidden sm:inline">Ver en BI</span>
            <span className="sm:hidden">BI</span>
          </a>

          {/* Botón Exportar Excel */}
          <button
            onClick={handleExportExcel}
            disabled={isExporting || isLoading}
            className="inline-flex items-center gap-1.5 h-8 px-2.5 sm:px-3.5 text-xs font-bold text-white bg-[#15803d] hover:bg-[#166534] rounded-md shadow-xs transition-colors disabled:opacity-50 select-none cursor-pointer shrink-0"
          >
            <FileSpreadsheet className={`h-3.5 w-3.5 shrink-0 ${isExporting ? "animate-bounce" : ""}`} />
            <span className="hidden sm:inline">{isExporting ? "Exportando..." : "Exportar Excel"}</span>
            <span className="sm:hidden">{isExporting ? "..." : "Excel"}</span>
          </button>

          {/* Usuario activo */}
          {user?.nombre && (
            <div
              title={`Usuario: ${user.nombre} (${user.rol || 'USUARIO'})`}
              className="hidden xl:flex items-center gap-1.5 h-8 px-2.5 bg-slate-50 border border-slate-200 rounded-md text-xs font-semibold text-slate-700"
            >
              <User className="h-3.5 w-3.5 text-slate-500 shrink-0" />
              <span className="truncate max-w-[120px]">{user.nombre.split(' ')[0]}</span>
            </div>
          )}

          {/* Botón Cerrar sesión */}
          <button
            onClick={onLogout}
            id="btnCerrarSesion"
            title="Cerrar sesión y regresar al portal Ecosistema"
            className="inline-flex items-center gap-1.5 h-8 px-2.5 sm:px-3 text-xs font-bold text-slate-700 hover:text-red-700 bg-slate-100 hover:bg-red-50 border border-slate-200 hover:border-red-200 rounded-md shadow-xs transition-colors select-none cursor-pointer shrink-0"
          >
            <LogOut className="h-3.5 w-3.5 text-slate-500 hover:text-red-600 shrink-0" />
            <span className="hidden sm:inline">Cerrar sesión</span>
            <span className="sm:hidden">Salir</span>
          </button>
        </div>
      </div>
    </header>
  );
}
