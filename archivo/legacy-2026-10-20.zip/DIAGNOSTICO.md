# Pedidos Sugeridos: diagnóstico y evolución

Decisión posterior: las tres tablas son de carga; FACT_VENTAS conserva fecha y distribuidor, sin columna origen. Una cuarta tabla FACT_VENTAS_AGREGADA se genera mediante procedimiento con acumulados actual/anterior por versión. es_competidor se calcula en materiales desde corporacion (HUMANOVA LAB CORP = 0; otras = 1; ausentes = NULL). Los scripts 004 a 007 y database/README.md describen el flujo vigente.

Actualización 16/10/2026: el usuario decidió usar DTM_PEDIDOS_SUGERIDOS con solo tres tablas ods (DIM_CLIENTE, DIM_MATERIAL y FACT_VENTAS), cargas trimestrales y períodos/divisores configurados en la aplicación. Esta decisión reemplaza las propuestas de catálogo de versiones y carga compleja de este diagnóstico. El diseño vigente está en database/README.md. El análisis del comportamiento original se conserva como referencia.

Fecha: 15 de octubre de 2026. Inspección estática del código; no se consultó SQL Server ni se ejecutó una prueba de carga.

## Copia inicial

Se copiaron y verificaron por SHA-256 los 47 archivos de aplicación y configuración de LUIS RENGIFO, sin diferencias. Se excluyeron .git, node_modules, .next, __pycache__, .venv y tsconfig.tsbuildinfo: historial, dependencias instalables y archivos regenerables. La configuración local .env se conserva; no debe publicarse. El proyecto original no se modificó.

La copia conserva puertos y rutas originales (Python 8080, Next.js /sugerido). Antes de levantar ambas aplicaciones simultáneamente hay que asignar puertos independientes y ajustar el proxy. Ejecutar npm ci dentro de frontend para reinstalar dependencias.

## Fuentes SQL identificadas

Configuración local: servidor 172.17.2.181:1433, base VW_FR.

| Objeto referenciado | Uso | Referencia en server/data_engine.py |
| --- | --- | --- |
| dbo.FACT_VENTAS_AGREGADA | Importes actuales y anteriores por RUC, presentación y métrica; matriz y benchmark territorial | 401, 524, 565, 1025, 1239 |
| dbo.DIM_MATERIAL | Jerarquía comercial, mercado y clasificación de competidores | 128, 402 |
| dbo.DIM_CLIENTE | Clientes, RUC, territorio, zona, supervisor, categoría y quintil | 166, 184, 403 |
| dbo.vendedores | Nombres de vendedores y supervisores asociados a zonaBase | 145 |
| dbo.FACT_VENTAS_SI | Compra por distribuidor/material/marca en detalle de cliente; soles o unidades | 1352 |

Son cinco objetos físicos referenciados; BASE_VENTAS, TOTAL_MERCADO y similares son CTE de las consultas, no tablas adicionales. El tipo real de cada objeto (tabla o vista), columnas e índices debe verificarse contra el catálogo SQL.

## Dos cortes de datos

La matriz lee vta_actual y vta_anterior de FACT_VENTAS_AGREGADA sin filtro temporal. El corte está implícito en la carga de esa tabla. Los cálculos SQL y Python contienen factores 5.0 y las respuestas indican Enero 2026 - Mayo 2026. FACT_VENTAS_SI sí filtra fechas explícitas entre 2026-01-01 y 2026-05-31.

No basta cambiar la etiqueta del período o agregar un selector: reemplazar los agregados perdería el corte original. Es necesario identificar la fuente enero–agosto y su comparable anterior. También decidir si dimensiones, quintiles y asignaciones comerciales se conservan por corte o se actualizan para ambos.

Modelo propuesto: identificador de corte inmutable, fechas inicial/final, número de meses, origen validado de datos, comparable anterior y versión de carga. Propagar el corte en todas las consultas, exportaciones y claves de caché. V1 usa cinco meses; V2 ocho. El servidor debe validar el identificador contra un catálogo permitido, sin aceptar nombres SQL arbitrarios del navegador. Para columnas datetime, usar límite final exclusivo al día siguiente.

## Capacidad y API: diseño pendiente de implementación

El servidor actual usa ThreadingHTTPServer y abre conexiones por operación. Los diccionarios CACHE son locales al proceso, sin expiración ni tamaño máximo; tampoco coordinan consultas idénticas simultáneas. No se ha demostrado capacidad para 50 usuarios.

Separar HTTP, casos de uso, cálculos y repositorios SQL. Usar un servicio de producción con pool limitado, consultas parametrizadas, límites de tiempo y autorización por vendedor/zona aplicada en servidor. Definir acceso de gerente y supervisor antes de exponer datos a toda la fuerza comercial.

Para consultas interactivas: caché acotada con expiración, deduplicación de consultas idénticas y concurrencia SQL limitada. Para matrices costosas y exportaciones: cola de trabajos con almacenamiento compartido, estados pendiente/en ejecución/completado/error, identificador de trabajo y consulta de estado. Establecer tamaño máximo, plazo de espera, rechazo explícito cuando se llena y reintentos limitados solo para errores transitorios. El resultado y estado deben quedar asociados al usuario autorizado y al corte. Una cola no aumenta por sí misma la capacidad de SQL Server.

Elegir límites de workers y conexiones mediante medición, no por el número de usuarios. Probar 50 usuarios concurrentes con filtros diversos, caché fría/caliente, exportaciones y cambios de corte. Registrar latencia p95, errores, espera de cola, consultas activas y memoria. Revisar planes e índices antes de crear índices nuevos.

## Referencia visual y de estructura

Se revisó oportunidad-venta-hexagonal: encabezado con identidad Humanova/Medifarma, tema claro/oscuro, tarjetas KPI, filtros, paneles y tablas adaptables. Su código separa domain, application e infrastructure y reutiliza un pool SQL. Tomar esos patrones para Pedidos Sugeridos, conservando la matriz, detalle de clientes y exportaciones. Sus dependencias Next.js 16/React 19/Tailwind 4 difieren de Next.js 14/React 18/Tailwind 3 del original; los componentes requieren adaptación.

## Orden de implementación

1. Confirmar fuentes y esquema de enero–agosto, comparable y conservación de dimensiones de V1.
2. Establecer resultados de referencia de V1 para comprobar equivalencia numérica.
3. Implementar catálogo de cortes y repositorios independientes; probar aislamiento entre cortes.
4. Incorporar límites de concurrencia, caché, cola de trabajos y autorización.
5. Adaptar interfaz visual y selector de corte, con estados de espera y error claros.
6. Validar resultados y carga antes de habilitar a la fuerza de ventas.

Estado: copia y diagnóstico completados. Rediseño, cola y V2 aún no implementados.
